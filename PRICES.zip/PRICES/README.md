# PriceGhost Pro — Real-Time Price Tracker & Multi-Store Deal Aggregator

A modern, full-featured web application for tracking product prices, discovering discounts, and comparing deals across Amazon, Flipkart, Croma, Reliance Digital, and Snapdeal.

---

## 🌟 What's New & Upgraded

- **💎 Modern Web Interface:**
  - Glassmorphic top navigation with ambient particle background and luminous glowing accents.
  - **Dark & Light Mode** toggle with instant local storage persistence.
  - Global search bar with keyboard shortcut (`/`).
  - **Best Deal Spotlight:** Highlights the #1 lowest price retailer and exact savings amount with a direct buy link.
  - Interactive retailer filters: Amazon, Flipkart, Croma, Reliance Digital, and Snapdeal.
  - **KPI Dashboard Metrics:** Total Tracked Items, Active Price Drops, Target Hits, and Potential Savings.
  - **Product Watchlist:** Rich product cards with high-res thumbnails, price drop percentage badges (`-18% OFF`), strikethrough historical highs, interactive SVG sparklines, target progress meters, competitor store deal pills, and category filters.
  - **Deals & Drops Feed:** Real-time feed aggregating the steepest discounts and all-time low items.
  - **In-App Notification Center:** Real-time alert bell with unread counter badge, notification drawer, and click-to-view links.
  - **High-Resolution Price History:** Smooth SVG bezier curve charts with gradient fills, statistics breakdown, and check history log table.

- **🗄️ Production-Grade Database & Multi-User Architecture:**
  - **Native Built-in SQLite (`node:sqlite`):** Zero-dependency C-speed SQLite engine running natively on Node 22/24+ on Windows, Linux, and macOS without requiring node-gyp or C++ compilation.
  - **Multi-Tenant User Isolation:** Full user registration (`/api/register`), session login (`/api/login`), password hashing via bcrypt, and isolated watchlists.
  - **Instant 1-Click Demo Access:** Pre-configured `admin` / `admin123` button for immediate reviewer access.
  - **Notifications Table (`notifications`):** Persists all price drops, target hits, restocks, and competitor discounts with read/unread tracking.
  - **Search History Table (`search_history`):** Captures popular searches to populate trending search pills.
  - **Categories & Notes:** Categorize tracked items (Smartphones, Audio, Laptops, Gaming, Home, Fashion) and attach custom notes.

---

## 🚀 Quick Start

### 1. Local Development (Node.js 22+)

```bash
# Install dependencies
npm install

# Run the test suite (36 tests)
npm test

# Start the application server
npm start
```

Then navigate to **http://localhost:8089** in your browser.

- Default Administrator: `admin`
- Default Password: `admin123` (or click **"⚡ 1-Click Demo Login"** on the website)

### 2. Docker Deployment

```bash
docker compose up -d --build
```

Access the web dashboard at **http://localhost:8089**.

---

## 🛠️ API Overview

| Method | Endpoint | Description |
|---|---|---|
| `POST` | `/api/register` | Register a new user account |
| `POST` | `/api/login` | Authenticate user session |
| `POST` | `/api/logout` | Terminate session |
| `GET` | `/api/me` | Fetch active user profile |
| `GET` | `/api/dashboard/stats` | KPI metrics (tracked items, savings, active drops) |
| `GET` | `/api/products` | Retrieve user's watchlist with search, sort & category filters |
| `POST` | `/api/products` | Track a new product by URL |
| `GET` | `/api/products/:id` | Get product details & full price history |
| `PUT` | `/api/products/:id` | Update product target price, category, or notes |
| `DELETE` | `/api/products/:id` | Delete product from watchlist |
| `POST` | `/api/products/:id/refresh` | Trigger immediate price recheck |
| `GET` | `/api/deals` | Get trending deals and all-time low price drops |
| `GET` | `/api/notifications` | Get in-app alerts and unread badge count |
| `POST` | `/api/notifications/read-all`| Mark all notifications as read |
| `POST` | `/api/compare` | Search & compare prices across all supported stores |
| `POST` | `/api/demo-check` | Quick URL extraction test & email report |
| `GET` | `/api/settings` | Get outbound alert webhooks (Discord / Telegram / Email) |
| `PUT` | `/api/settings` | Update alert webhooks |

---

## 🧪 Testing

The test suite runs with Node's native test runner (`node --test`) covering scraper accuracy, multi-store price comparison, error handling and retry mechanisms, user authentication, and database analytics:

```bash
npm test
```
