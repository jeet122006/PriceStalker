/* ==========================================================================
   PRICEGHOST PRO — CLIENT APPLICATION CORE
   ========================================================================== */

(() => {
  'use strict';

  // --- Global Application State ---
  let isAuthed = false;
  let currentUser = null;
  let products = [];
  let categories = ['All'];
  let currentCategory = 'All';
  let lastCompare = null;
  let storesList = [];
  let notifications = [];
  let unreadCount = 0;
  let caps = { browser: false, proxy: false };
  let selectedCandidateProduct = null;

  // --- DOM Elements ---
  const brandHomeBtn = document.getElementById('brandHomeBtn');
  const globalHeaderSearch = document.getElementById('globalHeaderSearch');
  const themeToggleBtn = document.getElementById('themeToggleBtn');
  const livePill = document.getElementById('livePill');
  const refreshAgo = document.getElementById('refreshAgo');

  const unauthedBtns = document.getElementById('unauthedBtns');
  const authedUserMenu = document.getElementById('authedUserMenu');
  const userMenuToggleBtn = document.getElementById('userMenuToggleBtn');
  const userDropdown = document.getElementById('userDropdown');
  const userAvatar = document.getElementById('userAvatar');
  const userMenuName = document.getElementById('userMenuName');
  const userDropdownDisplayName = document.getElementById('userDropdownDisplayName');
  const userDropdownEmail = document.getElementById('userDropdownEmail');
  const userRolePill = document.getElementById('userRolePill');
  const openSettingsItem = document.getElementById('openSettingsItem');
  const logoutItem = document.getElementById('logoutItem');

  const notifWrapper = document.getElementById('notifWrapper');
  const notifBtn = document.getElementById('notifBtn');
  const notifBadge = document.getElementById('notifBadge');
  const notifDropdown = document.getElementById('notifDropdown');
  const notifCountTag = document.getElementById('notifCountTag');
  const notifList = document.getElementById('notifList');
  const markAllReadBtn = document.getElementById('markAllReadBtn');

  // Navigation Tabs
  const navTabs = [...document.querySelectorAll('.nav-tab')];
  const panes = [...document.querySelectorAll('.pane')];
  const watchlistCountBadge = document.getElementById('watchlistCountBadge');

  // Compare Tab Elements
  const compareForm = document.getElementById('compareForm');
  const compareInput = document.getElementById('compareInput');
  const clearCompareInput = document.getElementById('clearCompareInput');
  const compareBtn = document.getElementById('compareBtn');
  const storeChips = document.getElementById('storeChips');
  const trendingChips = document.getElementById('trendingChips');
  const recentSearches = document.getElementById('recentSearches');
  const recentChips = document.getElementById('recentChips');
  const compareError = document.getElementById('compareError');
  const compareErrorText = document.getElementById('compareErrorText');
  const compareLoading = document.getElementById('compareLoading');
  const loadingText = document.getElementById('loadingText');
  const loadingStores = document.getElementById('loadingStores');
  const compareResults = document.getElementById('compareResults');
  const bestDealSpotlight = document.getElementById('bestDealSpotlight');
  const compareLabel = document.getElementById('compareLabel');
  const searchedAs = document.getElementById('searchedAs');
  const compareSummary = document.getElementById('compareSummary');
  const fltStock = document.getElementById('fltStock');
  const fltMax = document.getElementById('fltMax');
  const fltSort = document.getElementById('fltSort');
  const refreshCompareBtn = document.getElementById('refreshCompareBtn');
  const copyBtn = document.getElementById('copyBtn');
  const csvBtn = document.getElementById('csvBtn');
  const offerList = document.getElementById('offerList');
  const offerEmpty = document.getElementById('offerEmpty');
  const similarBox = document.getElementById('similarBox');
  const similarList = document.getElementById('similarList');
  const fixHint = document.getElementById('fixHint');
  const storeStatus = document.getElementById('storeStatus');
  const compareMeta = document.getElementById('compareMeta');

  // Watchlist Tab Elements
  const metricTotalTracked = document.getElementById('metricTotalTracked');
  const metricActiveDrops = document.getElementById('metricActiveDrops');
  const metricTargetHits = document.getElementById('metricTargetHits');
  const metricTotalSavings = document.getElementById('metricTotalSavings');
  const loggedOutNotice = document.getElementById('loggedOutNotice');
  const listSection = document.getElementById('listSection');
  const countLabel = document.getElementById('countLabel');
  const openAddModalBtn = document.getElementById('openAddModalBtn');
  const categoryPillsBar = document.getElementById('categoryPillsBar');
  const listFilter = document.getElementById('listFilter');
  const listSort = document.getElementById('listSort');
  const emptyState = document.getElementById('empty');
  const emptyAddBtn = document.getElementById('emptyAddBtn');
  const productList = document.getElementById('productList');

  // Deals Tab Elements
  const dealsGrid = document.getElementById('dealsGrid');
  const refreshDealsBtn = document.getElementById('refreshDealsBtn');

  // Inspector Tab Elements
  const demoForm = document.getElementById('demoForm');
  const demoUrlInput = document.getElementById('demoUrlInput');
  const demoEmailInput = document.getElementById('demoEmailInput');
  const demoBtn = document.getElementById('demoBtn');
  const demoMsg = document.getElementById('demoMsg');
  const demoChart = document.getElementById('demoChart');

  // Modals
  const addModal = document.getElementById('addModal');
  const addForm = document.getElementById('addForm');
  const urlInput = document.getElementById('urlInput');
  const targetInput = document.getElementById('targetInput');
  const categoryInput = document.getElementById('categoryInput');
  const intervalInput = document.getElementById('intervalInput');
  const alertEmailInput2 = document.getElementById('alertEmailInput2');
  const notesInput = document.getElementById('notesInput');
  const watchStoresInput = document.getElementById('watchStoresInput');
  const addError = document.getElementById('addError');
  const addBtn = document.getElementById('addBtn');
  const closeAddModalBtn = document.getElementById('closeAddModalBtn');
  const cancelAddBtn = document.getElementById('cancelAddBtn');

  const editModal = document.getElementById('editModal');
  const editForm = document.getElementById('editForm');
  const editProductId = document.getElementById('editProductId');
  const editNameInput = document.getElementById('editNameInput');
  const editTargetInput = document.getElementById('editTargetInput');
  const editCategoryInput = document.getElementById('editCategoryInput');
  const editIntervalInput = document.getElementById('editIntervalInput');
  const editAlertEmailInput = document.getElementById('editAlertEmailInput');
  const editNotesInput = document.getElementById('editNotesInput');
  const editCompareStoresInput = document.getElementById('editCompareStoresInput');
  const closeEditModalBtn = document.getElementById('closeEditModalBtn');
  const cancelEditBtn = document.getElementById('cancelEditBtn');

  const historyModal = document.getElementById('historyModal');
  const historyTitle = document.getElementById('historyTitle');
  const historySub = document.getElementById('historySub');
  const historyStatsBar = document.getElementById('historyStatsBar');
  const historyChart = document.getElementById('historyChart');
  const historyTableBody = document.getElementById('historyTableBody');
  const historyClose = document.getElementById('historyClose');
  const historyCloseBtn = document.getElementById('historyCloseBtn');

  const candidateModal = document.getElementById('candidateModal');
  const candidateList = document.getElementById('candidateList');
  const candidateCloseX = document.getElementById('candidateCloseX');
  const candidateCancel = document.getElementById('candidateCancel');

  const settingsModal = document.getElementById('settingsModal');
  const settingsCloseX = document.getElementById('settingsCloseX');
  const settingsCancel = document.getElementById('settingsCancel');
  const settingsSave = document.getElementById('settingsSave');
  const testAlertBtn = document.getElementById('testAlertBtn');
  const webhookInput = document.getElementById('webhookInput');
  const tgTokenInput = document.getElementById('tgTokenInput');
  const tgChatInput = document.getElementById('tgChatInput');
  const brevoKeyInput = document.getElementById('brevoKeyInput');
  const brevoSenderInput = document.getElementById('brevoSenderInput');
  const alertEmailInput = document.getElementById('alertEmailInput');
  const profileEmailInput = document.getElementById('profileEmailInput');
  const profilePasswordInput = document.getElementById('profilePasswordInput');
  const settingsMsg = document.getElementById('settingsMsg');

  const authModal = document.getElementById('authModal');
  const authCloseX = document.getElementById('authCloseX');
  const authTabLogin = document.getElementById('authTabLogin');
  const authTabRegister = document.getElementById('authTabRegister');
  const authModalTitle = document.getElementById('authModalTitle');
  const authEmailGroup = document.getElementById('authEmailGroup');
  const authUsername = document.getElementById('authUsername');
  const authEmail = document.getElementById('authEmail');
  const authPassword = document.getElementById('authPassword');
  const authError = document.getElementById('authError');
  const authSubmitBtn = document.getElementById('authSubmitBtn');
  const quickDemoLoginBtn = document.getElementById('quickDemoLoginBtn');
  const openLoginBtn = document.getElementById('openLoginBtn');
  const openRegisterBtn = document.getElementById('openRegisterBtn');
  const calloutLoginBtn = document.getElementById('calloutLoginBtn');
  const calloutDemoBtn = document.getElementById('calloutDemoBtn');

  const toastContainer = document.getElementById('toastContainer');

  let authMode = 'login'; // 'login' or 'register'

  // ==========================================================================
  // TOAST NOTIFICATIONS HELPER
  // ==========================================================================
  function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    let icon = 'ℹ️';
    if (type === 'success') icon = '✅';
    if (type === 'error') icon = '⚠️';
    toast.innerHTML = `<span>${icon}</span><span>${escapeHtml(message)}</span>`;
    toastContainer.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateX(100%)';
      toast.style.transition = 'all 0.3s ease';
      setTimeout(() => toast.remove(), 300);
    }, 4000);
  }

  // ==========================================================================
  // THEME SWITCHER (Dark / Light)
  // ==========================================================================
  function initTheme() {
    const savedTheme = localStorage.getItem('priceghost_theme') || 'dark';
    setTheme(savedTheme);
  }

  function setTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('priceghost_theme', theme);
  }

  themeToggleBtn.addEventListener('click', () => {
    const current = document.documentElement.getAttribute('data-theme') || 'dark';
    const next = current === 'dark' ? 'light' : 'dark';
    setTheme(next);
  });

  // ==========================================================================
  // TAB NAVIGATION
  // ==========================================================================
  function showTab(name) {
    if (!panes.some((p) => p.dataset.pane === name)) name = 'compare';
    navTabs.forEach((tab) => {
      const isCurrent = tab.dataset.tab === name;
      tab.classList.toggle('on', isCurrent);
      tab.setAttribute('aria-selected', isCurrent ? 'true' : 'false');
    });
    panes.forEach((pane) => {
      pane.classList.toggle('active', pane.dataset.pane === name);
      pane.hidden = pane.dataset.pane !== name;
    });
    if (location.hash.slice(1) !== name) {
      history.replaceState(null, '', '#' + name);
    }
    if (name === 'watch' && isAuthed) {
      loadProducts();
      loadStats();
    } else if (name === 'deals') {
      loadDeals();
    }
  }

  navTabs.forEach((tab) => {
    tab.addEventListener('click', () => showTab(tab.dataset.tab));
  });

  window.addEventListener('hashchange', () => showTab(location.hash.slice(1)));

  brandHomeBtn.addEventListener('click', (e) => {
    e.preventDefault();
    showTab('compare');
  });

  // ==========================================================================
  // AUTHENTICATION & SESSION
  // ==========================================================================
  async function authedFetch(url, opts = {}) {
    const res = await fetch(url, opts);
    if (res.status === 401) {
      isAuthed = false;
      renderAuthState();
      openAuthModal('login');
      throw new Error('Not logged in.');
    }
    return res;
  }

  async function checkAuth() {
    try {
      const res = await fetch('/api/me');
      const data = await res.json();
      if (data && data.authed) {
        isAuthed = true;
        currentUser = data.user || { username: data.username, role: 'user' };
      } else {
        isAuthed = false;
        currentUser = null;
      }
    } catch {
      isAuthed = false;
      currentUser = null;
    }
    renderAuthState();
    if (isAuthed) {
      loadProducts();
      loadStats();
      loadNotifications();
      loadCategories();
    }
  }

  function renderAuthState() {
    unauthedBtns.hidden = isAuthed;
    authedUserMenu.hidden = !isAuthed;
    notifWrapper.hidden = !isAuthed;
    loggedOutNotice.hidden = isAuthed;
    listSection.hidden = !isAuthed;

    if (isAuthed && currentUser) {
      const name = currentUser.username || 'User';
      userMenuName.textContent = name;
      userAvatar.textContent = name.charAt(0).toUpperCase();
      userDropdownDisplayName.textContent = name;
      userDropdownEmail.textContent = currentUser.email || `${name}@user.local`;
      userRolePill.textContent = (currentUser.role || 'user').toUpperCase();
    }
  }

  function openAuthModal(mode = 'login') {
    authMode = mode;
    authError.hidden = true;
    authUsername.value = '';
    authPassword.value = '';
    authEmail.value = '';

    if (mode === 'login') {
      authTabLogin.classList.add('on');
      authTabRegister.classList.remove('on');
      authModalTitle.textContent = 'Sign In to PriceGhost';
      authEmailGroup.hidden = true;
      authSubmitBtn.textContent = 'Sign In';
    } else {
      authTabRegister.classList.add('on');
      authTabLogin.classList.remove('on');
      authModalTitle.textContent = 'Create Free Account';
      authEmailGroup.hidden = false;
      authSubmitBtn.textContent = 'Create Account';
    }
    authModal.hidden = false;
    authUsername.focus();
  }

  authTabLogin.addEventListener('click', () => openAuthModal('login'));
  authTabRegister.addEventListener('click', () => openAuthModal('register'));
  authCloseX.addEventListener('click', () => (authModal.hidden = true));
  openLoginBtn.addEventListener('click', () => openAuthModal('login'));
  openRegisterBtn.addEventListener('click', () => openAuthModal('register'));
  calloutLoginBtn.addEventListener('click', () => openAuthModal('login'));

  // Quick 1-click Demo Login
  async function performDemoLogin() {
    authError.hidden = true;
    try {
      const res = await fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: 'admin', password: 'admin123' }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Demo login failed');
      authModal.hidden = true;
      showToast('Signed in as Admin!', 'success');
      await checkAuth();
    } catch (err) {
      authError.textContent = err.message + ' (Check docker or server startup log if password was customized)';
      authError.hidden = false;
    }
  }

  quickDemoLoginBtn.addEventListener('click', performDemoLogin);
  calloutDemoBtn.addEventListener('click', performDemoLogin);

  authForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    authError.hidden = true;
    authSubmitBtn.disabled = true;
    const origText = authSubmitBtn.textContent;
    authSubmitBtn.textContent = 'Processing…';

    const username = authUsername.value.trim();
    const password = authPassword.value;
    const email = authEmail.value.trim();

    try {
      const endpoint = authMode === 'register' ? '/api/register' : '/api/login';
      const body = authMode === 'register' ? { username, password, email } : { username, password };

      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Authentication failed');

      authModal.hidden = true;
      showToast(authMode === 'register' ? 'Account created successfully!' : `Welcome back, ${username}!`, 'success');
      await checkAuth();
    } catch (err) {
      authError.textContent = err.message;
      authError.hidden = false;
    } finally {
      authSubmitBtn.disabled = false;
      authSubmitBtn.textContent = origText;
    }
  });

  // User Dropdown toggle
  userMenuToggleBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    userDropdown.hidden = !userDropdown.hidden;
  });
  document.addEventListener('click', () => {
    userDropdown.hidden = true;
    notifDropdown.hidden = true;
  });

  logoutItem.addEventListener('click', async () => {
    await fetch('/api/logout', { method: 'POST' });
    isAuthed = false;
    currentUser = null;
    renderAuthState();
    showToast('Logged out successfully.', 'info');
    showTab('compare');
  });

  // ==========================================================================
  // IN-APP NOTIFICATIONS CENTER
  // ==========================================================================
  async function loadNotifications() {
    if (!isAuthed) return;
    try {
      const res = await authedFetch('/api/notifications');
      const data = await res.json();
      notifications = data.notifications || [];
      unreadCount = data.unreadCount || 0;
      renderNotifications();
    } catch {
      // ignore
    }
  }

  function renderNotifications() {
    if (unreadCount > 0) {
      notifBadge.textContent = unreadCount > 9 ? '9+' : unreadCount;
      notifBadge.hidden = false;
      notifCountTag.textContent = `${unreadCount} new`;
    } else {
      notifBadge.hidden = true;
      notifCountTag.textContent = '0 new';
    }

    if (!notifications.length) {
      notifList.innerHTML = `<div class="notif-empty">No alerts yet. We will ping you when prices drop or items restock!</div>`;
      return;
    }

    notifList.innerHTML = '';
    notifications.forEach((n) => {
      const div = document.createElement('div');
      div.className = `notif-item ${n.is_read ? '' : 'unread'}`;

      let iconClass = 'notif-icon-drop';
      let iconChar = '📉';
      if (n.type === 'target_met') {
        iconClass = 'notif-icon-target';
        iconChar = '🎯';
      } else if (n.type === 'restock') {
        iconClass = 'notif-icon-restock';
        iconChar = '📦';
      } else if (n.type === 'cheaper_store') {
        iconClass = 'notif-icon-cheaper';
        iconChar = '⚡';
      }

      div.innerHTML = `
        <div class="notif-item-icon ${iconClass}">${iconChar}</div>
        <div class="notif-item-content">
          <div class="notif-item-title">${escapeHtml(n.title)}</div>
          <div class="notif-item-msg">${escapeHtml(n.message)}</div>
          <div class="notif-item-time">${timeAgo(n.created_at)}</div>
        </div>
      `;

      div.addEventListener('click', async () => {
        if (!n.is_read) {
          await authedFetch(`/api/notifications/${n.id}/read`, { method: 'POST' });
          n.is_read = 1;
          unreadCount = Math.max(0, unreadCount - 1);
          renderNotifications();
        }
        if (n.url) window.open(n.url, '_blank');
      });

      notifList.appendChild(div);
    });
  }

  notifBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    notifDropdown.hidden = !notifDropdown.hidden;
  });
  notifDropdown.addEventListener('click', (e) => e.stopPropagation());

  markAllReadBtn.addEventListener('click', async () => {
    await authedFetch('/api/notifications/read-all', { method: 'POST' });
    notifications.forEach((n) => (n.is_read = 1));
    unreadCount = 0;
    renderNotifications();
    showToast('All notifications marked as read', 'info');
  });

  // ==========================================================================
  // DASHBOARD STATS
  // ==========================================================================
  async function loadStats() {
    if (!isAuthed) return;
    try {
      const res = await authedFetch('/api/dashboard/stats');
      const stats = await res.json();
      metricTotalTracked.textContent = stats.totalTracked || 0;
      metricActiveDrops.textContent = stats.activeDrops || 0;
      metricTargetHits.textContent = stats.targetsReached || 0;
      metricTotalSavings.textContent = fmtMoney(stats.totalSavings || 0, '₹');
    } catch {
      // ignore
    }
  }

  // ==========================================================================
  // FORMATTING & CHART HELPERS
  // ==========================================================================
  function fmtMoney(v, currency) {
    if (v == null) return '—';
    const n = Number(v);
    if (currency === '₹') {
      return `₹${n.toLocaleString('en-IN', {
        minimumFractionDigits: Number.isInteger(n) ? 0 : 2,
        maximumFractionDigits: 2,
      })}`;
    }
    return `${currency || '$'}${n.toLocaleString(undefined, {
      minimumFractionDigits: Number.isInteger(n) ? 0 : 2,
      maximumFractionDigits: 2,
    })}`;
  }

  function escapeHtml(s) {
    return String(s || '').replace(/[&<>"']/g, (c) => ({
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#39;',
    }[c]));
  }

  function timeAgo(iso) {
    if (!iso) return 'Just now';
    const normalized = iso.includes('T') ? iso : iso.replace(' ', 'T') + 'Z';
    const diffMs = Date.now() - new Date(normalized).getTime();
    if (Number.isNaN(diffMs)) return 'Recently';
    const mins = Math.round(diffMs / 60000);
    if (mins < 1) return 'Just now';
    if (mins < 60) return `${mins}m ago`;
    const hrs = Math.round(mins / 60);
    if (hrs < 24) return `${hrs}h ago`;
    const days = Math.round(hrs / 24);
    return `${days}d ago`;
  }

  function formatDateShort(iso) {
    if (!iso) return '';
    const normalized = iso.includes('T') ? iso : iso.replace(' ', 'T') + 'Z';
    const d = new Date(normalized);
    if (Number.isNaN(d.getTime())) return '';
    return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
  }

  // Modern SVG Sparkline with smooth bezier curve
  function sparklineSvg(points) {
    if (!points || points.length < 2) return '';
    const w = 260, h = 34, pad = 4;
    const min = Math.min(...points), max = Math.max(...points);
    const range = max - min || 1;
    const step = (w - pad * 2) / (points.length - 1);

    const coords = points.map((p, i) => {
      const x = pad + i * step;
      const y = h - pad - ((p - min) / range) * (h - pad * 2);
      return { x, y };
    });

    const isDrop = points[points.length - 1] < points[0];
    const strokeColor = isDrop ? 'var(--success)' : 'var(--danger)';

    const pathData = coords.reduce((acc, pt, i, arr) => {
      if (i === 0) return `M ${pt.x.toFixed(1)} ${pt.y.toFixed(1)}`;
      const prev = arr[i - 1];
      const cx = ((prev.x + pt.x) / 2).toFixed(1);
      return `${acc} C ${cx} ${prev.y.toFixed(1)}, ${cx} ${pt.y.toFixed(1)}, ${pt.x.toFixed(1)} ${pt.y.toFixed(1)}`;
    }, '');

    return `
      <svg viewBox="0 0 ${w} ${h}" preserveAspectRatio="none">
        <path d="${pathData}" fill="none" stroke="${strokeColor}" stroke-width="2" stroke-linecap="round" />
        <circle cx="${coords[coords.length - 1].x.toFixed(1)}" cy="${coords[coords.length - 1].y.toFixed(1)}" r="3" fill="${strokeColor}" />
      </svg>
    `;
  }

  // Interactive High-Res History Line Chart
  function historyLineChartSvg(history, currency) {
    if (!history || history.length < 2) {
      return `<p class="sub" style="margin:20px 0;text-align:center;">Building price history… Check back after automatic rechecks or hit "Recheck now"!</p>`;
    }
    const w = 680, h = 260, padL = 70, padR = 24, padT = 20, padB = 34;
    const prices = history.map((r) => r.price);
    const min = Math.min(...prices), max = Math.max(...prices);
    const range = max - min || Math.max(1, max * 0.1);
    const niceMin = Math.max(0, min - range * 0.1);
    const niceMax = max + range * 0.1;
    const plotW = w - padL - padR, plotH = h - padT - padB;
    const step = history.length > 1 ? plotW / (history.length - 1) : 0;

    const coords = history.map((r, i) => {
      const x = padL + i * step;
      const y = padT + plotH - ((r.price - niceMin) / (niceMax - niceMin)) * plotH;
      return { x, y, r };
    });

    const isDrop = prices[prices.length - 1] <= prices[0];
    const lineColor = isDrop ? 'var(--success)' : 'var(--danger)';

    const linePoints = coords.map((p) => `${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(' ');
    const areaPoints = `${coords[0].x.toFixed(1)},${h - padB} ${linePoints} ${coords[coords.length - 1].x.toFixed(1)},${h - padB}`;

    const gridLines = [0, 0.5, 1].map((frac) => {
      const y = padT + plotH * frac;
      const val = niceMax - (niceMax - niceMin) * frac;
      return `
        <line x1="${padL}" y1="${y}" x2="${w - padR}" y2="${y}" stroke="var(--border-subtle)" stroke-width="1" stroke-dasharray="3 3" />
        <text x="${padL - 10}" y="${y + 4}" text-anchor="end" fill="var(--text-muted)" font-size="11" font-family="var(--font-mono)">${fmtMoney(val, currency)}</text>
      `;
    }).join('');

    const dots = coords.map((p) => `
      <circle cx="${p.x.toFixed(1)}" cy="${p.y.toFixed(1)}" r="3.5" fill="${lineColor}" stroke="var(--bg-surface)" stroke-width="2">
        <title>${fmtMoney(p.r.price, currency)} on ${formatDateShort(p.r.checked_at)}</title>
      </circle>
    `).join('');

    return `
      <svg viewBox="0 0 ${w} ${h}" style="width:100%;height:auto;display:block;">
        <defs>
          <linearGradient id="chartGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stop-color="${lineColor}" stop-opacity="0.25" />
            <stop offset="100%" stop-color="${lineColor}" stop-opacity="0.0" />
          </linearGradient>
        </defs>
        ${gridLines}
        <polygon points="${areaPoints}" fill="url(#chartGrad)" />
        <polyline points="${linePoints}" fill="none" stroke="${lineColor}" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round" />
        ${dots}
        <text x="${padL}" y="${h - 10}" fill="var(--text-subtle)" font-size="11">${formatDateShort(history[0].checked_at)}</text>
        <text x="${w - padR}" y="${h - 10}" text-anchor="end" fill="var(--text-subtle)" font-size="11">${formatDateShort(history[history.length - 1].checked_at)}</text>
      </svg>
    `;
  }

  // Candidate Bar Chart for multi-method voting breakdown
  function candidateBarChartSvg(candidates, currency) {
    if (!candidates || !candidates.length) return '';
    const w = 540, rowH = 36, padL = 140, padR = 80, padT = 12;
    const h = padT * 2 + candidates.length * rowH;
    const maxVotes = Math.max(...candidates.map((c) => c.votes || c.confidence || 1));
    const barMaxW = w - padL - padR;

    const rows = candidates.map((c, i) => {
      const votes = c.votes || c.confidence || 0;
      const barW = Math.max(8, (votes / maxVotes) * barMaxW);
      const y = padT + i * rowH;
      const label = (c.sources ? c.sources.join(', ') : c.source) || 'Method';
      const color = i === 0 ? 'var(--accent-primary)' : 'var(--border-hover)';
      return `
        <text x="${padL - 12}" y="${y + rowH / 2 + 4}" text-anchor="end" fill="var(--text-main)" font-size="12" font-weight="600">${escapeHtml(label.slice(0, 20))}</text>
        <rect x="${padL}" y="${y + 6}" width="${barW.toFixed(1)}" height="${rowH - 12}" rx="4" fill="${color}" />
        <text x="${padL + barW + 10}" y="${y + rowH / 2 + 4}" fill="var(--text-main)" font-family="var(--font-mono)" font-size="12" font-weight="700">${fmtMoney(c.value, c.currency || currency)}</text>
      `;
    }).join('');

    return `<svg viewBox="0 0 ${w} ${h}" style="width:100%;height:auto;">${rows}</svg>`;
  }

  // ==========================================================================
  // VIEW 1: PRICE COMPARISON ENGINE
  // ==========================================================================
  async function loadCapabilities() {
    try {
      const res = await fetch('/api/capabilities');
      caps = await res.json();
    } catch {
      caps = { browser: false, proxy: false };
    }
  }

  async function loadStores() {
    try {
      const res = await fetch('/api/stores');
      storesList = await res.json();
      renderStoreChips();
    } catch {
      storesList = [];
    }
  }

  function renderStoreChips() {
    storeChips.innerHTML = '';
    storesList.forEach((store) => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'store-chip on';
      btn.dataset.store = store.id;
      btn.innerHTML = `<span class="store-dot"></span><span>${escapeHtml(store.name)}</span>`;
      btn.addEventListener('click', () => {
        btn.classList.toggle('on');
      });
      storeChips.appendChild(btn);
    });
  }

  function getSelectedStoreIds() {
    return [...storeChips.querySelectorAll('.store-chip.on')].map((b) => b.dataset.store);
  }

  // Clear input button
  compareInput.addEventListener('input', () => {
    clearCompareInput.hidden = !compareInput.value;
  });
  clearCompareInput.addEventListener('click', () => {
    compareInput.value = '';
    clearCompareInput.hidden = true;
    compareInput.focus();
  });

  // Trending chips
  trendingChips.addEventListener('click', (e) => {
    const btn = e.target.closest('.chip-trend');
    if (!btn) return;
    const q = btn.dataset.query;
    compareInput.value = q;
    clearCompareInput.hidden = false;
    runCompare({ query: q });
  });

  // Recent searches
  async function loadSearchHistory() {
    try {
      const res = await fetch('/api/search-history');
      const list = await res.json();
      if (list && list.length) {
        recentSearches.hidden = false;
        recentChips.innerHTML = '';
        list.slice(0, 6).forEach((item) => {
          const btn = document.createElement('button');
          btn.type = 'button';
          btn.className = 'chip-trend';
          btn.textContent = item.query;
          btn.addEventListener('click', () => {
            compareInput.value = item.query;
            clearCompareInput.hidden = false;
            runCompare({ query: item.query });
          });
          recentChips.appendChild(btn);
        });
      }
    } catch {}
  }

  compareForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const query = compareInput.value.trim();
    if (!query) return;
    runCompare({ query });
  });

  async function runCompare({ query, stores, fresh = false }, { label } = {}) {
    compareError.hidden = true;
    compareResults.hidden = true;
    compareLoading.hidden = false;
    compareBtn.disabled = true;

    loadingText.textContent = `Scanning retailers for “${query.length > 30 ? query.slice(0, 30) + '…' : query}”…`;
    loadingStores.innerHTML = '';
    storesList.forEach((s) => {
      const pill = document.createElement('div');
      pill.className = 'loading-store-pill';
      pill.innerHTML = `<span class="pulsing-spinner" style="width:14px;height:14px;border-width:2px;"></span><span>${escapeHtml(s.name)}</span>`;
      loadingStores.appendChild(pill);
    });

    try {
      const storeIds = stores || getSelectedStoreIds();
      const res = await fetch('/api/compare', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query, stores: storeIds, fresh }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Comparison query failed');

      lastCompare = { data, label: label || 'Results', request: { query, stores: storeIds } };
      renderCompareResults();
      loadSearchHistory();
    } catch (err) {
      compareErrorText.textContent = err.message;
      compareError.hidden = false;
    } finally {
      compareLoading.hidden = true;
      compareBtn.disabled = false;
    }
  }

  function getVisibleOffers() {
    if (!lastCompare || !lastCompare.data) return [];
    let offers = lastCompare.data.offers.slice();
    if (fltStock.checked) offers = offers.filter((o) => o.inStock);
    const max = Number(fltMax.value);
    if (fltMax.value !== '' && max > 0) offers = offers.filter((o) => o.price <= max);
    const mode = fltSort.value;
    if (mode === 'asc') offers.sort((a, b) => a.price - b.price);
    else if (mode === 'desc') offers.sort((a, b) => b.price - a.price);
    else offers.sort((a, b) => a.storeName.localeCompare(b.storeName) || a.price - b.price);
    return offers;
  }

  function renderCompareResults() {
    if (!lastCompare) return;
    const { data, label } = lastCompare;
    compareResults.hidden = false;

    compareLabel.textContent = label || 'Search Results';
    if (data.originalQuery) {
      searchedAs.hidden = false;
      searchedAs.innerHTML = `Shortened to <strong>${escapeHtml(data.query)}</strong> for best results across stores.`;
    } else {
      searchedAs.hidden = true;
    }

    // Best deal spotlight card
    const sm = data.summary;
    if (sm && sm.cheapest) {
      const cheapest = sm.cheapest;
      bestDealSpotlight.hidden = false;
      const saveText = sm.saving > 0
        ? `Save up to <strong>${fmtMoney(sm.saving, data.currency)}</strong> (${sm.savingPct}%) vs other retailers!`
        : `Best offer found across all active stores.`;

      bestDealSpotlight.innerHTML = `
        <div class="spotlight-left">
          <div class="spotlight-trophy">🏆</div>
          <div>
            <div class="spotlight-tag">Lowest Price Guaranteed</div>
            <div class="spotlight-title">${escapeHtml(cheapest.storeName)} has the lowest price</div>
            <div class="spotlight-desc">${saveText}</div>
          </div>
        </div>
        <div style="display:flex;align-items:center;gap:16px;">
          <div class="spotlight-price">${fmtMoney(cheapest.price, data.currency)}</div>
          <a class="btn btn-primary" href="${escapeHtml(cheapest.url)}" target="_blank" rel="noopener noreferrer">
            <span>Buy on ${escapeHtml(cheapest.storeName)}</span>
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path><polyline points="15 3 21 3 21 9"></polyline><line x1="10" y1="14" x2="21" y2="3"></line></svg>
          </a>
        </div>
      `;
    } else {
      bestDealSpotlight.hidden = true;
    }

    // Offers Grid
    const offers = getVisibleOffers();
    offerList.innerHTML = '';
    offerEmpty.hidden = offers.length > 0;

    const globalMin = data.offers.length ? data.offers[0].price : 0;

    offers.forEach((o, i) => {
      const card = createOfferCard(o, globalMin, data.currency);
      offerList.appendChild(card);
    });

    // Similar models box
    const sim = data.similar || [];
    similarBox.hidden = !sim.length;
    similarList.innerHTML = '';
    if (sim.length) {
      document.getElementById('similarTitle').textContent = `${sim.length} Similar / Alternative Listings`;
      sim.forEach((o) => {
        const card = createOfferCard(o, null, data.currency, true);
        similarList.appendChild(card);
      });
    }

    // Store coverage pills
    storeStatus.innerHTML = '';
    data.stores.forEach((st) => {
      const pill = document.createElement('div');
      pill.className = 'status-pill';
      const isOk = st.status === 'ok';
      const icon = isOk ? '●' : '⚠️';
      pill.innerHTML = `
        <span style="color:${isOk ? 'var(--success)' : 'var(--danger)'}">${icon}</span>
        <span>${escapeHtml(st.name)}</span>
        <span style="color:var(--text-subtle);font-size:11px;">(${escapeHtml(st.status)})</span>
      `;
      storeStatus.appendChild(pill);
    });

    const when = new Date(data.at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    compareMeta.textContent = `Scanned ${data.storesChecked} retailers at ${when}. Prices and stock live from merchant catalog.`;
  }

  function createOfferCard(o, globalMin, currency, isSimilar = false) {
    const card = document.createElement('div');
    const isLowest = !isSimilar && globalMin != null && o.price === globalMin;
    card.className = `offer-card ${isLowest ? 'is-lowest' : ''}`;

    const diff = o.diff > 0 ? `+${fmtMoney(o.diff, currency)} (${o.pctAbove}%)` : 'Lowest price';

    // Rating & Delivery info
    const ratingHtml = o.rating ? `<span class="rating-pill">★ ${o.rating}</span>` : '';
    const reviewsHtml = o.reviewsCount ? `<span class="reviews-count">(${o.reviewsCount.toLocaleString()})</span>` : '';
    const deliveryHtml = o.deliveryInfo ? `<span class="delivery-badge">🚚 ${escapeHtml(o.deliveryInfo)}</span>` : '';

    // Original MRP and Discount
    let mrpHtml = '';
    if (o.originalPrice && o.originalPrice > o.price) {
      mrpHtml = `
        <div class="mrp-line">
          <span>MRP: <span class="mrp-strike">${fmtMoney(o.originalPrice, currency)}</span></span>
          <span class="mrp-discount">Save ${fmtMoney(o.originalPrice - o.price, currency)} (${o.discountPct || 10}% OFF)</span>
        </div>
      `;
    }

    // Active Bank / Promotional Offers list
    let offersHtml = '';
    const promoList = o.offers || [];
    if (promoList.length) {
      const firstOffer = promoList[0];
      const otherOffers = promoList.slice(1);
      offersHtml = `
        <div class="promo-offers-box">
          <div class="promo-offer-item" style="font-weight:600;">
            <span class="promo-icon">🏷️</span>
            <span>${escapeHtml(firstOffer)}</span>
          </div>
          ${otherOffers.length ? `
            <details style="margin-top:4px;">
              <summary style="font-size:11px;color:var(--accent-primary);cursor:pointer;font-weight:600;">+ ${otherOffers.length} more bank deals &amp; coupons</summary>
              <div class="promo-offers-list" style="margin-top:6px;">
                ${otherOffers.map(off => `<div class="promo-offer-item"><span class="promo-icon">💳</span><span>${escapeHtml(off)}</span></div>`).join('')}
              </div>
            </details>
          ` : ''}
        </div>
      `;
    }

    card.innerHTML = `
      <div>
        <div class="card-top-row">
          <span class="store-badge" style="background:${escapeHtml(o.storeColor)}1a;color:${escapeHtml(o.storeColor)};border:1px solid ${escapeHtml(o.storeColor)}40">
            ${escapeHtml(o.storeName)}
          </span>
          ${isLowest ? '<span class="lowest-pill">Lowest Price</span>' : ''}
          ${isSimilar ? '<span class="lowest-pill" style="background:var(--info);">Similar</span>' : ''}
        </div>

        <div class="card-rating-line">
          ${ratingHtml}
          ${reviewsHtml}
          ${deliveryHtml}
        </div>

        <a class="offer-title" href="${escapeHtml(o.url)}" target="_blank" rel="noopener noreferrer">${escapeHtml(o.title)}</a>
      </div>

      <div>
        <div class="offer-price-row">
          <div class="offer-pricing-group">
            <div class="offer-price">${fmtMoney(o.price, o.currency || currency)}</div>
            ${mrpHtml}
          </div>
          <span class="stock-status ${o.inStock ? 'in-stock' : 'out-of-stock'}">
            ${o.inStock ? 'In Stock' : 'Out of Stock'}
          </span>
        </div>

        ${offersHtml}

        <div class="offer-card-actions" style="margin-top:12px;">
          <a class="btn btn-secondary btn-sm" href="${escapeHtml(o.url)}" target="_blank" rel="noopener noreferrer">
            <span>Buy on ${escapeHtml(o.storeName)}</span>
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path><polyline points="15 3 21 3 21 9"></polyline><line x1="10" y1="14" x2="21" y2="3"></line></svg>
          </a>
          <button type="button" class="btn btn-primary btn-sm" data-track-btn>
            ${isAuthed ? '+ Track Deal' : 'Log in to Track'}
          </button>
        </div>
      </div>
    `;

    const trackBtn = card.querySelector('[data-track-btn]');
    trackBtn.addEventListener('click', async () => {
      if (!isAuthed) {
        openAuthModal('login');
        return;
      }
      trackBtn.disabled = true;
      trackBtn.textContent = 'Tracking…';
      try {
        const res = await authedFetch('/api/products', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            url: o.url,
            category: 'General',
            compare_stores: 1,
          }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Failed to track product');
        showToast(`Tracking started for ${o.storeName} listing!`, 'success');
        trackBtn.textContent = '✓ Tracked';
        loadProducts();
        loadStats();
      } catch (err) {
        showToast(err.message, 'error');
        trackBtn.disabled = false;
        trackBtn.textContent = '+ Track Deal';
      }
    });

    return card;
  }

  [fltStock, fltMax, fltSort].forEach((el) => {
    el.addEventListener('input', renderCompareResults);
  });

  refreshCompareBtn.addEventListener('click', () => {
    if (lastCompare) runCompare(lastCompare.request, { fresh: true });
  });

  copyBtn.addEventListener('click', () => {
    if (!lastCompare) return;
    const offers = getVisibleOffers();
    const txt = offers.map((o) => `${o.storeName}: ${fmtMoney(o.price, lastCompare.data.currency)} — ${o.url}`).join('\n');
    navigator.clipboard.writeText(txt).then(() => showToast('Summary copied to clipboard!', 'success'));
  });

  csvBtn.addEventListener('click', () => {
    if (!lastCompare) return;
    const offers = getVisibleOffers();
    const rows = offers.map((o) => [o.storeName, o.title, o.price, o.inStock ? 'Yes' : 'No', o.url]);
    const csvContent = 'data:text/csv;charset=utf-8,Store,Product,Price,InStock,URL\n' + rows.map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(',')).join('\n');
    const link = document.createElement('a');
    link.href = encodeURI(csvContent);
    link.download = `price-comparison-${Date.now()}.csv`;
    link.click();
  });

  // Global Header Search shortcut
  document.addEventListener('keydown', (e) => {
    if (e.key === '/' && document.activeElement.tagName !== 'INPUT' && document.activeElement.tagName !== 'TEXTAREA') {
      e.preventDefault();
      globalHeaderSearch.focus();
    } else if (e.key === 'Escape') {
      // Close all modals
      [addModal, editModal, historyModal, candidateModal, settingsModal, authModal].forEach((m) => (m.hidden = true));
    }
  });

  globalHeaderSearch.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      const q = globalHeaderSearch.value.trim();
      if (!q) return;
      showTab('compare');
      compareInput.value = q;
      clearCompareInput.hidden = false;
      runCompare({ query: q });
    }
  });

  // ==========================================================================
  // VIEW 2: WATCHLIST
  // ==========================================================================
  async function loadCategories() {
    if (!isAuthed) return;
    try {
      const res = await authedFetch('/api/categories');
      categories = await res.json();
      renderCategoryPills();
    } catch {
      categories = ['All'];
    }
  }

  function renderCategoryPills() {
    categoryPillsBar.innerHTML = '';
    categories.forEach((cat) => {
      const pill = document.createElement('button');
      pill.type = 'button';
      pill.className = `cat-pill ${cat === currentCategory ? 'on' : ''}`;
      pill.textContent = cat;
      pill.addEventListener('click', () => {
        currentCategory = cat;
        renderCategoryPills();
        loadProducts();
      });
      categoryPillsBar.appendChild(pill);
    });
  }

  async function loadProducts() {
    if (!isAuthed) return;
    try {
      let url = '/api/products?';
      if (currentCategory && currentCategory !== 'All') {
        url += `category=${encodeURIComponent(currentCategory)}&`;
      }
      if (listFilter.value.trim()) {
        url += `q=${encodeURIComponent(listFilter.value.trim())}&`;
      }
      if (listSort.value) {
        url += `sort=${encodeURIComponent(listSort.value)}&`;
      }

      const res = await authedFetch(url);
      products = await res.json();
      renderProducts();
    } catch {
      products = [];
      renderProducts();
    }
  }

  listFilter.addEventListener('input', debounce(() => loadProducts(), 300));
  listSort.addEventListener('change', () => loadProducts());

  function debounce(fn, wait) {
    let timeout;
    return (...args) => {
      clearTimeout(timeout);
      timeout = setTimeout(() => fn(...args), wait);
    };
  }

  function renderProducts() {
    productList.innerHTML = '';
    countLabel.textContent = `${products.length} item${products.length === 1 ? '' : 's'}`;
    watchlistCountBadge.textContent = products.length;
    watchlistCountBadge.hidden = products.length === 0;

    if (!products.length) {
      emptyState.hidden = false;
      return;
    }
    emptyState.hidden = true;

    products.forEach((p) => {
      const card = createProductCard(p);
      productList.appendChild(card);
    });
  }

  function createProductCard(p) {
    const card = document.createElement('div');
    card.className = 'product-card';

    const maxSeen = p.stats ? p.stats.max : null;
    const minSeen = p.stats ? p.stats.min : null;
    const isPriceDrop = p.current_price != null && maxSeen != null && p.current_price < maxSeen;
    const dropPct = isPriceDrop ? Math.round(((maxSeen - p.current_price) / maxSeen) * 100) : 0;

    // Target calculation
    let targetHtml = '';
    if (p.target_price != null && p.current_price != null) {
      const pct = Math.min(100, Math.max(10, Math.round((p.target_price / p.current_price) * 100)));
      const isReached = p.current_price <= p.target_price;
      targetHtml = `
        <div class="target-progress-wrap">
          <div class="target-labels">
            <span>Target: <strong>${fmtMoney(p.target_price, p.currency)}</strong></span>
            <span>${isReached ? '🎯 Target Reached!' : `${fmtMoney(p.current_price - p.target_price, p.currency)} away`}</span>
          </div>
          <div class="target-track">
            <div class="target-bar" style="width:${pct}%;background:${isReached ? 'var(--success)' : 'var(--accent-primary)'}"></div>
          </div>
        </div>
      `;
    }

    // Cross-store competitor deal callout
    let competitorHtml = '';
    if (p.best_other_price != null && p.current_price != null && p.best_other_price < p.current_price) {
      const saveAmount = p.current_price - p.best_other_price;
      competitorHtml = `
        <a class="competitor-deal-pill" href="${escapeHtml(p.best_other_url || '#')}" target="_blank" rel="noopener noreferrer">
          <span class="comp-left">⚡ Cheaper on ${escapeHtml(p.best_other_store || 'another store')}</span>
          <span class="comp-price">${fmtMoney(p.best_other_price, p.currency)} (Save ${fmtMoney(saveAmount, p.currency)})</span>
        </a>
      `;
    }

    // Product thumbnail
    const thumbHtml = p.image
      ? `<img src="${escapeHtml(p.image)}" alt="" class="product-thumb" onerror="this.onerror=null;this.parentElement.innerHTML='<span class=\\'product-thumb-placeholder\\'>📦</span>'" />`
      : `<span class="product-thumb-placeholder">📦</span>`;

    card.innerHTML = `
      <div>
        <div class="card-header-line">
          <span class="product-cat-tag">${escapeHtml(p.category || 'General')}</span>
          <span class="stock-status ${p.in_stock ? 'in-stock' : 'out-of-stock'}">
            ${p.in_stock ? 'In Stock' : 'Out of Stock'}
          </span>
        </div>

        <div class="product-body-row">
          <div class="product-thumb-wrap">${thumbHtml}</div>
          <div class="product-details">
            <a class="product-name-link" href="${escapeHtml(p.url)}" target="_blank" rel="noopener noreferrer" title="${escapeHtml(p.name || p.url)}">
              ${escapeHtml(p.name || p.url)}
            </a>
            <div class="product-pricing-box">
              <span class="current-price">${fmtMoney(p.current_price, p.currency)}</span>
              ${isPriceDrop ? `<span class="highest-price-strike">${fmtMoney(maxSeen, p.currency)}</span>` : ''}
              ${dropPct > 0 ? `<span class="discount-badge">-${dropPct}%</span>` : ''}
            </div>
          </div>
        </div>

        ${p.sparkline && p.sparkline.length > 1 ? `<div class="sparkline-box">${sparklineSvg(p.sparkline)}</div>` : ''}
        ${targetHtml}
        ${competitorHtml}
      </div>

      <div class="card-actions-row">
        <span class="recheck-info">Checked ${timeAgo(p.last_checked_at)}</span>
        <div class="action-icons-wrap">
          <button class="action-icon-btn" data-action="refresh" title="Recheck price now">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 4 23 10 17 10"></polyline><polyline points="1 20 1 14 7 14"></polyline><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path></svg>
          </button>
          <button class="action-icon-btn" data-action="chart" title="Price history chart">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="20" x2="18" y2="10"></line><line x1="12" y1="20" x2="12" y2="4"></line><line x1="6" y1="20" x2="6" y2="14"></line></svg>
          </button>
          <button class="action-icon-btn" data-action="edit" title="Edit target & settings">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 20h9"></path><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"></path></svg>
          </button>
          <button class="action-icon-btn danger" data-action="delete" title="Stop tracking">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
          </button>
        </div>
      </div>
    `;

    // Action handlers
    card.querySelector('[data-action="refresh"]').addEventListener('click', async (e) => {
      const btn = e.currentTarget;
      btn.classList.add('spinning');
      try {
        await authedFetch(`/api/products/${p.id}/refresh`, { method: 'POST' });
        showToast('Price refreshed successfully!', 'success');
        loadProducts();
        loadStats();
      } catch (err) {
        showToast(err.message, 'error');
      } finally {
        btn.classList.remove('spinning');
      }
    });

    card.querySelector('[data-action="chart"]').addEventListener('click', () => {
      openHistoryModal(p);
    });

    card.querySelector('[data-action="edit"]').addEventListener('click', () => {
      openEditModal(p);
    });

    card.querySelector('[data-action="delete"]').addEventListener('click', async () => {
      if (!confirm(`Stop tracking “${p.name || 'this product'}”?`)) return;
      try {
        await authedFetch(`/api/products/${p.id}`, { method: 'DELETE' });
        showToast('Product removed from watchlist.', 'info');
        loadProducts();
        loadStats();
      } catch (err) {
        showToast(err.message, 'error');
      }
    });

    return card;
  }

  // Add Product Modal
  openAddModalBtn.addEventListener('click', () => {
    addError.hidden = true;
    urlInput.value = '';
    targetInput.value = '';
    notesInput.value = '';
    addModal.hidden = false;
    urlInput.focus();
  });
  emptyAddBtn.addEventListener('click', () => openAddModalBtn.click());
  closeAddModalBtn.addEventListener('click', () => (addModal.hidden = true));
  cancelAddBtn.addEventListener('click', () => (addModal.hidden = true));

  // Quick discount calculation buttons
  document.querySelectorAll('.target-quick-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
      const disc = Number(btn.dataset.discount);
      const curr = Number(targetInput.value) || 1000;
      targetInput.value = (curr * (1 - disc / 100)).toFixed(0);
    });
  });

  addForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    addError.hidden = true;
    addBtn.disabled = true;
    const origText = addBtn.innerHTML;
    addBtn.innerHTML = `<span>Scanning page…</span>`;

    try {
      const res = await authedFetch('/api/products', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          url: urlInput.value.trim(),
          target_price: targetInput.value ? Number(targetInput.value) : null,
          category: categoryInput.value,
          check_interval_minutes: Number(intervalInput.value),
          alert_email: alertEmailInput2.value.trim() || null,
          notes: notesInput.value.trim() || null,
          compare_stores: watchStoresInput.checked ? 1 : 0,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to add product');

      addModal.hidden = true;
      showToast(`Now tracking: ${data.name || 'Product'}`, 'success');
      loadProducts();
      loadStats();
      loadCategories();

      // If multiple candidates found, prompt user to pick
      if (data.last_candidates && data.last_candidates.length > 1) {
        openCandidateModal(data);
      }
    } catch (err) {
      addError.textContent = err.message;
      addError.hidden = false;
    } finally {
      addBtn.disabled = false;
      addBtn.innerHTML = origText;
    }
  });

  // Edit Product Modal
  function openEditModal(p) {
    editProductId.value = p.id;
    editNameInput.value = p.name || '';
    editTargetInput.value = p.target_price || '';
    editCategoryInput.value = p.category || 'General';
    editIntervalInput.value = p.check_interval_minutes || 60;
    editAlertEmailInput.value = p.alert_email || '';
    editNotesInput.value = p.notes || '';
    editCompareStoresInput.checked = !!p.compare_stores;
    editModal.hidden = false;
  }
  closeEditModalBtn.addEventListener('click', () => (editModal.hidden = true));
  cancelEditBtn.addEventListener('click', () => (editModal.hidden = true));

  editForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const id = editProductId.value;
    try {
      const res = await authedFetch(`/api/products/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: editNameInput.value.trim(),
          target_price: editTargetInput.value ? Number(editTargetInput.value) : null,
          category: editCategoryInput.value.trim() || 'General',
          check_interval_minutes: Number(editIntervalInput.value),
          alert_email: editAlertEmailInput.value.trim() || null,
          notes: editNotesInput.value.trim() || null,
          compare_stores: editCompareStoresInput.checked ? 1 : 0,
        }),
      });
      if (!res.ok) throw new Error('Update failed');
      editModal.hidden = true;
      showToast('Product settings updated!', 'success');
      loadProducts();
      loadCategories();
    } catch (err) {
      showToast(err.message, 'error');
    }
  });

  // History Modal
  async function openHistoryModal(p) {
    historyTitle.textContent = p.name || 'Product History';
    historySub.textContent = `Tracking started on ${formatDateShort(p.created_at)}`;
    historyChart.innerHTML = '<div class="pulsing-spinner" style="margin:20px auto;"></div>';
    historyTableBody.innerHTML = '';
    historyStatsBar.innerHTML = '';
    historyModal.hidden = false;

    try {
      const res = await authedFetch(`/api/products/${p.id}`);
      const data = await res.json();
      const hist = data.history || [];

      if (hist.length) {
        const prices = hist.map((h) => h.price);
        const minP = Math.min(...prices);
        const maxP = Math.max(...prices);
        const avgP = prices.reduce((a, b) => a + b, 0) / prices.length;
        const currP = hist[hist.length - 1].price;

        historyStatsBar.innerHTML = `
          <div class="stat-pill-box">
            <div class="stat-pill-label">Current Price</div>
            <div class="stat-pill-val">${fmtMoney(currP, p.currency)}</div>
          </div>
          <div class="stat-pill-box">
            <div class="stat-pill-label">Lowest Seen</div>
            <div class="stat-pill-val" style="color:var(--success)">${fmtMoney(minP, p.currency)}</div>
          </div>
          <div class="stat-pill-box">
            <div class="stat-pill-label">Highest Seen</div>
            <div class="stat-pill-val" style="color:var(--danger)">${fmtMoney(maxP, p.currency)}</div>
          </div>
          <div class="stat-pill-box">
            <div class="stat-pill-label">Average</div>
            <div class="stat-pill-val">${fmtMoney(avgP, p.currency)}</div>
          </div>
        `;

        historyChart.innerHTML = historyLineChartSvg(hist, p.currency);

        hist.slice().reverse().forEach((h, idx, arr) => {
          const next = arr[idx + 1];
          let diffHtml = '—';
          if (next) {
            const diff = h.price - next.price;
            if (diff < 0) diffHtml = `<span style="color:var(--success)">${fmtMoney(diff, p.currency)}</span>`;
            else if (diff > 0) diffHtml = `<span style="color:var(--danger)">+${fmtMoney(diff, p.currency)}</span>`;
          }

          const tr = document.createElement('tr');
          tr.innerHTML = `
            <td>${formatDateShort(h.checked_at)}</td>
            <td style="font-family:var(--font-mono);font-weight:700;">${fmtMoney(h.price, p.currency)}</td>
            <td><span class="stock-status ${h.in_stock ? 'in-stock' : 'out-of-stock'}">${h.in_stock ? 'In Stock' : 'Out of Stock'}</span></td>
            <td style="font-family:var(--font-mono);">${diffHtml}</td>
          `;
          historyTableBody.appendChild(tr);
        });
      } else {
        historyChart.innerHTML = `<p class="sub" style="text-align:center;margin:30px 0;">No check logs recorded yet.</p>`;
      }
    } catch (err) {
      historyChart.innerHTML = `<p class="error">${err.message}</p>`;
    }
  }
  historyClose.addEventListener('click', () => (historyModal.hidden = true));
  historyCloseBtn.addEventListener('click', () => (historyModal.hidden = true));

  // Multiple candidates picker modal
  function openCandidateModal(p) {
    selectedCandidateProduct = p;
    candidateList.innerHTML = '';
    candidateModal.hidden = false;

    (p.last_candidates || []).forEach((c) => {
      const li = document.createElement('li');
      li.className = 'candidate-item';
      li.innerHTML = `
        <div>
          <div style="font-weight:700;font-size:16px;font-family:var(--font-mono);">${fmtMoney(c.value, c.currency || p.currency)}</div>
          <div style="font-size:12px;color:var(--text-muted);">${(c.sources || [c.source]).join(', ')}</div>
        </div>
        <button class="btn btn-secondary btn-sm">Select Price</button>
      `;
      li.querySelector('button').addEventListener('click', async () => {
        await authedFetch(`/api/products/${p.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ current_price: c.value }),
        });
        candidateModal.hidden = true;
        showToast(`Selected price: ${fmtMoney(c.value, p.currency)}`, 'success');
        loadProducts();
      });
      candidateList.appendChild(li);
    });
  }
  candidateCloseX.addEventListener('click', () => (candidateModal.hidden = true));
  candidateCancel.addEventListener('click', () => (candidateModal.hidden = true));

  // ==========================================================================
  // VIEW 3: DEALS & DROPS
  // ==========================================================================
  async function loadDeals() {
    dealsGrid.innerHTML = '<div class="pulsing-spinner" style="margin:40px auto;grid-column:1/-1;"></div>';
    try {
      const res = await fetch('/api/deals');
      const deals = await res.json();
      if (!deals || !deals.length) {
        dealsGrid.innerHTML = `
          <div class="empty-state-card" style="grid-column:1/-1;">
            <div class="empty-icon">🔥</div>
            <h3>No active price drops right now</h3>
            <p>As retailers discount products on your watchlist, they will appear here with savings calculations!</p>
          </div>
        `;
        return;
      }

      dealsGrid.innerHTML = '';
      deals.forEach((d) => {
        const card = document.createElement('div');
        card.className = 'product-card';
        card.innerHTML = `
          <div>
            <div class="card-header-line">
              <span class="product-cat-tag">${escapeHtml(d.category || 'Deal')}</span>
              ${d.isAllTimeLow ? '<span class="lowest-pill">⭐ All-Time Low</span>' : ''}
            </div>

            <div class="product-body-row">
              <div class="product-thumb-wrap">
                ${d.image ? `<img src="${escapeHtml(d.image)}" alt="" class="product-thumb" />` : '<span class="product-thumb-placeholder">🏷️</span>'}
              </div>
              <div class="product-details">
                <a class="product-name-link" href="${escapeHtml(d.url)}" target="_blank" rel="noopener noreferrer">${escapeHtml(d.name || d.url)}</a>
                <div class="product-pricing-box">
                  <span class="current-price" style="color:var(--success);">${fmtMoney(d.current_price, d.currency)}</span>
                  ${d.highest_seen ? `<span class="highest-price-strike">${fmtMoney(d.highest_seen, d.currency)}</span>` : ''}
                  ${d.dropPercent > 0 ? `<span class="discount-badge">-${d.dropPercent}% OFF</span>` : ''}
                </div>
              </div>
            </div>

            ${d.sparkline && d.sparkline.length > 1 ? `<div class="sparkline-box">${sparklineSvg(d.sparkline)}</div>` : ''}
          </div>

          <div class="card-actions-row">
            <span class="recheck-info">Save ${fmtMoney(d.dropAmount, d.currency)}</span>
            <a class="btn btn-primary btn-sm" href="${escapeHtml(d.url)}" target="_blank" rel="noopener noreferrer">
              <span>View Deal</span>
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path><polyline points="15 3 21 3 21 9"></polyline><line x1="10" y1="14" x2="21" y2="3"></line></svg>
            </a>
          </div>
        `;
        dealsGrid.appendChild(card);
      });
    } catch (err) {
      dealsGrid.innerHTML = `<p class="error" style="grid-column:1/-1;">${err.message}</p>`;
    }
  }

  refreshDealsBtn.addEventListener('click', loadDeals);

  // ==========================================================================
  // VIEW 4: INSTANT INSPECTOR
  // ==========================================================================
  demoForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    demoMsg.hidden = true;
    demoChart.hidden = true;
    demoBtn.disabled = true;
    const origText = demoBtn.innerHTML;
    demoBtn.innerHTML = `<span>Inspecting page selectors…</span>`;

    try {
      const res = await fetch('/api/demo-check', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          url: demoUrlInput.value.trim(),
          email: demoEmailInput.value.trim() || undefined,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Inspection failed');

      demoMsg.className = 'alert-box alert-success';
      demoMsg.innerHTML = `
        <div>
          <strong>Extracted Price: ${fmtMoney(data.price, data.currency)}</strong>
          <div>${escapeHtml(data.name || 'Product Page')} · ${data.inStock ? 'In Stock' : 'Out of Stock'}</div>
          ${data.emailSent ? `<div style="margin-top:4px;color:var(--text-muted);">📧 Email report dispatched to ${escapeHtml(demoEmailInput.value)}</div>` : ''}
        </div>
      `;
      demoMsg.hidden = false;

      if (data.candidates && data.candidates.length) {
        demoChart.hidden = false;
        demoChart.innerHTML = `
          <div style="font-size:12px;font-weight:700;margin-bottom:8px;color:var(--text-muted);">Method Confidence &amp; Voting Breakdown:</div>
          ${candidateBarChartSvg(data.candidates, data.currency)}
        `;
      }
    } catch (err) {
      demoMsg.className = 'alert-box alert-error';
      demoMsg.textContent = err.message;
      demoMsg.hidden = false;
    } finally {
      demoBtn.disabled = false;
      demoBtn.innerHTML = origText;
    }
  });

  // ==========================================================================
  // SETTINGS & PROFILE MODAL
  // ==========================================================================
  openSettingsItem.addEventListener('click', async () => {
    userDropdown.hidden = true;
    settingsMsg.hidden = true;
    settingsModal.hidden = false;

    // Load settings
    try {
      const res = await authedFetch('/api/settings');
      const settings = await res.json();
      webhookInput.value = settings.discord_webhook_url || '';
      tgTokenInput.value = settings.telegram_bot_token || '';
      tgChatInput.value = settings.telegram_chat_id || '';
      brevoKeyInput.value = settings.brevo_api_key || '';
      brevoSenderInput.value = settings.brevo_sender_email || '';
      alertEmailInput.value = settings.alert_email || '';

      if (currentUser) {
        profileEmailInput.value = currentUser.email || '';
      }
    } catch {}
  });

  // Settings tab switch
  document.querySelectorAll('.settings-tab-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.settings-tab-btn').forEach((b) => b.classList.remove('on'));
      btn.classList.add('on');
      const sect = btn.dataset.sect;
      document.getElementById('sectWebhooks').hidden = sect !== 'webhooks';
      document.getElementById('sectProfile').hidden = sect !== 'profile';
    });
  });

  settingsCloseX.addEventListener('click', () => (settingsModal.hidden = true));
  settingsCancel.addEventListener('click', () => (settingsModal.hidden = true));

  settingsSave.addEventListener('click', async () => {
    settingsMsg.hidden = true;
    try {
      // Save global alerts settings
      await authedFetch('/api/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          discord_webhook_url: webhookInput.value.trim(),
          telegram_bot_token: tgTokenInput.value.trim(),
          telegram_chat_id: tgChatInput.value.trim(),
          brevo_api_key: brevoKeyInput.value.trim(),
          brevo_sender_email: brevoSenderInput.value.trim(),
          alert_email: alertEmailInput.value.trim(),
        }),
      });

      // Save profile if updated
      if (profileEmailInput.value.trim() || profilePasswordInput.value) {
        await authedFetch('/api/profile', {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            email: profileEmailInput.value.trim(),
            password: profilePasswordInput.value || undefined,
          }),
        });
      }

      settingsModal.hidden = true;
      showToast('Alert channels and settings saved!', 'success');
      await checkAuth();
    } catch (err) {
      settingsMsg.className = 'alert-box alert-error';
      settingsMsg.textContent = err.message;
      settingsMsg.hidden = false;
    }
  });

  testAlertBtn.addEventListener('click', async () => {
    testAlertBtn.disabled = true;
    testAlertBtn.textContent = 'Dispatching test…';
    settingsMsg.hidden = true;
    try {
      // First persist settings so test alert picks them up
      await authedFetch('/api/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          discord_webhook_url: webhookInput.value.trim(),
          telegram_bot_token: tgTokenInput.value.trim(),
          telegram_chat_id: tgChatInput.value.trim(),
          brevo_api_key: brevoKeyInput.value.trim(),
          brevo_sender_email: brevoSenderInput.value.trim(),
          alert_email: alertEmailInput.value.trim(),
        }),
      });

      const res = await authedFetch('/api/settings/test-alert', { method: 'POST' });
      if (!res.ok) throw new Error('Test alert failed');

      settingsMsg.className = 'alert-box alert-success';
      settingsMsg.textContent = 'Test ping dispatched! Check your Discord channel, Telegram chat, or Email inbox.';
      settingsMsg.hidden = false;
    } catch (err) {
      settingsMsg.className = 'alert-box alert-error';
      settingsMsg.textContent = err.message;
      settingsMsg.hidden = false;
    } finally {
      testAlertBtn.disabled = false;
      testAlertBtn.textContent = 'Send Test Alert';
    }
  });

  // ==========================================================================
  // INITIALIZATION
  // ==========================================================================
  initTheme();
  loadCapabilities();
  loadStores();
  loadSearchHistory();
  checkAuth();

  // URL hash routing
  const initialHash = location.hash.slice(1) || 'compare';
  showTab(initialHash);

  // Background refresh timer for status pill
  setInterval(() => {
    if (refreshAgo) {
      refreshAgo.textContent = 'Live Sync';
    }
  }, 30000);
})();
