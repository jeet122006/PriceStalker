(() => {
  "use strict";

  const canvas = document.createElement("canvas");
  const ctx = canvas.getContext("2d", { alpha: true });
  if (!ctx || !document.body) return;

  canvas.id = "priceghost-motion-background";
  canvas.setAttribute("aria-hidden", "true");
  document.body.prepend(canvas);
  document.body.classList.add("motion-bg-active");

  const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)");
  const pointer = { x: 0, y: 0 };
  const smoothPointer = { x: 0, y: 0 };
  const startedAt = performance.now();
  const particles = [];
  let width = 0;
  let height = 0;
  let pixelRatio = 1;
  let frameId = 0;
  let visible = !document.hidden;

  function seedParticles() {
    particles.length = 0;
    const count = width < 600 ? 30 : 58;
    for (let i = 0; i < count; i++) {
      particles.push({
        x: Math.random(),
        y: Math.random(),
        depth: 0.25 + Math.random() * 0.75,
        phase: Math.random() * Math.PI * 2,
        speed: 0.002 + Math.random() * 0.007,
        size: 0.45 + Math.random() * 1.05,
        cyan: Math.random() > 0.66,
      });
    }
  }

  function resize() {
    width = window.innerWidth;
    height = window.innerHeight;
    const pixelBudgetRatio = Math.sqrt(2600000 / Math.max(width * height, 1));
    pixelRatio = Math.min(window.devicePixelRatio || 1, 1.3, pixelBudgetRatio);
    canvas.width = Math.max(1, Math.round(width * pixelRatio));
    canvas.height = Math.max(1, Math.round(height * pixelRatio));
    ctx.setTransform(pixelRatio, 0, 0, pixelRatio, 0, 0);
    seedParticles();
    draw(performance.now());
  }

  function drawAtmosphere(time, progress) {
    const parallaxX = smoothPointer.x * Math.min(width * 0.018, 22);
    const parallaxY = smoothPointer.y * Math.min(height * 0.018, 18);
    const glowX = width * 0.73 - parallaxX;
    const glowY = height * 0.26 - parallaxY + Math.sin(time * 0.00012) * 12;
    const radius = Math.max(width, height) * 0.62;

    const field = ctx.createRadialGradient(glowX, glowY, 0, glowX, glowY, radius);
    field.addColorStop(0, "rgba(86, 81, 183, 0.12)");
    field.addColorStop(0.36, "rgba(55, 94, 160, 0.075)");
    field.addColorStop(0.72, "rgba(24, 79, 114, 0.025)");
    field.addColorStop(1, "rgba(5, 8, 18, 0)");
    ctx.globalAlpha = progress;
    ctx.fillStyle = field;
    ctx.fillRect(0, 0, width, height);

    const lowerGlow = ctx.createRadialGradient(
      width * 0.18 + parallaxX * 0.55,
      height * 0.76 + parallaxY * 0.5,
      0,
      width * 0.18 + parallaxX * 0.55,
      height * 0.76 + parallaxY * 0.5,
      Math.min(width, height) * 0.56
    );
    lowerGlow.addColorStop(0, "rgba(20, 139, 159, 0.075)");
    lowerGlow.addColorStop(0.55, "rgba(31, 90, 145, 0.035)");
    lowerGlow.addColorStop(1, "rgba(10, 20, 40, 0)");
    ctx.fillStyle = lowerGlow;
    ctx.fillRect(0, 0, width, height);
    ctx.globalAlpha = 1;
  }

  function drawLightRibbons(time, progress) {
    const motion = time * 0.00011;
    const pointerY = smoothPointer.y * Math.min(height * 0.025, 24);
    const pointerX = smoothPointer.x * Math.min(width * 0.025, 26);
    const startX = -width * 0.08 - pointerX;
    const endX = width * 1.08 - pointerX;
    const span = endX - startX;
    const palette = [
      ["rgba(133, 103, 239, 0.11)", "rgba(81, 128, 231, 0.16)", "rgba(48, 205, 215, 0.08)"],
      ["rgba(81, 113, 231, 0.07)", "rgba(112, 107, 235, 0.12)", "rgba(67, 199, 220, 0.11)"],
      ["rgba(66, 190, 216, 0.045)", "rgba(97, 126, 235, 0.10)", "rgba(165, 113, 238, 0.055)"],
    ];

    ctx.save();
    ctx.globalAlpha = progress;
    ctx.globalCompositeOperation = "screen";
    ctx.lineCap = "round";

    for (let layer = 0; layer < palette.length; layer++) {
      const phase = motion + layer * 1.72;
      const base = height * (0.3 + layer * 0.105);
      const amplitude = Math.min(height * 0.14, 118);
      const y1 = base + Math.sin(phase) * amplitude + pointerY * (0.24 + layer * 0.12);
      const y2 = height * (0.66 - layer * 0.1) + Math.cos(phase * 0.82 + 1) * amplitude;
      const y3 = height * (0.25 + layer * 0.15) + Math.sin(phase * 0.7 + 2.4) * amplitude * 0.82;
      const gradient = ctx.createLinearGradient(startX, y1, endX, y3);
      gradient.addColorStop(0, palette[layer][0]);
      gradient.addColorStop(0.49, palette[layer][1]);
      gradient.addColorStop(1, palette[layer][2]);

      ctx.beginPath();
      ctx.moveTo(startX, y1);
      ctx.bezierCurveTo(
        width * 0.28,
        y1 - amplitude * (0.7 + Math.sin(phase) * 0.18),
        width * 0.46,
        y2 + amplitude * 0.7,
        width * 0.6,
        y2
      );
      ctx.bezierCurveTo(
        width * 0.78,
        y2 - amplitude * 0.68,
        width * 0.88,
        y3 + amplitude * 0.82,
        endX,
        y3
      );
      ctx.strokeStyle = gradient;
      ctx.lineWidth = Math.max(5, Math.min(width, height) * (layer === 1 ? 0.022 : 0.015));
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(startX, y1);
      ctx.bezierCurveTo(
        width * 0.28,
        y1 - amplitude * (0.7 + Math.sin(phase) * 0.18),
        width * 0.46,
        y2 + amplitude * 0.7,
        width * 0.6,
        y2
      );
      ctx.bezierCurveTo(
        width * 0.78,
        y2 - amplitude * 0.68,
        width * 0.88,
        y3 + amplitude * 0.82,
        endX,
        y3
      );
      ctx.strokeStyle = gradient;
      ctx.globalAlpha = progress * 0.56;
      ctx.lineWidth = 0.8 + layer * 0.18;
      ctx.stroke();
      ctx.globalAlpha = progress;
    }
    ctx.restore();
  }

  function drawParticles(time, progress) {
    const pointerShiftX = smoothPointer.x * Math.min(width * 0.025, 26);
    const pointerShiftY = smoothPointer.y * Math.min(height * 0.025, 22);

    ctx.save();
    ctx.globalCompositeOperation = "screen";
    for (const particle of particles) {
      const drift = (time - startedAt) * particle.speed;
      const x = (particle.x * width + Math.sin(time * 0.00018 + particle.phase) * 12 * particle.depth
        - pointerShiftX * particle.depth + width * 2) % width;
      const y = (particle.y * height - drift - pointerShiftY * particle.depth + height * 3) % height;
      const twinkle = 0.36 + (Math.sin(time * 0.0012 + particle.phase) + 1) * 0.2;
      const opacity = progress * twinkle * (particle.cyan ? 0.52 : 0.4);
      const radius = particle.size * particle.depth;

      ctx.beginPath();
      ctx.fillStyle = particle.cyan
        ? `rgba(115, 228, 237, ${opacity})`
        : `rgba(190, 173, 255, ${opacity})`;
      ctx.arc(x, y, radius, 0, Math.PI * 2);
      ctx.fill();

      if (particle.size > 1.15 && particle.depth > 0.68) {
        ctx.beginPath();
        ctx.fillStyle = particle.cyan
          ? `rgba(104, 210, 232, ${opacity * 0.12})`
          : `rgba(153, 144, 237, ${opacity * 0.12})`;
        ctx.arc(x, y, radius * 5, 0, Math.PI * 2);
        ctx.fill();
      }
    }
    ctx.restore();
  }

  function draw(now) {
    ctx.clearRect(0, 0, width, height);
    const intro = Math.min(1, (now - startedAt) / 1350);
    const progress = 1 - Math.pow(1 - intro, 3);
    const follow = reducedMotion.matches ? 1 : 0.035;
    smoothPointer.x += (pointer.x - smoothPointer.x) * follow;
    smoothPointer.y += (pointer.y - smoothPointer.y) * follow;

    drawAtmosphere(now, progress);
    drawLightRibbons(now, progress);
    drawParticles(now, progress);

    if (!reducedMotion.matches && visible) {
      frameId = window.requestAnimationFrame(draw);
    }
  }

  function onPointerMove(event) {
    if (event.pointerType === "touch") return;
    pointer.x = (event.clientX / Math.max(width, 1) - 0.5) * 2;
    pointer.y = (event.clientY / Math.max(height, 1) - 0.5) * 2;
  }

  function onVisibilityChange() {
    visible = !document.hidden;
    if (frameId) window.cancelAnimationFrame(frameId);
    frameId = 0;
    if (visible && !reducedMotion.matches) {
      frameId = window.requestAnimationFrame(draw);
    } else {
      draw(performance.now());
    }
  }

  window.addEventListener("resize", resize, { passive: true });
  window.addEventListener("pointermove", onPointerMove, { passive: true });
  document.addEventListener("visibilitychange", onVisibilityChange);

  const onMotionPreferenceChange = () => {
    if (frameId) window.cancelAnimationFrame(frameId);
    frameId = 0;
    if (!reducedMotion.matches && visible) {
      frameId = window.requestAnimationFrame(draw);
    } else {
      draw(performance.now());
    }
  };
  if (reducedMotion.addEventListener) {
    reducedMotion.addEventListener("change", onMotionPreferenceChange);
  } else {
    reducedMotion.addListener(onMotionPreferenceChange);
  }

  resize();
  if (!reducedMotion.matches && visible) {
    frameId = window.requestAnimationFrame(draw);
  }
})();
