const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const session = require('express-session');
const db = require('./db');

function getSetting(key) {
  const row = db.prepare('SELECT value FROM settings WHERE key = ?').get(key);
  return row ? row.value : null;
}

function setSetting(key, value) {
  db.prepare(
    'INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value'
  ).run(key, value);
}

// Ensures at least one admin exists in the users table and settings
function ensureAdminUser() {
  const envUser = process.env.ADMIN_USERNAME || 'admin';
  const envPass = process.env.ADMIN_PASSWORD;
  const existingSettingHash = getSetting('auth_password_hash');

  const existingUser = db.prepare('SELECT * FROM users WHERE username = ?').get(envUser);

  if (envPass) {
    const hash = bcrypt.hashSync(envPass, 10);
    setSetting('auth_username', envUser);
    setSetting('auth_password_hash', hash);
    if (existingUser) {
      db.prepare("UPDATE users SET password_hash = ?, role = 'admin' WHERE id = ?").run(hash, existingUser.id);
    } else {
      db.prepare("INSERT INTO users (username, password_hash, email, role) VALUES (?, ?, ?, 'admin')").run(
        envUser,
        hash,
        'admin@priceghost.local'
      );
    }
    return;
  }

  if (!existingSettingHash && !existingUser) {
    const defaultPassword = 'admin123';
    const hash = bcrypt.hashSync(defaultPassword, 10);
    setSetting('auth_username', envUser);
    setSetting('auth_password_hash', hash);
    db.prepare("INSERT INTO users (username, password_hash, email, role) VALUES (?, ?, ?, 'admin')").run(
      envUser,
      hash,
      'admin@priceghost.local'
    );
    console.log('\n============================================================');
    console.log(' PriceGhost Admin account initialized:');
    console.log(`   Username: ${envUser}`);
    console.log(`   Password: ${defaultPassword}`);
    console.log(' (Change in docker-compose.yml or UI profile settings)');
    console.log('============================================================\n');
  } else if (!existingUser && existingSettingHash) {
    db.prepare("INSERT INTO users (username, password_hash, email, role) VALUES (?, ?, ?, 'admin')").run(
      envUser,
      existingSettingHash,
      'admin@priceghost.local'
    );
  }
}

function registerUser(username, password, email) {
  const cleanUser = String(username || '').trim();
  const cleanPass = String(password || '');
  const cleanEmail = String(email || '').trim().toLowerCase();

  if (!cleanUser || cleanUser.length < 3 || cleanUser.length > 32) {
    throw new Error('Username must be between 3 and 32 characters.');
  }
  if (!/^[a-zA-Z0-9_\-\.]+$/.test(cleanUser)) {
    throw new Error('Username can only contain letters, numbers, dots, and hyphens.');
  }
  if (!cleanPass || cleanPass.length < 6) {
    throw new Error('Password must be at least 6 characters.');
  }
  if (cleanEmail && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
    throw new Error('Invalid email address format.');
  }

  const existing = db.prepare('SELECT id FROM users WHERE LOWER(username) = LOWER(?) OR (email IS NOT NULL AND LOWER(email) = ?)').get(cleanUser, cleanEmail || '__none__');
  if (existing) {
    throw new Error('A user with that username or email already exists.');
  }

  const hash = bcrypt.hashSync(cleanPass, 10);
  const info = db.prepare(
    "INSERT INTO users (username, password_hash, email, role) VALUES (?, ?, ?, 'user')"
  ).run(cleanUser, hash, cleanEmail || null);

  return db.prepare('SELECT id, username, email, role, created_at FROM users WHERE id = ?').get(info.lastInsertRowid);
}

function verifyLogin(username, password) {
  if (!username || !password) return null;
  const cleanUser = String(username).trim();

  // Try user table first
  let user = db.prepare('SELECT * FROM users WHERE LOWER(username) = LOWER(?) OR LOWER(email) = LOWER(?)').get(cleanUser, cleanUser);

  if (user) {
    if (bcrypt.compareSync(password, user.password_hash)) {
      return { id: user.id, username: user.username, email: user.email, role: user.role };
    }
    return null;
  }

  // Fallback to legacy settings table admin
  const storedUser = getSetting('auth_username');
  const storedHash = getSetting('auth_password_hash');
  if (storedUser && storedHash && cleanUser === storedUser) {
    if (bcrypt.compareSync(password, storedHash)) {
      // Sync into users table if missing
      let adminRow = db.prepare('SELECT * FROM users WHERE username = ?').get(storedUser);
      if (!adminRow) {
        const info = db.prepare("INSERT INTO users (username, password_hash, role) VALUES (?, ?, 'admin')").run(storedUser, storedHash);
        adminRow = db.prepare('SELECT * FROM users WHERE id = ?').get(info.lastInsertRowid);
      }
      return { id: adminRow.id, username: adminRow.username, email: adminRow.email, role: adminRow.role };
    }
  }

  return null;
}

function sessionMiddleware() {
  const secret =
    process.env.SESSION_SECRET || getSetting('session_secret') || (() => {
      const generated = crypto.randomBytes(32).toString('hex');
      setSetting('session_secret', generated);
      return generated;
    })();
  return session({
    secret,
    name: 'priceghost.sid',
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      sameSite: 'lax',
      maxAge: 14 * 24 * 60 * 60 * 1000, // 14 days
    },
  });
}

function requireAuth(req, res, next) {
  if (req.session && req.session.authed && req.session.userId) return next();
  return res.status(401).json({ error: 'Not logged in.' });
}

module.exports = {
  ensureAdminUser,
  registerUser,
  verifyLogin,
  sessionMiddleware,
  requireAuth,
  getSetting,
  setSetting,
};
