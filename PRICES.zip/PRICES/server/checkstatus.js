const db = require('./db');

/**
 * Per-product "last check" status, kept in the existing key/value `settings` table
 * (key: "check_status:<productId>") so no schema change is needed.
 *
 *   { state: 'unavailable' | 'no_price', message, kind, at }
 *
 * No row means the last check succeeded (or the product was never checked).
 */
const PREFIX = 'check_status:';

const get = db.prepare('SELECT value FROM settings WHERE key = ?');
const put = db.prepare('INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value');
const del = db.prepare('DELETE FROM settings WHERE key = ?');

function getCheckStatus(productId) {
  const row = get.get(PREFIX + productId);
  if (!row) return null;
  try {
    return JSON.parse(row.value);
  } catch {
    return null;
  }
}

function setCheckStatus(productId, { state, message, kind }) {
  put.run(PREFIX + productId, JSON.stringify({ state, message, kind: kind || null, at: new Date().toISOString() }));
}

function clearCheckStatus(productId) {
  del.run(PREFIX + productId);
}

module.exports = { getCheckStatus, setCheckStatus, clearCheckStatus, PREFIX };
