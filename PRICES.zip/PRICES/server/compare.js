const fs = require('fs');
const path = require('path');
const { STORES, STORE_MAP, storeForUrl } = require('./stores');
const { extractPrice } = require('./scraper');
const { fetchHtml, classifyResponse } = require('./fetcher');

const CACHE_TTL_MS = 10 * 60 * 1000;
const OFFERS_PER_STORE = 3;

// ---------------------------------------------------------------------------------------
// Query handling
// ---------------------------------------------------------------------------------------

const COLORS = new Set(
  ('black white blue green red pink yellow silver gold grey gray purple orange violet graphite midnight starlight ' +
    'titanium natural cream lavender mint teal beige brown bronze copper rose coral maroon navy').split(' ')
);

/**
 * Turn a scraped page title ("Apple iPhone 15 (128 GB) - Black : Amazon.in: Electronics")
 * into a search query other stores will understand. Removes store names, marketing
 * phrases and colour words (colours differ between listings of the same product).
 */
function cleanQuery(name, maxWords = 9) {
  let s = String(name || '');
  s = s.split(/\s:\s|\s\|\s|\s[-–—]\s*(?=(?:buy|amazon|flipkart|croma|snapdeal|reliance|online))/i)[0];
  s = s.replace(/\b(amazon\.in|flipkart(\.com)?|snapdeal|croma|reliance digital)\b/gi, ' ');
  s = s.replace(/^\s*buy\s+/i, '').replace(/\s+online.*$/i, '');
  s = s.replace(/[(),\[\]]/g, ' ');
  const words = s
    .split(/\s+/)
    .map((w) => w.replace(/^[-–—]+|[-–—]+$/g, ''))
    .filter(Boolean)
    .filter((w) => !COLORS.has(w.toLowerCase()));
  return words.slice(0, maxWords).join(' ').trim();
}

const PRODUCT_NOUNS = new Set(('chair table desk laptop tablet television tv monitor headphones headphone earbuds earphones speaker soundbar ' +
  'watch smartwatch refrigerator fridge washer washing microwave oven cooker fryer purifier cleaner vacuum fan cooler heater geyser ' +
  'trimmer shaver camera printer router keyboard mouse sofa mattress bed shoes sneakers backpack bag suitcase').split(' '));
const NOUN_MODIFIERS = new Set(['gaming', 'office', 'smart', 'wireless', 'bluetooth', 'electric', 'air', 'water', 'robot', 'standing', 'study']);

/**
 * Turn anything the user pasted (a 200-character marketplace title, a full sentence) into a
 * short search query: brand + model words, the product type (e.g. "Gaming Chair") and one
 * storage/capacity token. Marketing clauses ("Designed in Denmark", "with ...") and colours
 * are dropped.
 */
function shortenQuery(raw) {
  let s = normalizeUnits(cleanQuery(raw, 60));
  s = s.replace(/([a-z]),(?=[A-Za-z])/g, '$1 ').replace(/\b(?:designed|made|manufactured|crafted)\s+in\s+\w+/gi, ' ').replace(/[,;|/&]+/g, ' ');
  const all = s.split(/\s+/).filter(Boolean);
  const cut = all.findIndex((w) => /^(with|featuring|includes?|upto|offers?)$/i.test(w));
  const words = (cut > 3 ? all.slice(0, cut) : all).filter((w) => !/^(onyx|jet|space|deep|phantom|cosmic)$/i.test(w));
  const head = words.slice(0, 3);

  const idx = words.findIndex((w, i) => i >= 2 && PRODUCT_NOUNS.has(w.toLowerCase()));
  const tail = [];
  if (idx !== -1 && idx >= 3) {
    if (idx > 3 && NOUN_MODIFIERS.has(words[idx - 1].toLowerCase())) tail.push(words[idx - 1]);
    tail.push(words[idx]);
  }

  const cap = all
    .filter((w) => /^\d+(\.\d+)?\s?(gb|tb|inch|in|l|ltr|kg|w)$/i.test(w) && !head.includes(w))
    .sort((x, y) => parseFloat(y) - parseFloat(x))[0];
  const extra = cap ? [cap] : words.slice(3, 5).filter((w) => /\d/.test(w));
  const out = [...head, ...tail, ...extra];
  return [...new Set(out)].join(' ').replace(/\s+/g, ' ').trim();
}

const STOP = new Set(['the', 'a', 'an', 'and', 'with', 'for', 'of', 'in', 'new', 'latest', 'buy', 'online', 'by', 'to', 'at', 'on', 'from']);

function normalizeUnits(s) {
  // "128 GB" -> "128gb", "6.7 inch" -> "6.7inch", "5 G" stays as is
  return s.replace(/(\d)\s+(gb|tb|mb|mah|inch|in|hz|kg|g|ml|l|ltr|w|v|mp|k)\b/gi, '$1$2');
}

function tokenize(s) {
  return normalizeUnits(String(s || '').toLowerCase())
    .replace(/[^a-z0-9.+]+/g, ' ')
    .split(' ')
    .map((t) => t.replace(/^\.+|\.+$/g, ''))
    .filter((t) => t && !STOP.has(t));
}

// Words that mark a *different model* when present in only one of query/title. Kept short
// on purpose: generic words like "air" (air conditioner, air fryer) would cause false rejections.
const VARIANT_WORDS = new Set(['pro', 'max', 'plus', 'ultra', 'mini', 'lite', 'se', 'fe']);
const ACCESSORY_WORDS = [
  'case', 'cover', 'protector', 'guard', 'tempered', 'screenguard', 'charger', 'cable', 'strap', 'skin', 'stand',
  'holder', 'adapter', 'pouch', 'sleeve', 'film', 'refill', 'replacement', 'bumper', 'lens', 'decal', 'sticker',
  'tripod', 'mount', 'dock', 'wallet', 'combo',
];
const USED_WORDS = ['renewed', 'refurbished', 'pre-owned', 'preowned', 'used', 'open box', 'second hand'];

/**
 * Score how well a result title matches the query. Returns null if it is rejected
 * (accessory, used/renewed, different model variant, missing a model number/capacity),
 * otherwise a 0..1 score.
 */
function relevance(query, title, { loose = false } = {}) {
  const q = tokenize(query);
  if (!q.length) return null;
  const titleLower = normalizeUnits(String(title || '').toLowerCase());
  const tTokens = new Set(tokenize(title));
  const compact = titleLower.replace(/[^a-z0-9]/g, '');
  const qSet = new Set(q);

  const has = (tok) => tTokens.has(tok) || (tok.length >= 4 && compact.includes(tok.replace(/[^a-z0-9]/g, '')));

  // Accessories & used stock are rejected unless the user asked for them.
  const queryLower = String(query).toLowerCase();
  for (const w of ACCESSORY_WORDS) {
    if (tTokens.has(w) && !qSet.has(w) && !queryLower.includes(w)) return null;
  }
  for (const w of USED_WORDS) {
    if (titleLower.includes(w) && !queryLower.includes(w)) return null;
  }

  // "iPhone 15" must not match "iPhone 15 Pro": a variant word in the title that the
  // query doesn't have means it's a different model.
  if (!loose) {
    for (const v of VARIANT_WORDS) {
      if (tTokens.has(v) && !qSet.has(v)) return null;
    }
    // Tokens containing digits (model numbers, storage, sizes) are mandatory.
    const keyTokens = q.filter((t) => /\d/.test(t));
    for (const t of keyTokens) if (!has(t)) return null;
  }

  const matched = q.filter(has).length;
  const coverage = matched / q.length;
  return coverage >= (loose ? 0.5 : 0.6) ? coverage : null;
}

// ---------------------------------------------------------------------------------------
// Fetching
// ---------------------------------------------------------------------------------------

// Fetching (retries, timeouts, browser rendering, block detection) lives in ./fetcher.js

function dumpDebug(storeId, query, html) {
  if (!process.env.COMPARE_DEBUG_DUMP) return;
  try {
    const dir = path.join(process.env.DATA_DIR || path.join(__dirname, '..', 'data'), 'debug');
    fs.mkdirSync(dir, { recursive: true });
    const safe = query.replace(/[^a-z0-9]+/gi, '_').slice(0, 40);
    fs.writeFileSync(path.join(dir, `${storeId}-${safe}.html`), html);
  } catch {
    /* debug only */
  }
}

// ---------------------------------------------------------------------------------------
// One store
// ---------------------------------------------------------------------------------------

async function searchStore(store, query, fetcher) {
  const started = Date.now();
  const searchUrl = store.searchUrl(query);
  const base = { id: store.id, name: store.name, color: store.color, searchUrl, offers: [], status: 'ok', message: '' };
  try {
    const ms = () => Date.now() - started;
    let status = 200;
    let html = '';
    let page = null;
    let parsed = [];

    // 1) Stores with a JSON endpoint behind their own site search: try it first (no JS needed).
    if (store.apiUrl && store.parseApi) {
      try {
        const api = await fetcher(store.apiUrl(query), { render: false, json: true });
        dumpDebug(store.id + '-api', query, api.html);
        parsed = store.parseApi(api.html) || [];
        status = api.status;
        html = api.html;
      } catch {
        /* fall through to the HTML page */
      }
    }

    // 2) The normal search page (rendered when the store needs it).
    if (!parsed.length) {
      page = await fetcher(searchUrl, { render: !!store.jsHeavy || store.render !== false });
      status = page.status;
      html = page.html;
      dumpDebug(store.id, query, html);
      try {
        parsed = store.parse(html) || [];
      } catch (err) {
        return { ...base, ms: ms(), status: 'error', message: `Parser error: ${err.message}` };
      }
    }

    if (!parsed.length) {
      const problem = (page && page.problem) || classifyResponse({ status, html });
      if (problem) {
        const code = problem.status ? ` (HTTP ${problem.status})` : '';
        if (problem.kind === 'unavailable' || problem.kind === 'rate_limited') {
          return { ...base, ms: ms(), status: 'unavailable', message: `${store.name} is temporarily unavailable${code}. Try again in a few minutes.` };
        }
        if (problem.kind === 'not_found') {
          return { ...base, ms: ms(), status: 'no_results', message: `No products found on ${store.name} for this search.` };
        }
        // blocked / captcha / access_denied: reported, never worked around.
        return { ...base, ms: ms(), status: 'blocked', message: `${store.name} blocked the automated request${code}. Open the store link to check manually, or configure FETCH_PROXY_TEMPLATE.` };
      }
      if (store.jsHeavy || !/₹|Rs\.?\s?\d/.test(html)) {
        return { ...base, ms: ms(), status: 'js_required', message: `${store.name} renders results with JavaScript, which a plain request can't see. Use FETCH_PROXY_TEMPLATE with a rendering proxy to enable it.` };
      }
      return { ...base, ms: ms(), status: 'no_results', message: `No products found on ${store.name} for this search.` };
    }

    const scored = parsed
      .map((o) => ({ ...o, relevance: relevance(query, o.title) }))
      .filter((o) => o.relevance != null);

    if (!scored.length) {
      // No exact model: keep the closest listings as "similar" so the person still sees prices.
      const similar = parsed
        .map((o) => ({ ...o, relevance: relevance(query, o.title, { loose: true }) }))
        .filter((o) => o.relevance != null)
        .sort((a, b) => b.relevance - a.relevance || a.price - b.price)
        .slice(0, OFFERS_PER_STORE)
        .map((o) => ({ ...o, similar: true, store: store.id, storeName: store.name, storeColor: store.color, currency: '₹' }));
      return {
        ...base, ms: ms(), status: 'no_match', similar,
        message: similar.length
          ? `No exact match on ${store.name}; ${similar.length} similar listing${similar.length === 1 ? '' : 's'} shown separately.`
          : `${store.name} had results, but none looked like this product.`,
      };
    }

    // Cheapest first; in-stock ahead of out-of-stock at equal price.
    scored.sort((a, b) => a.price - b.price || (b.inStock ? 1 : 0) - (a.inStock ? 1 : 0));
    const offers = scored.slice(0, OFFERS_PER_STORE).map((o) => ({
      ...o,
      store: store.id,
      storeName: store.name,
      storeColor: store.color,
      currency: '₹',
    }));
    return { ...base, ms: ms(), offers, message: `${scored.length} matching listing${scored.length === 1 ? '' : 's'}` };
  } catch (err) {
    const timedOut = err.kind === 'timeout' || err.code === 'ECONNABORTED' || /timeout/i.test(err.message);
    return {
      ...base,
      ms: Date.now() - started,
      status: timedOut ? 'timeout' : 'error',
      message: timedOut ? `${store.name} took too long to respond.` : `Could not reach ${store.name}: ${err.message}`,
    };
  }
}

// ---------------------------------------------------------------------------------------
// Orchestration
// ---------------------------------------------------------------------------------------

const cache = new Map();

function median(nums) {
  const s = [...nums].sort((a, b) => a - b);
  const m = Math.floor(s.length / 2);
  return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2;
}

/**
 * Compare a product across stores. Returns every matching listing sorted by price
 * ascending (`offers`), plus a per-store breakdown (`stores`, also cheapest first).
 *
 * options: { stores: [ids], fetcher, fresh, extraOffers: [], fixedQuery }
 */
async function compareQuery(query, options = {}) {
  const original = String(query || '').trim().replace(/\s+/g, ' ');
  if (original.length < 2) throw new Error('Enter a product name (at least 2 characters).');
  // Long pasted titles are shortened automatically instead of rejected.
  const q = original.length > 60 || original.split(' ').length > 8 ? shortenQuery(original) : original;
  if (q.length < 2) throw new Error('Could not work out a product name from that — try brand + model.');

  const defaultIds = options.fetcher ? ['amazon', 'flipkart', 'snapdeal', 'croma', 'reliance'] : STORES.map((s) => s.id);
  const ids = (options.stores && options.stores.length ? options.stores : defaultIds).filter((id) => STORE_MAP[id]);
  if (!ids.length) throw new Error('Pick at least one store to compare.');
  const fetcher = options.fetcher || fetchHtml;

  const cacheKey = `${[...ids].sort().join(',')}|${q.toLowerCase()}`;
  const useCache = !options.fetcher && !options.fresh;
  const hit = cache.get(cacheKey);
  if (useCache && hit && Date.now() - hit.at < CACHE_TTL_MS) {
    return { ...hit.data, cached: true };
  }

  const results = await Promise.all(ids.map((id) => searchStore(STORE_MAP[id], q, fetcher)));

  let offers = results.flatMap((r) => r.offers);
  if (options.extraOffers && options.extraOffers.length) offers = offers.concat(options.extraOffers);

  // Drop implausibly cheap listings (usually an accessory that slipped through).
  if (offers.length >= 4) {
    const floor = median(offers.map((o) => o.price)) * 0.3;
    offers = offers.filter((o) => o.price >= floor);
  }

  offers.sort((a, b) => a.price - b.price || (b.inStock ? 1 : 0) - (a.inStock ? 1 : 0));
  const min = offers.length ? offers[0].price : null;
  offers = offers.map((o, i) => ({
    ...o,
    rank: i + 1,
    diff: min != null ? Number((o.price - min).toFixed(2)) : 0,
    pctAbove: min ? Number((((o.price - min) / min) * 100).toFixed(1)) : 0,
  }));

  // Per-store best price (cheapest first, stores with no price at the end).
  const stores = results
    .map((r) => {
      const mine = offers.filter((o) => o.store === r.id);
      return {
        id: r.id,
        name: r.name,
        color: r.color,
        status: mine.length ? 'ok' : r.status === 'ok' ? 'no_match' : r.status,
        message: mine.length ? r.message : r.status === 'ok' ? 'No plausible match after filtering.' : r.message,
        searchUrl: r.searchUrl,
        ms: r.ms,
        count: mine.length,
        best: mine[0] || null,
      };
    })
    .sort((a, b) => {
      if (a.best && b.best) return a.best.price - b.best.price;
      if (a.best) return -1;
      if (b.best) return 1;
      return a.name.localeCompare(b.name);
    });

  // A product link's own store wasn't searched, but its listing is part of the ranking.
  for (const o of offers) {
    if (!stores.some((s) => s.id === o.store)) {
      stores.push({
        id: o.store, name: o.storeName, color: o.storeColor, status: 'ok',
        message: 'Your link', searchUrl: o.url, ms: 0, count: 1, best: o, fromLink: true,
      });
    }
  }
  stores.sort((a, b) => {
    if (a.best && b.best) return a.best.price - b.best.price;
    if (a.best) return -1;
    if (b.best) return 1;
    return a.name.localeCompare(b.name);
  });

  const bests = stores.filter((s) => s.best).map((s) => s.best);
  const hi = bests.length ? Math.max(...bests.map((b) => b.price)) : null;
  const summary = bests.length
    ? {
        cheapest: bests.reduce((a, b) => (b.price < a.price ? b : a)),
        highest: bests.reduce((a, b) => (b.price > a.price ? b : a)),
        saving: bests.length > 1 ? Number((hi - min).toFixed(2)) : 0,
        savingPct: bests.length > 1 && hi ? Number((((hi - min) / hi) * 100).toFixed(1)) : 0,
        storesWithPrice: bests.length,
      }
    : null;

  const similar = results
    .flatMap((r) => r.similar || [])
    .sort((a, b) => a.price - b.price)
    .map((o, i) => ({ ...o, rank: i + 1 }));

  const data = {
    query: q,
    originalQuery: original !== q ? original : null,
    similar,
    currency: '₹',
    at: new Date().toISOString(),
    cached: false,
    offers,
    stores,
    summary,
    storesChecked: ids.length,
  };
  if (useCache && offers.length) cache.set(cacheKey, { at: Date.now(), data });
  return data;
}

/**
 * Compare starting from a product URL: read the product's own name + price, search the
 * other stores for it, and include the original listing in the ranking.
 */
async function compareFromUrl(url, options = {}) {
  const origin = storeForUrl(url);
  const page = await (options.extractor || extractPrice)(url);
  const name = page.name ? cleanQuery(page.name) : '';
  if (!name) throw new Error("Couldn't read a product name from that link — try typing the product name instead.");

  const ids = (options.stores && options.stores.length ? options.stores : STORES.map((s) => s.id)).filter(
    (id) => !origin || id !== origin.id
  );

  const extra = [];
  if (page.best) {
    const host = (() => {
      try {
        return new URL(url).hostname.replace(/^www\./, '');
      } catch {
        return 'your link';
      }
    })();
    extra.push({
      title: String(page.name || name).slice(0, 250),
      price: page.best.value,
      url,
      image: page.image || null,
      inStock: page.inStock !== false,
      relevance: 1,
      store: origin ? origin.id : 'link',
      storeName: origin ? origin.name : host,
      storeColor: origin ? origin.color : '#8b93a7',
      currency: page.currency || '₹',
      fromLink: true,
    });
  }

  const data = await compareQuery(name, { ...options, stores: ids, extraOffers: extra });
  return { ...data, fromUrl: url, originStore: origin ? origin.id : null };
}

module.exports = { compareQuery, compareFromUrl, cleanQuery, shortenQuery, relevance, tokenize, searchStore, fetchHtml };
