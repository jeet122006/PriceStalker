const path = require('path');
const fs = require('fs');

const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, '..', 'data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

const dbPath = path.join(DATA_DIR, 'priceghost.db');

let rawDb;
let isNodeSqlite = false;

try {
  const { DatabaseSync } = require('node:sqlite');
  rawDb = new DatabaseSync(dbPath);
  isNodeSqlite = true;
} catch (e) {
  try {
    const Database = require('better-sqlite3');
    rawDb = new Database(dbPath);
    isNodeSqlite = false;
  } catch (err2) {
    throw new Error('No SQLite driver available. Ensure Node >= 22.5.0 or install better-sqlite3: ' + err2.message);
  }
}

let db;

if (isNodeSqlite) {
  const sanitize = (v) => (v === undefined ? null : v);

  class NodeSqliteWrapper {
    constructor(inner) {
      this.inner = inner;
    }
    exec(sql) {
      return this.inner.exec(sql);
    }
    pragma(pragmaStr) {
      return this.inner.exec(`PRAGMA ${pragmaStr}`);
    }
    prepare(sql) {
      const stmt = this.inner.prepare(sql);
      return {
        run: (...args) => {
          const clean = args.map(sanitize);
          const res = stmt.run(...clean);
          return {
            lastInsertRowid: res.lastInsertRowid != null ? Number(res.lastInsertRowid) : 0,
            changes: res.changes != null ? Number(res.changes) : 0,
          };
        },
        get: (...args) => {
          const clean = args.map(sanitize);
          return stmt.get(...clean);
        },
        all: (...args) => {
          const clean = args.map(sanitize);
          return stmt.all(...clean);
        },
      };
    }
    transaction(fn) {
      return (...args) => {
        this.exec('BEGIN TRANSACTION');
        try {
          const res = fn(...args);
          this.exec('COMMIT');
          return res;
        } catch (err) {
          this.exec('ROLLBACK');
          throw err;
        }
      };
    }
    close() {
      if (typeof this.inner.close === 'function') {
        this.inner.close();
      }
    }
  }

  db = new NodeSqliteWrapper(rawDb);
} else {
  db = rawDb;
}

try {
  db.pragma('journal_mode = WAL');
} catch (e) {
  // in-memory or unsupported pragma fallback
}

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  email TEXT,
  role TEXT DEFAULT 'user',
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS products (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  url TEXT NOT NULL,
  name TEXT,
  image TEXT,
  currency TEXT DEFAULT '$',
  current_price REAL,
  target_price REAL,
  drop_threshold REAL,
  in_stock INTEGER DEFAULT 1,
  category TEXT DEFAULT 'General',
  notes TEXT,
  check_interval_minutes INTEGER DEFAULT 60,
  last_checked_at TEXT,
  last_candidates TEXT,
  created_at TEXT DEFAULT (datetime('now')),
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS price_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  product_id INTEGER NOT NULL,
  price REAL NOT NULL,
  in_stock INTEGER DEFAULT 1,
  checked_at TEXT DEFAULT (datetime('now')),
  FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS notifications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  product_id INTEGER,
  type TEXT NOT NULL,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  old_price REAL,
  new_price REAL,
  url TEXT,
  is_read INTEGER DEFAULT 0,
  created_at TEXT DEFAULT (datetime('now')),
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS search_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  query TEXT NOT NULL,
  results_count INTEGER DEFAULT 0,
  searched_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT
);
`);

function addColumnIfMissing(table, columnDef) {
  const columnName = columnDef.split(/\s+/)[0];
  try {
    db.exec(`ALTER TABLE ${table} ADD COLUMN ${columnDef}`);
  } catch (err) {
    if (!/duplicate column name/i.test(err.message)) {
      // ignore
    }
  }
}

addColumnIfMissing('products', 'user_id INTEGER');
addColumnIfMissing('products', 'alert_email TEXT');
addColumnIfMissing('products', "category TEXT DEFAULT 'General'");
addColumnIfMissing('products', 'notes TEXT');
addColumnIfMissing('products', 'compare_stores INTEGER DEFAULT 0');
addColumnIfMissing('products', 'best_other_price REAL');
addColumnIfMissing('products', 'best_other_store TEXT');
addColumnIfMissing('products', 'best_other_url TEXT');
addColumnIfMissing('products', 'compared_at TEXT');

addColumnIfMissing('users', 'email TEXT');
addColumnIfMissing('users', 'alert_webhook TEXT');
addColumnIfMissing('users', 'alert_telegram_chat TEXT');
addColumnIfMissing('users', 'alert_telegram_token TEXT');

function seedSampleDataIfEmpty() {
  if (process.argv.includes('--test') || process.env.NODE_ENV === 'test') return;
  try {
    const row = db.prepare('SELECT COUNT(*) as c FROM products').get();
    if (row && row.c === 0) {
      const admin = db.prepare("SELECT id FROM users WHERE username = 'admin'").get();
      const uid = admin ? admin.id : null;

      const samples = [
        {
          url: 'https://www.amazon.in/Apple-iPhone-16-128-GB/dp/B0DGJ9BBP5',
          name: 'Apple iPhone 16 (128 GB) - Ultramarine',
          image: 'https://m.media-amazon.com/images/I/71d7rfSl0wL._SL1500_.jpg',
          currency: '₹',
          current_price: 69900,
          target_price: 68000,
          category: 'Smartphones',
          notes: 'Waiting for festival price drop',
          compare_stores: 1,
          best_other_store: 'Flipkart',
          best_other_price: 71999,
          best_other_url: 'https://www.flipkart.com',
          history: [79900, 77900, 74900, 71900, 69900],
        },
        {
          url: 'https://www.amazon.in/Sony-WH-1000XM5-Cancelling-Headphones-Bluetooth/dp/B09XS7JWHH',
          name: 'Sony WH-1000XM5 Wireless Noise Cancelling Headphones',
          image: 'https://m.media-amazon.com/images/I/61vJtKbAssL._SL1500_.jpg',
          currency: '₹',
          current_price: 24990,
          target_price: 25000,
          category: 'Audio & Headphones',
          notes: 'Office and travel headphones',
          compare_stores: 1,
          best_other_store: 'Croma',
          best_other_price: 26990,
          best_other_url: 'https://www.croma.com',
          history: [34990, 29990, 26990, 24990],
        },
        {
          url: 'https://www.amazon.in/Apple-MacBook-13-inch-Unified-Storage/dp/B0CX21C8S9',
          name: 'Apple MacBook Air 13-inch M3 (16GB Unified Memory, 256GB SSD)',
          image: 'https://m.media-amazon.com/images/I/71S34VGTc4L._SL1500_.jpg',
          currency: '₹',
          current_price: 104900,
          target_price: 99990,
          category: 'Laptops & PCs',
          notes: 'Development machine upgrade',
          compare_stores: 1,
          best_other_store: 'Reliance Digital',
          best_other_price: 106900,
          best_other_url: 'https://www.reliancedigital.in',
          history: [114900, 109900, 104900],
        },
        {
          url: 'https://www.amazon.in/Sony-PlayStation-5-Console-Slim/dp/B0CY5JMG6V',
          name: 'Sony PlayStation 5 Console (Slim)',
          image: 'https://m.media-amazon.com/images/I/51051FiD9UL._SL1000_.jpg',
          currency: '₹',
          current_price: 49990,
          target_price: 45000,
          category: 'Gaming & Consoles',
          notes: 'Weekend gaming',
          compare_stores: 1,
          best_other_store: 'Flipkart',
          best_other_price: 48999,
          best_other_url: 'https://www.flipkart.com',
          history: [54990, 52990, 49990],
        },
      ];

      for (const s of samples) {
        const info = db.prepare(
          `INSERT INTO products (user_id, url, name, image, currency, current_price, target_price,
           in_stock, check_interval_minutes, last_checked_at, compare_stores, category, notes,
           best_other_store, best_other_price, best_other_url)
           VALUES (?, ?, ?, ?, ?, ?, ?, 1, 60, datetime('now'), ?, ?, ?, ?, ?, ?)`
        ).run(
          uid,
          s.url,
          s.name,
          s.image,
          s.currency,
          s.current_price,
          s.target_price,
          s.compare_stores,
          s.category,
          s.notes,
          s.best_other_store,
          s.best_other_price,
          s.best_other_url
        );

        for (const p of s.history) {
          db.prepare('INSERT INTO price_history (product_id, price, in_stock) VALUES (?, ?, 1)').run(info.lastInsertRowid, p);
        }
      }

      // Sample notifications
      db.prepare(`
        INSERT INTO notifications (user_id, type, title, message, old_price, new_price, created_at)
        VALUES (?, 'price_drop', 'Price drop: Apple iPhone 16', 'Dropped from ₹79,900 to ₹69,900 (-₹10,000)', 79900, 69900, datetime('now', '-2 hours'))
      `).run(uid);

      db.prepare(`
        INSERT INTO notifications (user_id, type, title, message, old_price, new_price, created_at)
        VALUES (?, 'target_met', 'Target reached: Sony WH-1000XM5', 'Now ₹24,990, at or below your target of ₹25,000', 26990, 24990, datetime('now', '-5 hours'))
      `).run(uid);
    }
  } catch (e) {
    console.warn('Sample seed notice:', e.message);
  }
}

seedSampleDataIfEmpty();

module.exports = db;
