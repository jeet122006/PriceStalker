const axios = require('axios');

/**
 * Shared page fetching for product pages and store search pages.
 *
 *  - Classifies responses as ok / transient failure / access-control block.
 *  - Retries ONLY transient failures (HTTP 502/503/504/429, timeouts, network resets) a small,
 *    configurable number of times with exponential backoff + jitter.
 *  - Never retries or works around access controls: HTTP 403, CAPTCHA pages, "access denied"
 *    and explicit automated-access refusals are reported as blocked, once, and left alone.
 *  - Never throws for an HTTP status; callers get { status, html, problem }.
 *    It only throws FetchError for network failures / timeouts that outlast the retries.
 *
 * Config (all optional env vars):
 *   FETCH_TIMEOUT_MS         plain HTTP timeout per attempt            (default 12000)
 *   BROWSER_NAV_TIMEOUT_MS   Playwright navigation timeout per attempt (default 25000, 5000-120000)
 *   FETCH_MAX_RETRIES        retries after the first attempt           (default 2, max 5)
 *   FETCH_BACKOFF_MS         base delay; doubles each retry            (default 1000)
 */

const UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';

const USER_MESSAGE = 'Price check temporarily unavailable.';

// ---------------------------------------------------------------------------------------
// Config
// ---------------------------------------------------------------------------------------

function intEnv(name, def, min, max) {
  const n = Number.parseInt(process.env[name], 10);
  if (!Number.isFinite(n)) return def;
  return Math.min(max, Math.max(min, n));
}

const config = {
  httpTimeoutMs: () => intEnv('FETCH_TIMEOUT_MS', 12000, 1000, 120000),
  navTimeoutMs: () => intEnv('BROWSER_NAV_TIMEOUT_MS', 25000, 5000, 120000),
  maxRetries: () => intEnv('FETCH_MAX_RETRIES', 2, 0, 5),
  backoffMs: () => intEnv('FETCH_BACKOFF_MS', 1000, 0, 30000),
};

// ---------------------------------------------------------------------------------------
// Errors + safe logging
// ---------------------------------------------------------------------------------------

class FetchError extends Error {
  constructor(kind, message, { transient = false, status = null } = {}) {
    super(message);
    this.name = 'FetchError';
    this.kind = kind; // timeout | network
    this.transient = transient;
    this.status = status;
  }
}

/** Thrown by extractPrice when the page can't be trusted as a product page. */
class PageUnavailableError extends Error {
  constructor(kind, { status = null, transient = true, detail = '' } = {}) {
    super(`${USER_MESSAGE}${detail ? ` (${detail})` : ''}`);
    this.name = 'PageUnavailableError';
    this.kind = kind; // unavailable | timeout | network | rate_limited | blocked | captcha | access_denied | not_found
    this.status = status;
    this.transient = transient;
    this.userMessage = kind === 'not_found' ? 'The product page was not found.' : USER_MESSAGE;
  }
}

/** host + shortened path, no query string or fragment: "www.amazon.in/dp/B0ABCDEF…" */
function describeUrl(url) {
  try {
    const u = new URL(url);
    const path = u.pathname.length > 24 ? `${u.pathname.slice(0, 23)}…` : u.pathname;
    return `${u.hostname}${path === '/' ? '' : path}`;
  } catch {
    return 'invalid-url';
  }
}

function logFetch(level, url, fields) {
  const parts = Object.entries(fields)
    .filter(([, v]) => v != null && v !== '')
    .map(([k, v]) => `${k}=${String(v).replace(/\s+/g, ' ').slice(0, 80)}`);
  console[level](`[fetch] ${describeUrl(url)} ${parts.join(' ')}`);
}

// ---------------------------------------------------------------------------------------
// Response classification
// ---------------------------------------------------------------------------------------

// Signals that the page IS a real product / results page. A big product page can mention
// "captcha" in its scripts, so these suppress text-based block detection.
const PRODUCT_SIGNALS = [
  /id=["']productTitle["']/i,
  /data-component-type=["']s-search-result["']/i,
  /"@type"\s*:\s*"Product"/i,
  /property=["']og:type["'][^>]*content=["']product/i,
  /class=["'][^"']*a-price[ "']/i,
  /product-tuple-listing/i,
];

const CAPTCHA_RE =
  /enter the characters you see below|type the characters you see|robot check|not a robot|captcha|verify you are (?:a )?human|are you a human/i;
const ACCESS_DENIED_RE =
  /access denied|request blocked|unusual traffic|pardon our interruption|temporarily blocked|automated access|api-services-support@amazon|you don't have permission to access|just a moment\.{0,3}<|attention required/i;
const ERROR_TITLE_RE =
  /^\s*(?:robot check|sorry!|page not found|access denied|error|403|503|service unavailable|just a moment|amazon\.\w+\s*:\s*sorry)/i;

function visibleStart(html, n = 6000) {
  const body = String(html || '');
  const title = (body.match(/<title[^>]*>([\s\S]*?)<\/title>/i) || [, ''])[1];
  const text = body
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<[^>]+>/g, ' ')
    .replace(/\s+/g, ' ')
    .slice(0, n);
  return { title: title.trim(), text };
}

/**
 * Returns null when the response looks like a normal page, otherwise
 * { kind, transient, status } where kind is one of:
 *   unavailable | rate_limited | blocked | captcha | access_denied | not_found
 */
function classifyResponse({ status = 200, html = '' } = {}) {
  const s = Number(status) || 0;
  const body = String(html || '');
  const hasProduct = PRODUCT_SIGNALS.some((re) => re.test(body));
  const { title, text } = hasProduct ? { title: '', text: '' } : visibleStart(body);
  const probe = `${title} ${text}`;

  // Explicit refusals first: these are access controls, never retried.
  if (!hasProduct) {
    if (CAPTCHA_RE.test(probe)) return { kind: 'captcha', transient: false, status: s };
    if (ACCESS_DENIED_RE.test(probe)) return { kind: 'access_denied', transient: false, status: s };
  }
  if (s === 403) return { kind: 'blocked', transient: false, status: s };
  if (s === 429) return { kind: 'rate_limited', transient: true, status: s };
  if (s === 502 || s === 503 || s === 504) return { kind: 'unavailable', transient: true, status: s };
  if (s === 404 || s === 410) return { kind: 'not_found', transient: false, status: s };
  if (s >= 500) return { kind: 'unavailable', transient: true, status: s };
  if (s >= 400) return { kind: 'blocked', transient: false, status: s };

  // HTTP 200 with a generic error title ("Sorry! Something went wrong") and nothing that
  // looks like a product: a server-side error page, not a product. Treated as transient.
  if (!hasProduct && title && ERROR_TITLE_RE.test(title)) {
    return { kind: 'unavailable', transient: true, status: s };
  }
  return null;
}

// ---------------------------------------------------------------------------------------
// Transports
// ---------------------------------------------------------------------------------------

const BROWSER_HEADERS = {
  'User-Agent': UA,
  'Accept-Language': 'en-IN,en;q=0.9',
  Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
  'Accept-Encoding': 'gzip, deflate, br',
};

/** FETCH_PROXY_TEMPLATE wins; SCRAPER_API_KEY is a ScraperAPI shortcut. Returns null when unset. */
function proxyTarget(url, { render = false } = {}) {
  const tpl = process.env.FETCH_PROXY_TEMPLATE;
  if (tpl) return tpl.replace('{url}', encodeURIComponent(url));
  const key = process.env.SCRAPER_API_KEY;
  if (key) {
    return `https://api.scraperapi.com/?api_key=${encodeURIComponent(key)}&country_code=in${render ? '&render=true' : ''}&url=${encodeURIComponent(url)}`;
  }
  return null;
}

async function plainGet(target, { json = false } = {}) {
  try {
    const res = await axios.get(target, {
      headers: { ...BROWSER_HEADERS, ...(json ? { Accept: 'application/json,*/*;q=0.8' } : {}) },
      timeout: config.httpTimeoutMs(),
      maxRedirects: 5,
      responseType: 'text',
      transformResponse: [(d) => d],
      validateStatus: () => true,
    });
    return { status: res.status, html: typeof res.data === 'string' ? res.data : String(res.data || '') };
  } catch (err) {
    if (err.code === 'ECONNABORTED' || err.code === 'ETIMEDOUT' || /timeout/i.test(err.message)) {
      throw new FetchError('timeout', `request timed out after ${config.httpTimeoutMs()}ms`, { transient: true });
    }
    throw new FetchError('network', err.code || err.message, { transient: /ECONNRESET|EAI_AGAIN|ETIMEDOUT|ENOTFOUND|EPIPE/.test(err.code || '') });
  }
}

let browserPromise = null;
/** Optional real Chromium (USE_BROWSER=1 + playwright installed). Relaunches if it died. */
async function getBrowser() {
  if (browserPromise) {
    const existing = await browserPromise.catch(() => null);
    if (existing && existing.isConnected()) return existing;
    browserPromise = null;
  }
  browserPromise = (async () => {
    const { chromium } = require('playwright');
    // Standard headless launch. No flags that hide automation.
    return chromium.launch({ headless: true, args: ['--no-sandbox'] });
  })().catch((err) => {
    browserPromise = null;
    throw err;
  });
  return browserPromise;
}

/**
 * Render a page in Chromium. The navigation timeout is configurable (BROWSER_NAV_TIMEOUT_MS).
 * Images, fonts and media are not downloaded — we only need the HTML — which also makes
 * navigation noticeably faster and less likely to time out.
 */
async function fetchWithBrowser(url, { getBrowserFn = getBrowser, navTimeoutMs = config.navTimeoutMs() } = {}) {
  const browser = await getBrowserFn();
  const ctx = await browser.newContext({ userAgent: UA, locale: 'en-IN', timezoneId: 'Asia/Kolkata', viewport: { width: 1366, height: 900 } });
  try {
    const page = await ctx.newPage();
    await page.route('**/*', (route) => {
      const type = route.request().resourceType();
      return type === 'image' || type === 'font' || type === 'media' ? route.abort() : route.continue();
    });
    let resp;
    try {
      resp = await page.goto(url, { waitUntil: 'domcontentloaded', timeout: navTimeoutMs });
    } catch (err) {
      if (err && (err.name === 'TimeoutError' || /timeout/i.test(err.message))) {
        throw new FetchError('timeout', `navigation timed out after ${navTimeoutMs}ms`, { transient: true });
      }
      throw new FetchError('network', String(err && err.message).split('\n')[0].slice(0, 80), { transient: false });
    }
    await page.waitForLoadState('networkidle', { timeout: Math.min(8000, navTimeoutMs) }).catch(() => {});
    return { status: resp ? resp.status() : 200, html: await page.content() };
  } finally {
    await ctx.close().catch(() => {});
  }
}

// ---------------------------------------------------------------------------------------
// Retry wrapper
// ---------------------------------------------------------------------------------------

const defaultSleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** delay = base * 2^(retryIndex) plus up to 20% jitter. */
function backoffDelay(retryIndex, base = config.backoffMs(), rand = Math.random) {
  return Math.round(base * 2 ** retryIndex * (1 + rand() * 0.2));
}

/**
 * Fetch a URL with limited retries for transient errors.
 *
 * options:
 *   render      use the real browser when USE_BROWSER=1 / render=true on the proxy
 *   proxy       allow FETCH_PROXY_TEMPLATE / SCRAPER_API_KEY (default true)
 *   json        request JSON (API endpoints)
 *   transport   (url, opts) => Promise<{status, html}>  — injectable for tests
 *   sleep, rand injectable for tests
 *   maxRetries, backoffMs override the env config
 *
 * Resolves { status, html, problem, attempts } — problem is null for a usable page.
 * Rejects with FetchError only if every attempt hit a network error / timeout.
 */
async function fetchHtml(url, options = {}) {
  const {
    render = false,
    proxy = true,
    json = false,
    transport,
    sleep = defaultSleep,
    rand = Math.random,
    maxRetries = config.maxRetries(),
    backoffMs = config.backoffMs(),
  } = options;

  const doFetch =
    transport ||
    (async (u) => {
      if (process.env.USE_BROWSER === '1' && render && !json) {
        try {
          return await fetchWithBrowser(u);
        } catch (err) {
          // Browser trouble (not installed, crashed, timed out): fall back to a plain request
          // for this attempt; the retry loop handles repeated timeouts.
          logFetch('warn', u, { via: 'browser', error: err.kind || 'error', detail: err.message });
          if (err.kind === 'timeout') throw err;
        }
      }
      const proxied = proxy ? proxyTarget(u, { render }) : null;
      return plainGet(proxied || u, { json });
    });

  let lastErr = null;
  let last = null;
  const attempts = maxRetries + 1;
  for (let attempt = 1; attempt <= attempts; attempt++) {
    last = null;
    lastErr = null;
    try {
      last = await doFetch(url, { render, json });
    } catch (err) {
      lastErr = err instanceof FetchError ? err : new FetchError('network', err.code || err.message, { transient: false });
    }

    let problem = null;
    let transient = false;
    if (last) {
      problem = json ? (last.status >= 400 ? classifyResponse({ status: last.status, html: '' }) : null) : classifyResponse(last);
      transient = !!(problem && problem.transient);
      if (!problem) return { ...last, problem: null, attempts: attempt };
    } else {
      transient = lastErr.transient;
    }

    const more = transient && attempt < attempts;
    logFetch(more ? 'warn' : 'error', url, {
      attempt: `${attempt}/${attempts}`,
      status: last ? last.status : null,
      problem: problem ? problem.kind : lastErr && lastErr.kind,
      retry: more ? 'yes' : 'no',
    });
    if (!more) break;
    await sleep(backoffDelay(attempt - 1, backoffMs, rand));
  }

  if (last) return { ...last, problem: classifyResponse(last) || { kind: 'unavailable', transient: true, status: last.status }, attempts };
  throw lastErr;
}

module.exports = {
  UA,
  USER_MESSAGE,
  config,
  FetchError,
  PageUnavailableError,
  describeUrl,
  classifyResponse,
  backoffDelay,
  proxyTarget,
  fetchHtml,
  fetchWithBrowser,
};
