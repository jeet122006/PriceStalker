const express = require('express');
const path = require('path');
const db = require('./db');
const { extractPrice } = require('./scraper');
const { PageUnavailableError } = require('./fetcher');
const { getCheckStatus, clearCheckStatus, PREFIX: STATUS_PREFIX } = require('./checkstatus');
const { checkProduct, start: startScheduler, notifyAll, compareProduct } = require('./scheduler');
const { compareQuery, compareFromUrl } = require('./compare');
const { STORES, storeForUrl } = require('./stores');
const { sendBrevoEmail } = require('./notify');
const { ensureAdminUser, registerUser, verifyLogin, sessionMiddleware, requireAuth } = require('./auth');

ensureAdminUser();

const app = express();
app.use(express.json());
app.use(sessionMiddleware());
app.use(express.static(path.join(__dirname, '..', 'public')));

// --- Auth Endpoints ---

app.post('/api/register', (req, res) => {
  const { username, password, email } = req.body || {};
  try {
    const user = registerUser(username, password, email);
    req.session.authed = true;
    req.session.userId = user.id;
    req.session.username = user.username;
    req.session.role = user.role;
    res.status(201).json({ ok: true, user });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.post('/api/login', (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) {
    return res.status(400).json({ error: 'Username and password are required.' });
  }
  const user = verifyLogin(username, password);
  if (!user) {
    return res.status(401).json({ error: 'Invalid username or password.' });
  }
  req.session.authed = true;
  req.session.userId = user.id;
  req.session.username = user.username;
  req.session.role = user.role;
  res.json({ ok: true, user });
});

app.post('/api/logout', (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

app.get('/api/me', (req, res) => {
  if (req.session && req.session.authed && req.session.userId) {
    const user = db.prepare('SELECT id, username, email, role, alert_webhook, alert_telegram_chat, created_at FROM users WHERE id = ?').get(req.session.userId);
    res.json({ authed: true, username: req.session.username, user: user || { id: req.session.userId, username: req.session.username, role: req.session.role } });
  } else if (req.session && req.session.authed) {
    res.json({ authed: true, username: req.session.username || 'admin', user: { id: 1, username: req.session.username || 'admin', role: 'admin' } });
  } else {
    res.json({ authed: false });
  }
});

app.put('/api/profile', requireAuth, (req, res) => {
  const userId = req.session.userId;
  const { email, password, alert_webhook, alert_telegram_chat, alert_telegram_token } = req.body || {};
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(userId);
  if (!user) return res.status(404).json({ error: 'User not found' });

  if (email !== undefined) {
    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return res.status(400).json({ error: 'Invalid email address' });
    }
    db.prepare('UPDATE users SET email = ? WHERE id = ?').run(email || null, userId);
  }

  if (password) {
    if (password.length < 6) return res.status(400).json({ error: 'Password must be at least 6 characters' });
    const bcrypt = require('bcryptjs');
    const hash = bcrypt.hashSync(password, 10);
    db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(hash, userId);
  }

  if (alert_webhook !== undefined) db.prepare('UPDATE users SET alert_webhook = ? WHERE id = ?').run(alert_webhook || null, userId);
  if (alert_telegram_chat !== undefined) db.prepare('UPDATE users SET alert_telegram_chat = ? WHERE id = ?').run(alert_telegram_chat || null, userId);
  if (alert_telegram_token !== undefined) db.prepare('UPDATE users SET alert_telegram_token = ? WHERE id = ?').run(alert_telegram_token || null, userId);

  const updated = db.prepare('SELECT id, username, email, role, alert_webhook, alert_telegram_chat FROM users WHERE id = ?').get(userId);
  res.json({ ok: true, user: updated });
});

// --- Dashboard Metrics & Analytics ---

const sparklineStmt = db.prepare(
  'SELECT price FROM price_history WHERE product_id = ? ORDER BY checked_at DESC LIMIT 16'
);

const statsStmt = db.prepare(
  'SELECT MIN(price) AS min, MAX(price) AS max, AVG(price) AS avg, COUNT(*) AS count FROM price_history WHERE product_id = ?'
);

app.get('/api/dashboard/stats', requireAuth, (req, res) => {
  const userId = req.session.userId;
  const isAdmin = req.session.role === 'admin';
  const filter = isAdmin ? '' : 'WHERE (user_id = ? OR user_id IS NULL)';
  const params = isAdmin ? [] : [userId];

  const totalTrackedRow = db.prepare(`SELECT COUNT(*) as count FROM products ${filter}`).get(...params);
  const totalTracked = totalTrackedRow ? totalTrackedRow.count : 0;

  const products = db.prepare(`
    SELECT p.id, p.currency, p.current_price, p.target_price,
           (SELECT MAX(price) FROM price_history h WHERE h.product_id = p.id) as max_price,
           (SELECT MIN(price) FROM price_history h WHERE h.product_id = p.id) as min_price
    FROM products p ${filter}
  `).all(...params);

  let totalSavings = 0;
  let activeDrops = 0;
  let targetsReached = 0;

  for (const p of products) {
    if (p.current_price != null) {
      if (p.max_price != null && p.current_price < p.max_price) {
        activeDrops++;
        totalSavings += (p.max_price - p.current_price);
      }
      if (p.target_price != null && p.current_price <= p.target_price) {
        targetsReached++;
      }
    }
  }

  const unreadNotifsRow = db.prepare('SELECT COUNT(*) as count FROM notifications WHERE (user_id = ? OR user_id IS NULL) AND is_read = 0').get(userId);
  const unreadNotifs = unreadNotifsRow ? unreadNotifsRow.count : 0;

  res.json({
    totalTracked,
    activeDrops,
    targetsReached,
    totalSavings: Math.round(totalSavings),
    unreadNotifs,
  });
});

app.get('/api/deals', (req, res) => {
  const rows = db.prepare(`
    SELECT p.id, p.name, p.url, p.image, p.currency, p.current_price, p.target_price, p.in_stock, p.category,
           p.best_other_store, p.best_other_price, p.best_other_url,
           (SELECT MIN(price) FROM price_history h WHERE h.product_id = p.id) AS lowest_seen,
           (SELECT MAX(price) FROM price_history h WHERE h.product_id = p.id) AS highest_seen
    FROM products p
    WHERE p.current_price IS NOT NULL
    ORDER BY p.current_price ASC
    LIMIT 20
  `).all();

  const deals = rows.map((p) => {
    const highest = p.highest_seen || p.current_price;
    const dropAmount = highest > p.current_price ? (highest - p.current_price) : 0;
    const dropPercent = highest > 0 ? Math.round((dropAmount / highest) * 100) : 0;
    const isAllTimeLow = p.current_price <= (p.lowest_seen || p.current_price);
    return {
      ...p,
      dropAmount,
      dropPercent,
      isAllTimeLow,
      sparkline: sparklineStmt.all(p.id).map((r) => r.price).reverse(),
    };
  });

  res.json(deals);
});

// --- In-App Notifications ---

app.get('/api/notifications', requireAuth, (req, res) => {
  const userId = req.session.userId;
  const list = db.prepare(`
    SELECT * FROM notifications 
    WHERE (user_id = ? OR user_id IS NULL)
    ORDER BY created_at DESC 
    LIMIT 40
  `).all(userId);
  const unreadCount = list.filter((n) => !n.is_read).length;
  res.json({ notifications: list, unreadCount });
});

app.post('/api/notifications/:id/read', requireAuth, (req, res) => {
  db.prepare('UPDATE notifications SET is_read = 1 WHERE id = ?').run(req.params.id);
  res.json({ ok: true });
});

app.post('/api/notifications/read-all', requireAuth, (req, res) => {
  const userId = req.session.userId;
  db.prepare('UPDATE notifications SET is_read = 1 WHERE (user_id = ? OR user_id IS NULL)').run(userId);
  res.json({ ok: true });
});

app.delete('/api/notifications/:id', requireAuth, (req, res) => {
  db.prepare('DELETE FROM notifications WHERE id = ?').run(req.params.id);
  res.status(204).end();
});

// --- Categories & Tags ---

app.get('/api/categories', requireAuth, (req, res) => {
  const userId = req.session.userId;
  const rows = db.prepare(`
    SELECT DISTINCT category FROM products
    WHERE (user_id = ? OR user_id IS NULL) AND category IS NOT NULL AND category != ''
    ORDER BY category ASC
  `).all(userId);
  const defaults = ['All', 'Smartphones', 'Laptops & PCs', 'Audio & Headphones', 'Gaming & Consoles', 'Home & Kitchen', 'Fashion & Wearables'];
  const userCats = rows.map((r) => r.category);
  const merged = Array.from(new Set([...defaults, ...userCats]));
  res.json(merged);
});

// --- Search History ---

app.get('/api/search-history', (req, res) => {
  const rows = db.prepare('SELECT query, COUNT(*) as count, MAX(searched_at) as last_searched FROM search_history GROUP BY query ORDER BY count DESC, last_searched DESC LIMIT 10').all();
  res.json(rows);
});

app.post('/api/search-history', (req, res) => {
  const { query, resultsCount } = req.body || {};
  if (query && typeof query === 'string' && query.trim()) {
    const userId = req.session && req.session.userId ? req.session.userId : null;
    db.prepare('INSERT INTO search_history (user_id, query, results_count) VALUES (?, ?, ?)').run(userId, query.trim(), resultsCount || 0);
  }
  res.json({ ok: true });
});

// --- Products CRUD ---

app.get('/api/products', requireAuth, (req, res) => {
  const userId = req.session.userId;
  const isAdmin = req.session.role === 'admin';
  const { category, q, sort } = req.query;

  let sql = 'SELECT * FROM products WHERE 1=1';
  const params = [];

  if (!isAdmin && userId) {
    sql += ' AND (user_id = ? OR user_id IS NULL)';
    params.push(userId);
  }

  if (category && category !== 'All') {
    sql += ' AND category = ?';
    params.push(category);
  }

  if (q && q.trim()) {
    sql += ' AND (name LIKE ? OR url LIKE ? OR notes LIKE ?)';
    const term = `%${q.trim()}%`;
    params.push(term, term, term);
  }

  if (sort === 'price_asc') {
    sql += ' ORDER BY current_price ASC';
  } else if (sort === 'price_desc') {
    sql += ' ORDER BY current_price DESC';
  } else if (sort === 'name') {
    sql += ' ORDER BY name ASC';
  } else {
    sql += ' ORDER BY created_at DESC';
  }

  const products = db.prepare(sql).all(...params);
  res.json(
    products.map((p) => {
      const stats = statsStmt.get(p.id);
      return {
        ...withParsedCandidates(p),
        sparkline: sparklineStmt.all(p.id).map((r) => r.price).reverse(),
        stats: stats && stats.count ? { min: stats.min, max: stats.max, avg: Number(stats.avg.toFixed(2)), count: stats.count } : null,
      };
    })
  );
});

app.get('/api/products/export.csv', requireAuth, (req, res) => {
  const userId = req.session.userId;
  const isAdmin = req.session.role === 'admin';
  const filter = (!isAdmin && userId) ? 'WHERE (p.user_id = ? OR p.user_id IS NULL)' : '';
  const params = (!isAdmin && userId) ? [userId] : [];

  const rows = db
    .prepare(
      `SELECT p.name, p.url, p.category, p.currency, p.current_price, p.target_price, p.in_stock, p.last_checked_at,
              p.best_other_store, p.best_other_price, p.best_other_url, p.notes,
              (SELECT MIN(price) FROM price_history h WHERE h.product_id = p.id) AS lowest_seen,
              (SELECT MAX(price) FROM price_history h WHERE h.product_id = p.id) AS highest_seen
       FROM products p ${filter} ORDER BY p.current_price ASC`
    )
    .all(...params);
  const cols = ['name', 'url', 'category', 'currency', 'current_price', 'target_price', 'in_stock', 'lowest_seen', 'highest_seen', 'best_other_store', 'best_other_price', 'best_other_url', 'notes', 'last_checked_at'];
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', 'attachment; filename="priceghost-watchlist.csv"');
  res.send(toCsv(cols, rows));
});

app.get('/api/stores', (req, res) => {
  res.json(STORES.map((s) => ({ id: s.id, name: s.name, color: s.color, homepage: s.homepage, jsHeavy: !!s.jsHeavy })));
});

app.get('/api/capabilities', (req, res) => {
  res.json({
    browser: process.env.USE_BROWSER === '1',
    proxy: !!(process.env.FETCH_PROXY_TEMPLATE || process.env.SCRAPER_API_KEY),
  });
});

app.post('/api/compare', rateLimit(15, 60 * 1000), async (req, res) => {
  const { query, stores, fresh } = req.body || {};
  const input = String(query || '').trim();
  if (!input) return res.status(400).json({ error: 'Type a product name or paste a product link.' });
  const storeIds = Array.isArray(stores) ? stores.filter((s) => typeof s === 'string') : undefined;
  try {
    let data;
    if (/^https?:\/\//i.test(input)) {
      const authed = !!(req.session && req.session.authed);
      if (!authed && !storeForUrl(input)) {
        return res.status(400).json({
          error: 'Links are only supported for the listed stores unless you are logged in. Type the product name instead.',
        });
      }
      data = await compareFromUrl(input, { stores: storeIds, fresh: !!fresh });
    } else {
      data = await compareQuery(input, { stores: storeIds, fresh: !!fresh });
    }
    // record search history quietly
    try {
      const userId = req.session && req.session.userId ? req.session.userId : null;
      db.prepare('INSERT INTO search_history (user_id, query, results_count) VALUES (?, ?, ?)').run(userId, input.slice(0, 100), (data.offers || []).length);
    } catch {}
    res.json(data);
  } catch (err) {
    console.error('[compare] failed:', String(err.message).slice(0, 120));
    res.status(502).json({ error: err.message });
  }
});

app.post('/api/products/:id/compare', requireAuth, rateLimit(15, 60 * 1000), async (req, res) => {
  const product = db.prepare('SELECT * FROM products WHERE id = ?').get(req.params.id);
  if (!product) return res.status(404).json({ error: 'Not found' });
  try {
    const { result, best, error } = await compareProduct(product, { alert: false, fresh: true });
    if (error) return res.status(400).json({ error });
    res.json({ ...result, tracked: { id: product.id, price: product.current_price, best_other: best } });
  } catch (err) {
    console.error('[product compare] failed:', err.message);
    res.status(502).json({ error: err.message });
  }
});

app.get('/api/products/:id', requireAuth, (req, res) => {
  const product = db.prepare('SELECT * FROM products WHERE id = ?').get(req.params.id);
  if (!product) return res.status(404).json({ error: 'Not found' });
  const history = db
    .prepare('SELECT price, in_stock, checked_at FROM price_history WHERE product_id = ? ORDER BY checked_at ASC')
    .all(product.id);
  res.json({ ...withParsedCandidates(product), history });
});

app.post('/api/products', requireAuth, async (req, res) => {
  const { url, target_price, drop_threshold, check_interval_minutes, alert_email, compare_stores, category, notes } = req.body;
  if (!url || !/^https?:\/\//i.test(url)) {
    return res.status(400).json({ error: 'A valid product URL is required.' });
  }
  if (alert_email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(alert_email)) {
    return res.status(400).json({ error: 'That email address looks invalid.' });
  }
  try {
    const result = await extractPrice(url);
    const now = new Date().toISOString();
    const userId = req.session.userId || null;
    const cat = category && typeof category === 'string' && category.trim() ? category.trim() : 'General';
    const note = notes && typeof notes === 'string' ? notes.trim() : null;

    const info = db
      .prepare(
        `INSERT INTO products (user_id, url, name, image, currency, current_price, target_price, drop_threshold,
         in_stock, check_interval_minutes, last_checked_at, last_candidates, alert_email, compare_stores, category, notes)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        userId,
        url,
        result.name,
        result.image,
        result.currency || '$',
        result.best ? result.best.value : null,
        target_price ?? null,
        drop_threshold ?? null,
        result.inStock ? 1 : 0,
        check_interval_minutes || 60,
        now,
        JSON.stringify(result.candidates || []),
        alert_email || null,
        compare_stores ? 1 : 0,
        cat,
        note
      );
    if (result.best) {
      db.prepare('INSERT INTO price_history (product_id, price, in_stock) VALUES (?, ?, ?)').run(
        info.lastInsertRowid,
        result.best.value,
        result.inStock ? 1 : 0
      );
    }
    const product = db.prepare('SELECT * FROM products WHERE id = ?').get(info.lastInsertRowid);

    if (alert_email) {
      sendDemoEmail({
        email: alert_email,
        title: `Now tracking: ${result.name || url}`,
        message: result.best
          ? `Current price: ${result.currency || '$'}${result.best.value}. We'll alert you the moment the price drops, hits your target, or the item restocks.`
          : `We'll keep rechecking and alert you on any future change.`,
        url,
      });
    }

    res.status(201).json(withParsedCandidates(product));
  } catch (err) {
    console.error('[add product] failed:', String(err.message).slice(0, 120));
    if (err instanceof PageUnavailableError) {
      return res.status(502).json({ error: `${err.userMessage} The store didn't return a usable page — try again in a few minutes.` });
    }
    res.status(502).json({ error: `Could not fetch or parse that URL: ${err.message}` });
  }
});

app.post('/api/demo-check', async (req, res) => {
  const { url, email } = req.body;
  if (!url || !/^https?:\/\//i.test(url)) {
    return res.status(400).json({ error: 'A valid product URL is required.' });
  }
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return res.status(400).json({ error: 'A valid email address is required.' });
  }
  try {
    const result = await extractPrice(url);
    const emailResult = await sendDemoEmail({
      email,
      title: `Price check: ${result.name || url}`,
      message: result.best
        ? `Current price: ${result.currency || '$'}${result.best.value}${result.inStock ? '' : ' (currently out of stock)'}.`
        : `No price could be confidently extracted from this page.`,
      url,
    });
    res.json({
      name: result.name,
      currency: result.currency || '$',
      price: result.best ? result.best.value : null,
      inStock: result.inStock,
      candidates: result.candidates || [],
      emailSent: emailResult.sent,
      emailError: emailResult.sent ? null : emailResult.reason,
    });
  } catch (err) {
    console.error('[demo-check] failed:', String(err.message).slice(0, 120));
    if (err instanceof PageUnavailableError) {
      return res.status(502).json({ error: `${err.userMessage} The store didn't return a usable page — try again in a few minutes.` });
    }
    res.status(502).json({ error: `Could not fetch or parse that URL: ${err.message}` });
  }
});

async function sendDemoEmail({ email, title, message, url }) {
  const brevoApiKey = getSettingValue('brevo_api_key') || process.env.BREVO_API_KEY || null;
  const senderEmail = getSettingValue('brevo_sender_email') || process.env.BREVO_SENDER_EMAIL || null;
  if (!brevoApiKey) {
    return { sent: false, reason: 'Email alerts are not configured yet (add a Brevo API key under Alerts setup).' };
  }
  await sendBrevoEmail({ apiKey: brevoApiKey, senderEmail, toEmail: email, title, message, url });
  return { sent: true };
}

function getSettingValue(key) {
  const row = db.prepare('SELECT value FROM settings WHERE key = ?').get(key);
  return row ? row.value : null;
}

app.put('/api/products/:id', requireAuth, (req, res) => {
  const product = db.prepare('SELECT * FROM products WHERE id = ?').get(req.params.id);
  if (!product) return res.status(404).json({ error: 'Not found' });
  const body = req.body || {};
  const { name, check_interval_minutes, current_price, alert_email, compare_stores, category, notes } = body;
  if (alert_email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(alert_email)) {
    return res.status(400).json({ error: 'That email address looks invalid.' });
  }
  const has = (k) => Object.prototype.hasOwnProperty.call(body, k);
  db.prepare(
    `UPDATE products SET name = COALESCE(?, name), target_price = ?, drop_threshold = ?,
     check_interval_minutes = COALESCE(?, check_interval_minutes),
     current_price = COALESCE(?, current_price),
     alert_email = COALESCE(?, alert_email),
     compare_stores = COALESCE(?, compare_stores),
     category = COALESCE(?, category),
     notes = COALESCE(?, notes)
     WHERE id = ?`
  ).run(
    name ?? null,
    has('target_price') ? body.target_price ?? null : product.target_price,
    has('drop_threshold') ? body.drop_threshold ?? null : product.drop_threshold,
    check_interval_minutes ?? null,
    current_price ?? null,
    alert_email ?? null,
    compare_stores == null ? null : compare_stores ? 1 : 0,
    category ?? null,
    notes ?? null,
    req.params.id
  );
  res.json(withParsedCandidates(db.prepare('SELECT * FROM products WHERE id = ?').get(req.params.id)));
});

app.delete('/api/products/:id', requireAuth, (req, res) => {
  db.prepare('DELETE FROM products WHERE id = ?').run(req.params.id);
  clearCheckStatus(req.params.id);
  res.status(204).end();
});

app.post('/api/products/:id/refresh', requireAuth, async (req, res) => {
  const product = db.prepare('SELECT * FROM products WHERE id = ?').get(req.params.id);
  if (!product) return res.status(404).json({ error: 'Not found' });
  await checkProduct(product);
  res.json(withParsedCandidates(db.prepare('SELECT * FROM products WHERE id = ?').get(req.params.id)));
});

// --- Settings ---

app.get('/api/settings', requireAuth, (req, res) => {
  const rows = db.prepare('SELECT key, value FROM settings').all();
  const settings = Object.fromEntries(rows.filter((r) => !r.key.startsWith(STATUS_PREFIX)).map((r) => [r.key, r.value]));
  res.json(settings);
});

app.put('/api/settings', requireAuth, (req, res) => {
  const entries = Object.entries(req.body || {});
  const stmt = db.prepare('INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value');
  const tx = db.transaction((items) => {
    for (const [key, value] of items) stmt.run(key, String(value));
  });
  tx(entries);
  res.json({ ok: true });
});

app.post('/api/settings/test-alert', requireAuth, async (req, res) => {
  try {
    await notifyAll({
      title: 'PriceGhost test alert',
      message: 'If you got this, your alerts are wired up correctly.',
      url: null,
    });
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

function rateLimit(max, windowMs) {
  const hits = new Map();
  setInterval(() => {
    const now = Date.now();
    for (const [k, v] of hits) if (now - v.start > windowMs) hits.delete(k);
  }, windowMs).unref();
  return (req, res, next) => {
    const key = req.ip || 'unknown';
    const now = Date.now();
    const entry = hits.get(key);
    if (!entry || now - entry.start > windowMs) {
      hits.set(key, { start: now, count: 1 });
      return next();
    }
    entry.count += 1;
    if (entry.count > max) {
      res.setHeader('Retry-After', Math.ceil((entry.start + windowMs - now) / 1000));
      return res.status(429).json({ error: 'Too many comparisons — wait a minute and try again.' });
    }
    next();
  };
}

function toCsv(cols, rows) {
  const esc = (v) => {
    if (v == null) return '';
    let s = String(v);
    if (/^[=+\-@\t\r]/.test(s)) s = "'" + s;
    return /[",\n\r]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
  };
  return [cols.join(','), ...rows.map((r) => cols.map((c) => esc(r[c])).join(','))].join('\r\n');
}

function withParsedCandidates(product) {
  if (!product) return product;
  let candidates = [];
  try {
    candidates = JSON.parse(product.last_candidates || '[]');
  } catch {
    candidates = [];
  }
  return { ...product, last_candidates: candidates, check_status: getCheckStatus(product.id) };
}

const PORT = process.env.PORT || 8089;
app.listen(PORT, () => {
  console.log(`PriceGhost-lite listening on port ${PORT}`);
  startScheduler();
});
