const axios = require('axios');

async function sendDiscordAlert({ webhookUrl, title, message, url }) {
  if (!webhookUrl) return;
  try {
    await axios.post(webhookUrl, {
      embeds: [
        {
          title,
          description: message,
          url,
          color: 0x7c3aed,
        },
      ],
    });
  } catch (err) {
    console.error('[notify] Discord webhook failed:', err.message);
  }
}

function escapeHtml(str) {
  return String(str == null ? '' : str).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

async function sendTelegramAlert({ botToken, chatId, title, message, url }) {
  if (!botToken || !chatId) return;
  try {
    await axios.post(
      `https://api.telegram.org/bot${botToken}/sendMessage`,
      { chat_id: chatId, text: `${title}\n${message}${url ? `\n${url}` : ''}` },
      { timeout: 10000 }
    );
  } catch (err) {
    // Never log the URL here: it contains the bot token.
    console.error('[notify] Telegram failed:', err.response?.data?.description || err.message);
  }
}

async function sendBrevoEmail({ apiKey, senderEmail, toEmail, title, message, url }) {
  if (!apiKey || !toEmail) return;
  try {
    await axios.post(
      'https://api.brevo.com/v3/smtp/email',
      {
        sender: { name: 'PriceGhost Lite', email: senderEmail || toEmail },
        to: [{ email: toEmail }],
        subject: title,
        htmlContent: `<p>${escapeHtml(message)}</p>${url ? `<p><a href="${escapeHtml(url)}">${escapeHtml(url)}</a></p>` : ''}`,
      },
      {
        headers: {
          'api-key': apiKey,
          'Content-Type': 'application/json',
          Accept: 'application/json',
        },
        timeout: 10000,
      }
    );
  } catch (err) {
    const detail = err.response?.data?.message || err.message;
    console.error('[notify] Brevo email failed:', detail);
  }
}

module.exports = { sendDiscordAlert, sendBrevoEmail, sendTelegramAlert };
