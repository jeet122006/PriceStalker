const cron = require('node-cron');
const db = require('./db');
const { extractPrice } = require('./scraper');
const { PageUnavailableError, USER_MESSAGE, describeUrl } = require('./fetcher');
const { setCheckStatus, clearCheckStatus } = require('./checkstatus');
const { sendDiscordAlert, sendBrevoEmail, sendTelegramAlert } = require('./notify');
const { compareQuery, cleanQuery } = require('./compare');
const { storeForUrl } = require('./stores');

function getSetting(key) {
  const row = db.prepare('SELECT value FROM settings WHERE key = ?').get(key);
  return row ? row.value : null;
}

function getWebhook() {
  return getSetting('discord_webhook_url') || process.env.DISCORD_WEBHOOK_URL || null;
}

function getBrevoConfig() {
  return {
    apiKey: getSetting('brevo_api_key') || process.env.BREVO_API_KEY || null,
    senderEmail: getSetting('brevo_sender_email') || process.env.BREVO_SENDER_EMAIL || null,
    toEmail: getSetting('alert_email') || process.env.ALERT_EMAIL || null,
  };
}

function getTelegramConfig() {
  return {
    botToken: getSetting('telegram_bot_token') || process.env.TELEGRAM_BOT_TOKEN || null,
    chatId: getSetting('telegram_chat_id') || process.env.TELEGRAM_CHAT_ID || null,
  };
}

function logNotification({ userId, productId, type, title, message, oldPrice, newPrice, url }) {
  try {
    db.prepare(
      `INSERT INTO notifications (user_id, product_id, type, title, message, old_price, new_price, url)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(userId || null, productId || null, type, title, message, oldPrice || null, newPrice || null, url || null);
  } catch (e) {
    // ignore
  }
}

async function notifyAll({ title, message, url, extraEmail, userId, productId, type = 'alert', oldPrice, newPrice }) {
  logNotification({ userId, productId, type, title, message, oldPrice, newPrice, url });
  const webhookUrl = getWebhook();
  const brevo = getBrevoConfig();
  const sends = [
    sendDiscordAlert({ webhookUrl, title, message, url }),
    sendBrevoEmail({ ...brevo, title, message, url }),
    sendTelegramAlert({ ...getTelegramConfig(), title, message, url }),
  ];
  // A product can carry its own alert email (set when it was added, e.g. via the demo
  // "check by email" flow) independent of the one global address in Settings — make
  // sure that address also gets any price-drop / target / restock notification.
  if (extraEmail && extraEmail !== brevo.toEmail) {
    sends.push(
      sendBrevoEmail({ apiKey: brevo.apiKey, senderEmail: brevo.senderEmail, toEmail: extraEmail, title, message, url })
    );
  }
  await Promise.all(sends);
}

/**
 * Re-check one tracked product.
 *
 * If the page can't be retrieved or trusted (HTTP 403/503, CAPTCHA, access-denied, timeout)
 * NOTHING about the product changes: the last valid price, stock flag and price history are
 * kept, no alerts fire, and a "Price check temporarily unavailable." status is recorded for
 * the UI. A valid price must be a finite number > 0; zero or missing is never saved.
 *
 * options.extractor is injectable for tests.
 */
async function checkProduct(product, { extractor = extractPrice } = {}) {
  const label = `product ${product.id} (${describeUrl(product.url)})`;
  try {
    let result;
    try {
      result = await extractor(product.url);
    } catch (err) {
      // Leave price, stock and history untouched; only stamp the attempt + status.
      const unavailable = err instanceof PageUnavailableError;
      const message = unavailable ? err.userMessage : USER_MESSAGE;
      setCheckStatus(product.id, { state: 'unavailable', message, kind: unavailable ? err.kind : 'error' });
      db.prepare('UPDATE products SET last_checked_at = ? WHERE id = ?').run(new Date().toISOString(), product.id);
      console.warn(`[scheduler] ${label}: check failed (${unavailable ? err.kind + (err.status ? ' HTTP ' + err.status : '') : String(err.message).slice(0, 80)}); kept last price`);
      return { ok: false, kept: true, kind: unavailable ? err.kind : 'error' };
    }

    const newPrice = result.best && Number.isFinite(result.best.value) && result.best.value > 0 ? result.best.value : null;
    // Page loaded fine (it passed block/error detection) but has no usable price.
    if (newPrice == null && !result.inStock) {
      // A genuine "currently unavailable" product page: record out of stock, keep the price.
      clearCheckStatus(product.id);
      db.prepare('UPDATE products SET in_stock = 0, last_checked_at = ?, last_candidates = ? WHERE id = ?').run(
        new Date().toISOString(),
        JSON.stringify(result.candidates || []),
        product.id
      );
      return { ok: true, outOfStock: true };
    }
    if (newPrice == null) {
      setCheckStatus(product.id, { state: 'no_price', message: "Couldn't read a price from the page.", kind: 'no_price' });
      db.prepare('UPDATE products SET last_checked_at = ?, last_candidates = ? WHERE id = ?').run(
        new Date().toISOString(),
        JSON.stringify(result.candidates || []),
        product.id
      );
      return { ok: false, kept: true, kind: 'no_price' };
    }
    clearCheckStatus(product.id);
    const inStock = result.inStock ? 1 : 0;
    const now = new Date().toISOString();

    if (newPrice != null) {
      db.prepare('INSERT INTO price_history (product_id, price, in_stock) VALUES (?, ?, ?)').run(
        product.id,
        newPrice,
        inStock
      );
    }

    db.prepare(
      `UPDATE products SET current_price = COALESCE(?, current_price), in_stock = ?,
       last_checked_at = ?, last_candidates = ?,
       name = COALESCE(name, ?), image = COALESCE(image, ?)
       WHERE id = ?`
    ).run(
      newPrice,
      inStock,
      now,
      JSON.stringify(result.candidates || []),
      result.name,
      result.image,
      product.id
    );

    const prevPrice = product.current_price;
    const wasInStock = product.in_stock;
    const cur = product.currency || '$';

    if (newPrice != null && prevPrice != null && newPrice < prevPrice) {
      const drop = prevPrice - newPrice;
      if (product.drop_threshold == null || drop >= product.drop_threshold) {
        await notifyAll({
          title: `Price drop: ${product.name || product.url}`,
          message: `Price dropped from ${cur}${prevPrice} to ${cur}${newPrice} (-${cur}${drop.toFixed(2)})`,
          url: product.url,
          extraEmail: product.alert_email,
          userId: product.user_id,
          productId: product.id,
          type: 'price_drop',
          oldPrice: prevPrice,
          newPrice: newPrice,
        });
      }
    }
    if (newPrice != null && product.target_price != null && newPrice <= product.target_price) {
      await notifyAll({
        title: `Target price reached: ${product.name || product.url}`,
        message: `Now ${cur}${newPrice}, at or below your target of ${cur}${product.target_price}`,
        url: product.url,
        extraEmail: product.alert_email,
        userId: product.user_id,
        productId: product.id,
        type: 'target_met',
        oldPrice: prevPrice,
        newPrice: newPrice,
      });
    }
    if (inStock && !wasInStock) {
      await notifyAll({
        title: `Back in stock: ${product.name || product.url}`,
        message: `The item is available again${newPrice != null ? ` at ${cur}${newPrice}` : ''}.`,
        url: product.url,
        extraEmail: product.alert_email,
        userId: product.user_id,
        productId: product.id,
        type: 'restock',
        newPrice: newPrice,
      });
    }
  } catch (err) {
    console.error(`[scheduler] Failed to check ${label}:`, String(err.message).slice(0, 120));
    return { ok: false, kept: true, kind: 'error' };
  }
  return { ok: true };
}

// ---- Cross-store watch ------------------------------------------------------------------
// For products with "watch other stores" switched on, periodically search the other stores
// for the same model and alert when one of them undercuts the price we're tracking.
const COMPARE_EVERY_MS = 6 * 60 * 60 * 1000;

/**
 * Runs a comparison for one tracked product, stores the best price found elsewhere on the
 * product row, and returns { result, best }. Alerts only when a *new low* appears elsewhere
 * (cheaper than both the tracked price and the previous best-elsewhere price), so you don't
 * get re-notified every six hours about the same deal.
 */
async function compareProduct(product, { alert = true, fresh = false, fetcher, notify = notifyAll } = {}) {
  const query = cleanQuery(product.name || '');
  if (!query) return { result: null, best: null, error: 'This product has no name to search with yet.' };

  const own = storeForUrl(product.url);
  const result = await compareQuery(query, { fresh, fetcher });
  const others = result.offers.filter((o) => !own || o.store !== own.id);
  const best = others[0] || null;

  const prevBest = product.best_other_price;
  db.prepare(
    `UPDATE products SET best_other_price = ?, best_other_store = ?, best_other_url = ?, compared_at = ? WHERE id = ?`
  ).run(best ? best.price : null, best ? best.storeName : null, best ? best.url : null, new Date().toISOString(), product.id);

  if (alert && best && product.current_price != null && best.price < product.current_price * 0.98) {
    const isNewLow = prevBest == null || best.price < prevBest;
    if (isNewLow) {
      const cur = product.currency || '₹';
      await notify({
        title: `Cheaper on ${best.storeName}: ${product.name || query}`,
        message: `${best.storeName} has it for ${cur}${best.price} — ${cur}${(product.current_price - best.price).toFixed(2)} less than the ${cur}${product.current_price} you're tracking.`,
        url: best.url,
        extraEmail: product.alert_email,
        userId: product.user_id,
        productId: product.id,
        type: 'cheaper_store',
        oldPrice: product.current_price,
        newPrice: best.price,
      });
    }
  }
  return { result, best };
}

async function maybeCompare(product) {
  if (!product.compare_stores) return;
  const last = product.compared_at ? new Date(product.compared_at).getTime() : 0;
  if (Date.now() - last < COMPARE_EVERY_MS) return;
  try {
    // Re-read: checkProduct just refreshed current_price.
    const fresh = db.prepare('SELECT * FROM products WHERE id = ?').get(product.id);
    if (fresh) await compareProduct(fresh);
  } catch (err) {
    console.error(`[scheduler] Cross-store compare failed for product ${product.id}:`, err.message);
  }
}

function isDue(product) {
  if (!product.last_checked_at) return true;
  const last = new Date(product.last_checked_at).getTime();
  const intervalMs = (product.check_interval_minutes || 60) * 60 * 1000;
  return Date.now() - last >= intervalMs;
}

function start() {
  // Runs every 5 minutes; each product only actually re-checked when its own interval has elapsed.
  cron.schedule('*/5 * * * *', async () => {
    const products = db.prepare('SELECT * FROM products').all();
    for (const product of products) {
      if (isDue(product)) {
        await checkProduct(product);
      }
      await maybeCompare(product);
    }
  });
  console.log('[scheduler] Started (evaluates due products every 5 minutes)');
}

module.exports = { start, checkProduct, notifyAll, compareProduct };
