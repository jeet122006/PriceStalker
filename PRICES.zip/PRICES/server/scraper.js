const cheerio = require('cheerio');
const { fetchHtml, PageUnavailableError, classifyResponse, FetchError } = require('./fetcher');

const OUT_OF_STOCK_PATTERNS = [
  /out of stock/i,
  /currently unavailable/i,
  /sold out/i,
  /no longer available/i,
  /we don't know when or if this item will be back in stock/i, // Amazon
];

function parsePriceString(str) {
  if (str == null) return null;
  if (typeof str === 'number') return Number.isFinite(str) && str > 0 ? str : null;
  const cleaned = String(str).replace(/[^0-9.,]/g, '').replace(/^[.,]+|[.,]+$/g, '').trim();
  if (!cleaned) return null;

  // Work out which separator is the decimal point. The old rule ("a trailing comma means
  // decimal") turned Indian-style prices without paise, e.g. "₹54,999" or "₹1,29,999",
  // into 54.999 / 1.29. The rules below handle US, European and Indian grouping.
  const lastComma = cleaned.lastIndexOf(',');
  const lastDot = cleaned.lastIndexOf('.');
  let normalized;
  if (lastComma !== -1 && lastDot !== -1) {
    // Both present: whichever comes last is the decimal separator.
    normalized =
      lastComma > lastDot
        ? cleaned.replace(/\./g, '').replace(',', '.') // 1.299,00
        : cleaned.replace(/,/g, ''); //                   1,299.00 / 1,29,999.00
  } else if (lastComma !== -1) {
    const commas = (cleaned.match(/,/g) || []).length;
    const afterLast = cleaned.length - lastComma - 1;
    // A single comma followed by 1-2 digits is a decimal ("12,50"); anything else
    // (3 digits after it, or several commas as in Indian grouping) is thousands.
    normalized = commas === 1 && afterLast >= 1 && afterLast <= 2 ? cleaned.replace(',', '.') : cleaned.replace(/,/g, '');
  } else if ((cleaned.match(/\./g) || []).length > 1) {
    normalized = cleaned.replace(/\./g, ''); // 1.299.000 -> thousands separators
  } else {
    normalized = cleaned;
  }
  const value = parseFloat(normalized);
  return Number.isFinite(value) && value > 0 ? value : null;
}

function currencySymbolNear(text) {
  const m = text.match(/(\$|€|£|₹|¥)/);
  return m ? m[1] : null;
}

// ISO 4217 codes (as used in JSON-LD / og:price:currency) to display symbols.
const CURRENCY_SYMBOLS = {
  USD: '$', INR: '₹', EUR: '€', GBP: '£', JPY: '¥',
  CAD: 'CA$', AUD: 'AU$', SGD: 'S$', AED: 'AED ',
};

function normalizeCurrency(value) {
  if (!value) return null;
  const v = String(value).trim();
  if (/^(\$|€|£|₹|¥)$/.test(v)) return v; // already a symbol
  return CURRENCY_SYMBOLS[v.toUpperCase()] || null;
}

// Fallback when no explicit currency is found anywhere on the page: infer it from the
// store's country domain. This matters most for Amazon's regional sites (amazon.in,
// amazon.co.uk, ...), which don't always expose JSON-LD/meta currency info.
const TLD_CURRENCY = {
  'amazon.in': '₹', '.in': '₹',
  'amazon.co.uk': '£', '.co.uk': '£', '.uk': '£',
  'amazon.de': '€', 'amazon.fr': '€', 'amazon.it': '€', 'amazon.es': '€', '.de': '€', '.fr': '€', '.it': '€', '.es': '€',
  'amazon.co.jp': '¥', '.jp': '¥',
  'amazon.ca': 'CA$', '.ca': 'CA$',
  'amazon.com.au': 'AU$', '.au': 'AU$',
};

function currencyFromUrl(url) {
  try {
    const host = new URL(url).hostname.toLowerCase();
    for (const [key, symbol] of Object.entries(TLD_CURRENCY)) {
      if (host.includes(key) || host.endsWith(key)) return symbol;
    }
  } catch {
    /* ignore malformed URL */
  }
  return null;
}

function isAmazonHost(url) {
  try {
    return /(^|\.)amazon\./i.test(new URL(url).hostname);
  } catch {
    return false;
  }
}

function extractJsonLd($) {
  const candidates = [];
  $('script[type="application/ld+json"]').each((_, el) => {
    let raw;
    try {
      raw = JSON.parse($(el).contents().text());
    } catch {
      return;
    }
    const nodes = Array.isArray(raw) ? raw : [raw, ...(raw['@graph'] || [])];
    for (const node of nodes) {
      if (!node || typeof node !== 'object') continue;
      const types = [].concat(node['@type'] || []);
      if (!types.some((t) => String(t).toLowerCase().includes('product')) && !node.offers) continue;
      const offers = [].concat(node.offers || []);
      for (const offer of offers) {
        if (!offer) continue;
        const price = offer.price ?? offer.lowPrice ?? offer.highPrice;
        if (price != null) {
          const value = parsePriceString(price);
          if (value != null) {
            candidates.push({
              value,
              currency: normalizeCurrency(offer.priceCurrency),
              source: 'JSON-LD',
              confidence: 0.95,
              inStock: !/outofstock/i.test(String(offer.availability || '')),
            });
          }
        }
      }
    }
  });
  return candidates;
}

function extractMetaTags($) {
  const candidates = [];
  const selectors = [
    'meta[property="product:price:amount"]',
    'meta[property="og:price:amount"]',
    'meta[itemprop="price"]',
    'meta[name="twitter:data1"]',
  ];
  const metaCurrency =
    normalizeCurrency($('meta[property="product:price:currency"]').attr('content')) ||
    normalizeCurrency($('meta[property="og:price:currency"]').attr('content')) ||
    normalizeCurrency($('meta[itemprop="priceCurrency"]').attr('content'));
  for (const sel of selectors) {
    $(sel).each((_, el) => {
      const raw = $(el).attr('content') || $(el).attr('value');
      const value = parsePriceString(raw);
      if (value != null) {
        candidates.push({ value, currency: metaCurrency, source: 'Meta Tag', confidence: 0.75, inStock: true });
      }
    });
  }
  return candidates;
}

// Amazon's product pages (amazon.in, .com, .co.uk, ...) often skip JSON-LD/meta pricing
// entirely, so a dedicated selector pass is the difference between "no price found" and
// a correct one. ".a-offscreen" spans hold the full, screen-reader-friendly price text
// (e.g. "₹1,299.00"), which also gives us the currency symbol for free.
function extractAmazonSelectors($) {
  const candidates = [];
  const selectors = [
    '#corePriceFeature_feature_div .a-price .a-offscreen',
    '#corePrice_feature_div .a-price .a-offscreen',
    '#corePriceDisplay_desktop_feature_div .a-price .a-offscreen',
    '#apex_desktop .a-price .a-offscreen',
    '#priceblock_ourprice',
    '#priceblock_dealprice',
    '.a-price .a-offscreen',
  ];
  const seen = new Set();
  $(selectors.join(',')).each((_, el) => {
    const text = $(el).text().trim();
    const value = parsePriceString(text);
    if (value == null || value <= 0) return;
    const key = value.toFixed(2);
    if (seen.has(key)) return;
    seen.add(key);
    candidates.push({
      value,
      currency: currencySymbolNear(text),
      source: 'Amazon Selectors',
      confidence: 0.9,
      inStock: true,
    });
  });
  return candidates.slice(0, 5);
}

function extractGenericCss($) {
  const candidates = [];
  const selectors = [
    '[class*="price" i]',
    '[id*="price" i]',
    '[data-testid*="price" i]',
    '[itemprop="price"]',
  ];
  const seen = new Set();
  $(selectors.join(',')).each((_, el) => {
    const text = $(el).text().trim();
    if (!text || text.length > 40) return;
    const match = text.match(/[\$€£₹¥]\s?[\d.,]+/);
    if (!match) return;
    const value = parsePriceString(match[0]);
    if (value == null || value <= 0 || value > 100000) return;
    const key = value.toFixed(2);
    if (seen.has(key)) return;
    seen.add(key);
    candidates.push({
      value,
      currency: currencySymbolNear(match[0]),
      source: 'Generic CSS',
      confidence: 0.5,
      inStock: true,
    });
  });
  return candidates.slice(0, 8);
}

function detectOutOfStock($, bodyText) {
  return OUT_OF_STOCK_PATTERNS.some((re) => re.test(bodyText));
}

function extractTitleAndImage($) {
  const name =
    $('meta[property="og:title"]').attr('content') ||
    $('title').first().text() ||
    null;
  const image =
    $('meta[property="og:image"]').attr('content') ||
    $('img[class*="product" i]').first().attr('src') ||
    null;
  return { name: name ? name.trim().slice(0, 200) : null, image: image || null };
}

/**
 * Voting: merge candidates from all strategies, group near-identical values,
 * and rank by combined confidence. Returns { best, candidates, name, image, inStock }.
 *
 * Throws PageUnavailableError (never returns a result) when the page can't be trusted as a
 * product page — HTTP 403/503, CAPTCHA, access-denied, timeouts — so callers keep the last
 * valid price instead of recording an error page as a product.
 *
 * options.fetcher: (url, opts) => { status, html, problem } — injectable for tests.
 */
async function extractPrice(url, { fetcher = fetchHtml } = {}) {
  const amazon = isAmazonHost(url);
  let res;
  try {
    // Amazon product pages are the ones that need the browser/proxy; other stores stay on
    // a direct request exactly as before (just with retries and block detection).
    res = await fetcher(url, { render: amazon, proxy: amazon });
  } catch (err) {
    if (err instanceof FetchError) {
      throw new PageUnavailableError(err.kind, { transient: err.transient, detail: err.message });
    }
    throw err;
  }
  const problem = res.problem || classifyResponse(res);
  if (problem) {
    throw new PageUnavailableError(problem.kind, {
      status: problem.status,
      transient: problem.transient,
      detail: problem.status ? `HTTP ${problem.status}, ${problem.kind}` : problem.kind,
    });
  }
  const $ = cheerio.load(res.html);
  const bodyText = $('body').text().slice(0, 20000);

  let candidates = [
    ...extractJsonLd($),
    ...extractMetaTags($),
    ...extractGenericCss($),
    ...(isAmazonHost(url) ? extractAmazonSelectors($) : []),
  ];

  // Fall back to a currency inferred from the store's domain (important for Amazon's
  // regional sites, which frequently omit explicit currency markup) whenever a
  // candidate's own extraction method didn't turn one up.
  const urlCurrency = currencyFromUrl(url);
  candidates = candidates.map((c) => ({ ...c, currency: c.currency || urlCurrency || '$' }));

  // Group by rounded value, summing confidence as a simple "vote weight"
  const groups = new Map();
  for (const c of candidates) {
    const key = c.value.toFixed(2);
    if (!groups.has(key)) groups.set(key, { ...c, votes: 0, sources: [] });
    const g = groups.get(key);
    g.votes += c.confidence;
    g.sources.push(c.source);
  }
  candidates = [...groups.values()].sort((a, b) => b.votes - a.votes);

  candidates = candidates.filter((c) => Number.isFinite(c.value) && c.value > 0);

  const { name, image } = extractTitleAndImage($);
  const outOfStock = detectOutOfStock($, bodyText);

  return {
    best: candidates[0] || null,
    candidates,
    name,
    image,
    currency: (candidates[0] && candidates[0].currency) || urlCurrency || '$',
    inStock: !outOfStock,
  };
}

module.exports = { extractPrice, parsePriceString, isAmazonHost };
