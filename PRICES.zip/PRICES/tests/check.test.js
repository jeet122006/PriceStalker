const test = require('node:test');
const assert = require('node:assert');
const os = require('os');
const path = require('path');
const fs = require('fs');

process.env.DATA_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'pg-check-'));
const db = require('../server/db');
const { checkProduct } = require('../server/scheduler');
const { getCheckStatus } = require('../server/checkstatus');
const { PageUnavailableError } = require('../server/fetcher');

function addProduct(price = 1999) {
  const info = db
    .prepare("INSERT INTO products (url, name, currency, current_price, in_stock) VALUES ('https://www.amazon.in/dp/B0ABCDEFGH?tag=x', 'Test product', '₹', ?, 1)")
    .run(price);
  const id = info.lastInsertRowid;
  db.prepare('INSERT INTO price_history (product_id, price, in_stock) VALUES (?, ?, 1)').run(id, 2099);
  db.prepare('INSERT INTO price_history (product_id, price, in_stock) VALUES (?, ?, 1)').run(id, price);
  return db.prepare('SELECT * FROM products WHERE id = ?').get(id);
}
const row = (id) => db.prepare('SELECT * FROM products WHERE id = ?').get(id);
const history = (id) => db.prepare('SELECT price FROM price_history WHERE product_id = ? ORDER BY id').all(id).map((r) => r.price);

test('HTTP 503 / timeout / blocked checks keep the last valid price, stock flag and history', async () => {
  const p = addProduct(1999);
  const failures = [
    new PageUnavailableError('unavailable', { status: 503 }),
    new PageUnavailableError('timeout', { transient: true }),
    new PageUnavailableError('captcha', { transient: false }),
    new PageUnavailableError('blocked', { status: 403, transient: false }),
    new Error('something unexpected'),
  ];
  for (const err of failures) {
    const out = await checkProduct(p, { extractor: async () => { throw err; } });
    assert.strictEqual(out.ok, false);
    assert.strictEqual(out.kept, true);
    assert.strictEqual(row(p.id).current_price, 1999);
    assert.strictEqual(row(p.id).in_stock, 1);
    assert.deepStrictEqual(history(p.id), [2099, 1999]);
    const st = getCheckStatus(p.id);
    assert.strictEqual(st.state, 'unavailable');
    assert.strictEqual(st.message, 'Price check temporarily unavailable.');
  }
});

test('a price of zero or a missing price is never saved', async () => {
  const p = addProduct(1500);
  const zero = { best: { value: 0 }, candidates: [{ value: 0 }], name: 'Robot Check', image: null, inStock: true };
  const none = { best: null, candidates: [], name: 'Test product', image: null, inStock: true };
  for (const result of [zero, none]) {
    await checkProduct(p, { extractor: async () => result });
    assert.strictEqual(row(p.id).current_price, 1500);
    assert.deepStrictEqual(history(p.id), [2099, 1500]);
    assert.strictEqual(getCheckStatus(p.id).state, 'no_price');
  }
});

test('a later successful check records the new price and clears the unavailable status', async () => {
  const p = addProduct(1999);
  await checkProduct(p, { extractor: async () => { throw new PageUnavailableError('unavailable', { status: 503 }); } });
  assert.ok(getCheckStatus(p.id));

  const ok = { best: { value: 2049 }, candidates: [{ value: 2049, sources: ['JSON-LD'] }], name: 'Test product', image: null, inStock: true };
  const out = await checkProduct(row(p.id), { extractor: async () => ok });
  assert.strictEqual(out.ok, true);
  assert.strictEqual(row(p.id).current_price, 2049);
  assert.deepStrictEqual(history(p.id), [2099, 1999, 2049]);
  assert.strictEqual(getCheckStatus(p.id), null);
});

test('a genuine out-of-stock page (no price) marks stock but keeps the price', async () => {
  const p = addProduct(1999);
  const oos = { best: null, candidates: [], name: 'Test product', image: null, inStock: false };
  const out = await checkProduct(p, { extractor: async () => oos });
  assert.strictEqual(out.outOfStock, true);
  assert.strictEqual(row(p.id).in_stock, 0);
  assert.strictEqual(row(p.id).current_price, 1999);
  assert.strictEqual(getCheckStatus(p.id), null);
});
