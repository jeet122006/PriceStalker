const test = require('node:test');
const assert = require('node:assert');
const { compareQuery, compareFromUrl, cleanQuery, relevance } = require('../server/compare');
const { parsePriceString } = require('../server/scraper');

const { amazonHtml, flipkartHtml, snapdealHtml, cromaHtml, relianceShell, captchaHtml, fakeFetcher, ok } = require('./fixtures');


// ---- Price parsing --------------------------------------------------------------------

test('parsePriceString handles Indian, US and European formats', () => {
  const cases = { '₹54,999': 54999, '₹1,29,999': 129999, '₹1,29,999.00': 129999, '$1,299.99': 1299.99, '12,50': 12.5, '1.299,00': 1299, '₹999': 999 };
  for (const [input, want] of Object.entries(cases)) assert.strictEqual(parsePriceString(input), want, input);
});

// ---- Matching -------------------------------------------------------------------------

test('relevance rejects accessories, renewed stock and different variants', () => {
  const q = 'Apple iPhone 15 128GB';
  assert.ok(relevance(q, 'Apple iPhone 15 (128 GB) - Black') > 0.9);
  assert.strictEqual(relevance(q, 'Apple iPhone 15 Pro (128 GB)'), null, 'Pro is a different model');
  assert.strictEqual(relevance(q, 'Apple iPhone 15 Plus (128 GB)'), null, 'Plus is a different model');
  assert.strictEqual(relevance(q, 'Spigen Case Cover for iPhone 15 128 GB'), null, 'accessory');
  assert.strictEqual(relevance(q, 'Apple iPhone 15 (128 GB) (Renewed)'), null, 'renewed');
  assert.strictEqual(relevance(q, 'Apple iPhone 15 (256 GB)'), null, 'wrong capacity');
  assert.ok(relevance('iphone 15 case', 'Spigen Case for iPhone 15') > 0, 'accessory query still matches accessories');
});

test('relevance does not reject "air conditioner" for an AC search', () => {
  assert.ok(relevance('Voltas 1.5 ton 3 star split ac', 'Voltas 1.5 Ton 3 Star Split Air Conditioner') > 0.6);
});

test('cleanQuery strips store names, marketing text and colours', () => {
  assert.strictEqual(cleanQuery('Apple iPhone 15 (128 GB) - Black : Amazon.in: Electronics'), 'Apple iPhone 15 128 GB');
  assert.strictEqual(cleanQuery('Buy Apple iPhone 15 (Blue, 128 GB) Online at Best Price | Flipkart'), 'Apple iPhone 15 128 GB');
});

// ---- Full comparison ------------------------------------------------------------------

test('all prices are returned in ascending order across stores, with filters applied', async () => {
  const fetcher = fakeFetcher({
    'amazon.in': ok(amazonHtml),
    'flipkart.com': ok(flipkartHtml),
    'snapdeal.com': ok(snapdealHtml),
    'croma.com': ok(cromaHtml),
    'reliancedigital.in': ok(relianceShell),
  });
  const r = await compareQuery('Apple iPhone 15 128GB', { fetcher });

  const prices = r.offers.map((o) => o.price);
  assert.deepStrictEqual(prices, [...prices].sort((a, b) => a - b), 'offers sorted ascending');
  assert.deepStrictEqual(prices, [64999, 65900, 66490, 67490]);
  assert.deepStrictEqual(r.offers.map((o) => o.store), ['flipkart', 'amazon', 'croma', 'snapdeal']);
  assert.strictEqual(r.offers[0].rank, 1);
  assert.strictEqual(r.offers[0].diff, 0);
  assert.strictEqual(r.offers[3].diff, 2491);

  // The Pro / Plus / case / renewed listings must not leak in.
  assert.ok(r.offers.every((o) => !/pro|plus|case|renewed/i.test(o.title)));

  // Flipkart: tracking params stripped but pid kept; Amazon: canonical /dp/ link.
  assert.ok(r.offers[0].url.includes('pid=MOBGTAGPTB3VS24W') && !r.offers[0].url.includes('lid='));
  assert.strictEqual(r.offers[1].url, 'https://www.amazon.in/dp/B0AAAAAAA1');

  assert.strictEqual(r.summary.cheapest.store, 'flipkart');
  assert.strictEqual(r.summary.highest.store, 'snapdeal');
  assert.strictEqual(r.summary.saving, 2491);

  // Reliance returned a JS shell -> reported honestly, not silently dropped.
  const rel = r.stores.find((s) => s.id === 'reliance');
  assert.strictEqual(rel.status, 'js_required');
  assert.strictEqual(r.stores.at(-1).id, 'reliance', 'stores without a price are listed last');
});

test('blocked, erroring and timed-out stores are reported without breaking the others', async () => {
  const timeout = Object.assign(new Error('timeout of 12000ms exceeded'), { code: 'ECONNABORTED' });
  const fetcher = fakeFetcher({
    'amazon.in': { status: 503, html: captchaHtml },
    'flipkart.com': ok(flipkartHtml),
    'snapdeal.com': timeout,
    'croma.com': new Error('getaddrinfo ENOTFOUND'),
    'reliancedigital.in': ok(relianceShell),
  });
  const r = await compareQuery('Apple iPhone 15 128GB', { fetcher });
  const st = Object.fromEntries(r.stores.map((s) => [s.id, s.status]));
  assert.deepStrictEqual(st, { flipkart: 'ok', amazon: 'blocked', snapdeal: 'timeout', croma: 'error', reliance: 'js_required' });
  assert.strictEqual(r.offers.length, 1);
  assert.strictEqual(r.summary.saving, 0, 'no saving claimed with a single price');
});

test('a store with results but no matching model is "no_match"', async () => {
  const fetcher = fakeFetcher({ 'amazon.in': ok(amazonHtml) });
  const r = await compareQuery('Samsung Galaxy S24 256GB', { fetcher, stores: ['amazon'] });
  assert.strictEqual(r.stores[0].status, 'no_match');
  assert.strictEqual(r.offers.length, 0);
  assert.strictEqual(r.summary, null);
});

test('store selection is respected and validated', async () => {
  const fetcher = fakeFetcher({ 'snapdeal.com': ok(snapdealHtml) });
  const r = await compareQuery('Apple iPhone 15 128GB', { fetcher, stores: ['snapdeal'] });
  assert.strictEqual(r.stores.length, 1);
  await assert.rejects(() => compareQuery('x', { fetcher }), /at least 2/);
  await assert.rejects(() => compareQuery('iphone 15', { fetcher, stores: ['nope'] }), /at least one store/);
});

test('compareFromUrl ranks the original listing together with the other stores', async () => {
  const fetcher = fakeFetcher({
    'flipkart.com': ok(flipkartHtml),
    'snapdeal.com': ok(snapdealHtml),
    'croma.com': ok(cromaHtml),
    'reliancedigital.in': ok(relianceShell),
    'amazon.in': ok(amazonHtml),
  });
  const extractor = async () => ({
    name: 'Apple iPhone 15 (128 GB) - Black : Amazon.in: Electronics',
    best: { value: 65900 }, currency: '₹', inStock: true, image: null,
  });
  const r = await compareFromUrl('https://www.amazon.in/dp/B0AAAAAAA1', { fetcher, extractor });
  assert.strictEqual(r.query, 'Apple iPhone 15 128 GB');
  assert.strictEqual(r.originStore, 'amazon');
  const prices = r.offers.map((o) => o.price);
  assert.deepStrictEqual(prices, [...prices].sort((a, b) => a - b));
  assert.strictEqual(r.offers.filter((o) => o.store === 'amazon').length, 1, 'origin store not double-counted');
  assert.ok(r.offers.find((o) => o.fromLink));
  assert.ok(r.stores.find((s) => s.id === 'amazon' && s.fromLink));
});

// ---- v1.2: long titles, similar listings, JSON APIs ------------------------------------

test('long pasted titles are shortened instead of rejected', async () => {
  const { shortenQuery } = require('../server/compare');
  const long = 'Casa Copenhagen Designed in Denmark,High-Back Italian Leather Gaming Ergonomic Chair with Adjustable Lumbar Support & 4D Armrest, Black (Gold Series)';
  assert.ok(long.length < 400);
  const q = shortenQuery(long);
  assert.match(q, /Casa Copenhagen/);
  assert.match(q, /Chair/);
  assert.ok(q.length < 60);
  const data = await compareQuery(long, { stores: ['snapdeal'], fetcher: async () => ({ status: 200, html: '<html></html>' }) });
  assert.equal(data.originalQuery, long.replace(/\s+/g, ' '));
  assert.ok(data.query.length < 60);
});

test('no exact match still surfaces similar listings separately', async () => {
  const html = `<html><body><div class="product-tuple-listing">
    <a class="dp-widget-link" href="https://www.snapdeal.com/product/x/1"></a>
    <p class="product-title" title="Casa Copenhagen Ergonomic Gaming Chair Black">Casa Copenhagen Ergonomic Gaming Chair Black</p>
    <span class="product-price" data-price="9499">Rs. 9,499</span></div></body></html>`;
  const data = await compareQuery('Casa Copenhagen Gaming Chair 4D', { stores: ['snapdeal'], fetcher: async () => ({ status: 200, html }) });
  assert.equal(data.offers.length, 0);
  assert.equal(data.similar.length, 1);
  assert.equal(data.similar[0].price, 9499);
});

test('Reliance JSON API results are parsed without any rendering', () => {
  const { STORE_MAP } = require('../server/stores');
  const body = JSON.stringify({ items: [{ name: 'Apple iPhone 15 128GB Black', slug: 'apple-iphone-15-128gb-black', price: { effective: { min: 65990 } }, medias: [{ url: 'https://cdn.example/a.jpg' }] }] });
  const offers = STORE_MAP.reliance.parseApi(body);
  assert.equal(offers.length, 1);
  assert.equal(offers[0].price, 65990);
  assert.match(offers[0].url, /reliancedigital\.in/);
});
