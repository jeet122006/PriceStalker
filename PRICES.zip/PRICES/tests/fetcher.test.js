const test = require('node:test');
const assert = require('node:assert');

const F = require('../server/fetcher');
const { extractPrice } = require('../server/scraper');

const SERVICE_UNAVAILABLE = '<html><head><title>Service Unavailable</title></head><body>Try again later.</body></html>';
const CAPTCHA_PAGE = '<html><body><h4>Enter the characters you see below</h4><p>api-services-support@amazon.com</p></body></html>';
const ACCESS_DENIED = '<html><head><title>Access Denied</title></head><body><h1>Access Denied</h1></body></html>';
const PRODUCT_PAGE = `<html><head><title>Apple iPhone 15 (128 GB) - Black : Amazon.in</title>
  <script type="application/ld+json">${JSON.stringify({ '@type': 'Product', name: 'Apple iPhone 15 (128 GB) - Black', offers: { price: '65900.00', priceCurrency: 'INR', availability: 'InStock' } })}</script>
  <script>var captchaConfig = { enabled: false };</script></head>
  <body><span id="productTitle">Apple iPhone 15 (128 GB) - Black</span>
  <span class="a-price"><span class="a-offscreen">₹65,900.00</span></span></body></html>`;

// A transport that plays back a scripted list of responses (or errors) and counts calls.
function scripted(steps) {
  const calls = [];
  const transport = async (url) => {
    calls.push(url);
    const step = steps[Math.min(calls.length - 1, steps.length - 1)];
    if (step instanceof Error) throw step;
    return step;
  };
  return { transport, calls };
}
const noWait = () => {
  const delays = [];
  return { sleep: async (ms) => delays.push(ms), delays, rand: () => 0 };
};
const AMAZON = 'https://www.amazon.in/Some-Long-Product-Name/dp/B0ABCDEFGH?tag=secret-tag&ref=sr_1_1';

// ---- HTTP 503 -------------------------------------------------------------------------

test('HTTP 503 is retried with exponential backoff and then succeeds', async () => {
  const { transport, calls } = scripted([
    { status: 503, html: SERVICE_UNAVAILABLE },
    { status: 503, html: SERVICE_UNAVAILABLE },
    { status: 200, html: PRODUCT_PAGE },
  ]);
  const w = noWait();
  const res = await F.fetchHtml(AMAZON, { transport, ...w, maxRetries: 2, backoffMs: 1000 });
  assert.strictEqual(res.problem, null);
  assert.strictEqual(res.status, 200);
  assert.strictEqual(calls.length, 3);
  assert.deepStrictEqual(w.delays, [1000, 2000]); // base * 2^n
});

test('a persistent 503 stops after the retry limit and is reported as unavailable', async () => {
  const { transport, calls } = scripted([{ status: 503, html: SERVICE_UNAVAILABLE }]);
  const w = noWait();
  const res = await F.fetchHtml(AMAZON, { transport, ...w, maxRetries: 2, backoffMs: 500 });
  assert.strictEqual(calls.length, 3); // 1 try + 2 retries, never more
  assert.deepStrictEqual(w.delays, [500, 1000]);
  assert.strictEqual(res.problem.kind, 'unavailable');
  assert.strictEqual(res.problem.transient, true);
  assert.strictEqual(res.status, 503);
});

test('backoff doubles each retry and jitter stays within 20%', () => {
  assert.strictEqual(F.backoffDelay(0, 1000, () => 0), 1000);
  assert.strictEqual(F.backoffDelay(1, 1000, () => 0), 2000);
  assert.strictEqual(F.backoffDelay(2, 1000, () => 0), 4000);
  assert.ok(F.backoffDelay(1, 1000, () => 1) <= 2400);
});

// ---- Timeouts -------------------------------------------------------------------------

test('a timeout is retried, and recovers if the next attempt works', async () => {
  const timeout = new F.FetchError('timeout', 'navigation timed out after 25000ms', { transient: true });
  const { transport, calls } = scripted([timeout, { status: 200, html: PRODUCT_PAGE }]);
  const w = noWait();
  const res = await F.fetchHtml(AMAZON, { transport, ...w, maxRetries: 2, backoffMs: 1000 });
  assert.strictEqual(res.problem, null);
  assert.strictEqual(calls.length, 2);
  assert.deepStrictEqual(w.delays, [1000]);
});

test('timeouts that outlast the retries reject with a timeout FetchError', async () => {
  const timeout = new F.FetchError('timeout', 'navigation timed out after 25000ms', { transient: true });
  const { transport, calls } = scripted([timeout]);
  const w = noWait();
  await assert.rejects(
    F.fetchHtml(AMAZON, { transport, ...w, maxRetries: 1, backoffMs: 100 }),
    (err) => err instanceof F.FetchError && err.kind === 'timeout'
  );
  assert.strictEqual(calls.length, 2);
});

test('browser navigation timeout is configurable and a Playwright timeout becomes a FetchError', async () => {
  const saved = process.env.BROWSER_NAV_TIMEOUT_MS;
  try {
    delete process.env.BROWSER_NAV_TIMEOUT_MS;
    assert.strictEqual(F.config.navTimeoutMs(), 25000);
    process.env.BROWSER_NAV_TIMEOUT_MS = '40000';
    assert.strictEqual(F.config.navTimeoutMs(), 40000);
    process.env.BROWSER_NAV_TIMEOUT_MS = '10'; // clamped
    assert.strictEqual(F.config.navTimeoutMs(), 5000);
    process.env.BROWSER_NAV_TIMEOUT_MS = 'abc'; // invalid -> default
    assert.strictEqual(F.config.navTimeoutMs(), 25000);
  } finally {
    if (saved === undefined) delete process.env.BROWSER_NAV_TIMEOUT_MS;
    else process.env.BROWSER_NAV_TIMEOUT_MS = saved;
  }

  let seenTimeout = null;
  let ctxClosed = false;
  const fakeBrowser = {
    newContext: async () => ({
      newPage: async () => ({
        route: async () => {},
        goto: async (_u, opts) => {
          seenTimeout = opts.timeout;
          throw Object.assign(new Error('page.goto: Timeout 7000ms exceeded.'), { name: 'TimeoutError' });
        },
      }),
      close: async () => { ctxClosed = true; },
    }),
  };
  await assert.rejects(
    F.fetchWithBrowser(AMAZON, { getBrowserFn: async () => fakeBrowser, navTimeoutMs: 7000 }),
    (err) => err.kind === 'timeout' && err.transient === true
  );
  assert.strictEqual(seenTimeout, 7000);
  assert.ok(ctxClosed, 'browser context is always closed');
});

// ---- Blocked pages: detected, never retried, never bypassed -----------------------------

test('HTTP 403, CAPTCHA and access-denied pages are classified and NOT retried', async () => {
  const cases = [
    [{ status: 403, html: '<html><title>Forbidden</title></html>' }, 'blocked'],
    [{ status: 200, html: CAPTCHA_PAGE }, 'captcha'],
    [{ status: 503, html: CAPTCHA_PAGE }, 'captcha'], // Amazon's explicit automated-access refusal
    [{ status: 200, html: ACCESS_DENIED }, 'access_denied'],
    [{ status: 403, html: ACCESS_DENIED }, 'access_denied'],
  ];
  for (const [response, kind] of cases) {
    const { transport, calls } = scripted([response]);
    const w = noWait();
    const res = await F.fetchHtml(AMAZON, { transport, ...w, maxRetries: 3 });
    assert.strictEqual(res.problem.kind, kind, `${response.status} -> ${kind}`);
    assert.strictEqual(res.problem.transient, false);
    assert.strictEqual(calls.length, 1, `${kind} must not be retried`);
    assert.deepStrictEqual(w.delays, []);
  }
});

test('a real product page that merely mentions "captcha" in a script is not treated as blocked', () => {
  assert.strictEqual(F.classifyResponse({ status: 200, html: PRODUCT_PAGE }), null);
});

// ---- extractPrice ---------------------------------------------------------------------

const withPage = (status, html) => async () => ({ status, html, problem: null });

test('extractPrice returns the price from a normal product page', async () => {
  const r = await extractPrice(AMAZON, { fetcher: withPage(200, PRODUCT_PAGE) });
  assert.strictEqual(r.best.value, 65900);
  assert.strictEqual(r.currency, '₹');
  assert.match(r.name, /iPhone 15/);
  assert.strictEqual(r.inStock, true);
});

test('extractPrice refuses error pages instead of returning them as products', async () => {
  const bad = [
    [503, SERVICE_UNAVAILABLE, 'unavailable', true],
    [403, '<html><title>Forbidden</title></html>', 'blocked', false],
    [200, CAPTCHA_PAGE, 'captcha', false],
    [200, ACCESS_DENIED, 'access_denied', false],
    [200, '<html><title>Robot Check</title><body>₹1,999 price</body></html>', 'captcha', false],
  ];
  for (const [status, html, kind, transient] of bad) {
    await assert.rejects(
      extractPrice(AMAZON, { fetcher: withPage(status, html) }),
      (err) => err instanceof F.PageUnavailableError && err.kind === kind && err.transient === transient &&
        err.userMessage === 'Price check temporarily unavailable.',
      `${status} ${kind}`
    );
  }
});

test('extractPrice maps fetch timeouts to a PageUnavailableError', async () => {
  const fetcher = async () => { throw new F.FetchError('timeout', 'navigation timed out after 25000ms', { transient: true }); };
  await assert.rejects(extractPrice(AMAZON, { fetcher }), (err) => err instanceof F.PageUnavailableError && err.kind === 'timeout');
});

test('a price of zero is never returned as a price', async () => {
  const zero = `<html><head><title>Some product</title><script type="application/ld+json">${JSON.stringify({ '@type': 'Product', offers: { price: '0', priceCurrency: 'INR' } })}</script></head><body><span id="productTitle">Some product</span></body></html>`;
  const r = await extractPrice(AMAZON, { fetcher: withPage(200, zero) });
  assert.strictEqual(r.best, null);
  assert.ok(r.candidates.every((c) => c.value > 0));
});

// ---- Logging --------------------------------------------------------------------------

test('logs describe the page without printing the full product URL', async () => {
  assert.strictEqual(F.describeUrl(AMAZON).includes('tag=secret-tag'), false);
  assert.ok(F.describeUrl(AMAZON).startsWith('www.amazon.in/Some-Long-Product'));

  const lines = [];
  const origWarn = console.warn, origError = console.error;
  console.warn = (...a) => lines.push(a.join(' '));
  console.error = (...a) => lines.push(a.join(' '));
  try {
    const { transport } = scripted([{ status: 503, html: SERVICE_UNAVAILABLE }]);
    await F.fetchHtml(AMAZON, { transport, ...noWait(), maxRetries: 1 });
  } finally {
    console.warn = origWarn;
    console.error = origError;
  }
  assert.ok(lines.length >= 2);
  for (const l of lines) {
    assert.ok(!l.includes(AMAZON), 'full URL leaked');
    assert.ok(!l.includes('secret-tag') && !l.includes('B0ABCDEFGH'), 'query/ASIN leaked');
    assert.ok(l.length < 200, 'log line should be concise');
  }
  assert.match(lines[0], /status=503 problem=unavailable retry=yes/);
});
