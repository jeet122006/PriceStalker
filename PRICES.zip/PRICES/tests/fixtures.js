// ---- Fixtures: minimal HTML shaped like each store's results page ---------------------

const amazonHtml = `<html><body>
 <div data-component-type="s-search-result" data-asin="B0AAAAAAA1">
   <h2><a class="a-link-normal" href="/Apple-iPhone-15/dp/B0AAAAAAA1?ref=x"><span>Apple iPhone 15 (128 GB) - Black</span></a></h2>
   <img class="s-image" src="https://m.media-amazon.com/a.jpg">
   <span class="a-price"><span class="a-offscreen">₹65,900.00</span></span>
   <span class="a-price a-text-price"><span class="a-offscreen">₹79,900.00</span></span>
 </div>
 <div data-component-type="s-search-result" data-asin="B0AAAAAAA2">
   <h2><a href="/x/dp/B0AAAAAAA2"><span>Apple iPhone 15 Pro (128 GB) - Natural Titanium</span></a></h2>
   <span class="a-price"><span class="a-offscreen">₹1,24,900.00</span></span>
 </div>
 <div data-component-type="s-search-result" data-asin="B0AAAAAAA3">
   <h2><a href="/x/dp/B0AAAAAAA3"><span>Spigen Case Cover for iPhone 15 128 GB</span></a></h2>
   <span class="a-price"><span class="a-offscreen">₹499.00</span></span>
 </div>
 <div data-component-type="s-search-result" data-asin="B0AAAAAAA4">
   <h2><a href="/x/dp/B0AAAAAAA4"><span>Apple iPhone 15 (128 GB) - Black (Renewed)</span></a></h2>
   <span class="a-price"><span class="a-offscreen">₹48,000.00</span></span>
 </div>
</body></html>`;

// Flipkart-style: obfuscated classes, data-id cards, prices WITHOUT decimals (Indian grouping)
const flipkartHtml = `<html><body>
 <div data-id="MOBGTAGPTB3VS24W"><div class="x1"><a class="zz" href="/apple-iphone-15-black-128-gb/p/itm6ac6485515ae4?pid=MOBGTAGPTB3VS24W&lid=LSTxxx&marketplace=FLIPKART" title="Apple iPhone 15 (Black, 128 GB)">
    <img alt="Apple iPhone 15" src="https://rukminim2.flixcart.com/a.jpg">
    <div>Apple iPhone 15 (Black, 128 GB)</div></a>
    <div class="p1">₹64,999</div><div class="p2">₹79,900</div><div>18% off</div></div></div>
 <div data-id="MOBGTAGPTB3VS99Z"><a href="/apple-iphone-15-plus/p/itm9?pid=MOBGTAGPTB3VS99Z" title="Apple iPhone 15 Plus (Blue, 128 GB)"><div>Apple iPhone 15 Plus (Blue, 128 GB)</div></a><div>₹72,999</div></div>
</body></html>`;

const snapdealHtml = `<html><body>
 <div class="product-tuple-listing">
   <a class="dp-widget-link" href="https://www.snapdeal.com/product/apple-iphone-15-128gb/6000001"><img class="product-image" src="https://n1.sdlcdn.com/a.jpg"></a>
   <p class="product-title" title="Apple iPhone 15 128 GB Black">Apple iPhone 15 128 GB Black</p>
   <span class="product-price" data-price="67490">Rs. 67,490</span>
   <span class="product-desc-price strike">Rs. 79,900</span>
 </div></body></html>`;

// Croma: JS-heavy, data embedded as JSON
const cromaHtml = `<html><body><div id="root"></div>
 <script id="__NEXT_DATA__" type="application/json">${JSON.stringify({ props: { products: [
   { name: 'Apple iPhone 15 128GB (Black)', url: '/apple-iphone-15-128gb-black-/p/300652', price: { value: 66490, formattedValue: '₹66,490' } },
   { name: 'Apple iPhone 15 Pro 256GB', url: '/apple-iphone-15-pro-256gb/p/300700', price: { value: 129900 } },
 ] } })}</script></body></html>`;

const relianceShell = `<html><head></head><body><div id="app"></div><script src="/bundle.js"></script></body></html>`;
const captchaHtml = `<html><body><h4>Enter the characters you see below</h4><p>api-services-support@amazon.com</p></body></html>`;

function fakeFetcher(map) {
  return async (url) => {
    for (const [needle, res] of Object.entries(map)) {
      if (url.includes(needle)) {
        if (res instanceof Error) throw res;
        return res;
      }
    }
    throw new Error('no fixture for ' + url);
  };
}

const ok = (html) => ({ status: 200, html });

module.exports = { amazonHtml, flipkartHtml, snapdealHtml, cromaHtml, relianceShell, captchaHtml, fakeFetcher, ok };
