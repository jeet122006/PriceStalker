const test = require('node:test');
const assert = require('node:assert');
const os = require('os');
const path = require('path');
const fs = require('fs');

process.env.DATA_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'pg-test-'));
const db = require('../server/db');
const { compareProduct } = require('../server/scheduler');
const F = require('./fixtures');

const fetcher = F.fakeFetcher({
  'amazon.in': F.ok(F.amazonHtml), 'flipkart.com': F.ok(F.flipkartHtml), 'snapdeal.com': F.ok(F.snapdealHtml),
  'croma.com': F.ok(F.cromaHtml), 'reliancedigital.in': F.ok(F.relianceShell),
});

function addProduct(url, price) {
  const info = db
    .prepare("INSERT INTO products (url, name, currency, current_price, compare_stores) VALUES (?, 'Apple iPhone 15 (128 GB) - Black : Amazon.in: Electronics', '₹', ?, 1)")
    .run(url, price);
  return db.prepare('SELECT * FROM products WHERE id = ?').get(info.lastInsertRowid);
}

test('cross-store watch alerts on a new low elsewhere, excludes the tracked store, and does not repeat', async () => {
  const alerts = [];
  const notify = async (a) => alerts.push(a);

  let p = addProduct('https://www.flipkart.com/apple-iphone-15/p/itm1?pid=X', 70000);
  // Flipkart is the tracked store, so the cheapest *other* store is Amazon.in at 65,900.
  let r = await compareProduct(p, { fetcher, notify });
  assert.strictEqual(r.best.store, 'amazon');
  assert.strictEqual(r.best.price, 65900);
  assert.strictEqual(alerts.length, 1);
  assert.match(alerts[0].title, /Cheaper on Amazon\.in/);
  assert.strictEqual(alerts[0].url, 'https://www.amazon.in/dp/B0AAAAAAA1');

  p = db.prepare('SELECT * FROM products WHERE id = ?').get(p.id);
  assert.strictEqual(p.best_other_price, 65900);
  assert.strictEqual(p.best_other_store, 'Amazon.in');
  assert.ok(p.compared_at);

  // Same prices again => not a new low => no second alert.
  await compareProduct(p, { fetcher, notify });
  assert.strictEqual(alerts.length, 1, 'no repeat alert for the same deal');
});

test('no alert when other stores are not meaningfully cheaper', async () => {
  const alerts = [];
  // Tracked at 66,000; best elsewhere (Flipkart 64,999) is only ~1.5% cheaper => under the 2% threshold.
  const p = addProduct('https://www.amazon.in/dp/B0AAAAAAA1', 66000);
  const r = await compareProduct(p, { fetcher, notify: async (a) => alerts.push(a) });
  assert.strictEqual(r.best.price, 64999);
  assert.strictEqual(alerts.length, 0);
});

test('a product without a name returns a clear error instead of searching blindly', async () => {
  const info = db.prepare("INSERT INTO products (url, name, current_price) VALUES ('https://x.test/p', NULL, 100)").run();
  const p = db.prepare('SELECT * FROM products WHERE id = ?').get(info.lastInsertRowid);
  const r = await compareProduct(p, { fetcher });
  assert.ok(r.error);
});
