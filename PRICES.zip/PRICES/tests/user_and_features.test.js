const test = require('node:test');
const assert = require('node:assert');
const os = require('os');
const path = require('path');
const fs = require('fs');

process.env.DATA_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'pg-users-'));
const db = require('../server/db');
const { registerUser, verifyLogin, ensureAdminUser } = require('../server/auth');

test('ensureAdminUser initializes default admin account', () => {
  ensureAdminUser();
  const admin = verifyLogin('admin', 'admin123');
  assert.ok(admin);
  assert.strictEqual(admin.username, 'admin');
  assert.strictEqual(admin.role, 'admin');
});

test('user registration creates an account with hashed password and prevents duplicate usernames', () => {
  const user = registerUser('alice', 'securePassword123', 'alice@example.com');
  assert.ok(user.id);
  assert.strictEqual(user.username, 'alice');
  assert.strictEqual(user.email, 'alice@example.com');

  // Verify login succeeds
  const authed = verifyLogin('alice', 'securePassword123');
  assert.ok(authed);
  assert.strictEqual(authed.id, user.id);

  // Wrong password fails
  const failed = verifyLogin('alice', 'wrongPassword');
  assert.strictEqual(failed, null);

  // Duplicate registration rejects
  assert.throws(() => {
    registerUser('alice', 'anotherPassword', 'alice2@example.com');
  }, /already exists/);
});

test('notifications table logs alerts and tracks read status', () => {
  const user = registerUser('bob', 'password123', 'bob@example.com');
  const info = db.prepare(
    "INSERT INTO products (user_id, url, name, currency, current_price, target_price) VALUES (?, 'https://test.com/item', 'Test Item', '$', 99, 100)"
  ).run(user.id);

  // Insert a notification
  db.prepare(`
    INSERT INTO notifications (user_id, product_id, type, title, message, old_price, new_price, url)
    VALUES (?, ?, 'price_drop', 'Price dropped on Test Item', 'Down from $120 to $99', 120, 99, 'https://test.com/item')
  `).run(user.id, info.lastInsertRowid);

  const notifs = db.prepare('SELECT * FROM notifications WHERE user_id = ?').all(user.id);
  assert.strictEqual(notifs.length, 1);
  assert.strictEqual(notifs[0].is_read, 0);
  assert.strictEqual(notifs[0].type, 'price_drop');

  // Mark as read
  db.prepare('UPDATE notifications SET is_read = 1 WHERE id = ?').run(notifs[0].id);
  const updated = db.prepare('SELECT * FROM notifications WHERE id = ?').get(notifs[0].id);
  assert.strictEqual(updated.is_read, 1);
});

test('dashboard stats accurately computes total tracked, drops, and targets', () => {
  const user = registerUser('charlie', 'password123', 'charlie@example.com');
  const p1 = db.prepare(
    "INSERT INTO products (user_id, url, name, currency, current_price, target_price) VALUES (?, 'https://test.com/p1', 'Item 1', '$', 80, 100)"
  ).run(user.id);
  db.prepare('INSERT INTO price_history (product_id, price) VALUES (?, 100)').run(p1.lastInsertRowid);
  db.prepare('INSERT INTO price_history (product_id, price) VALUES (?, 80)').run(p1.lastInsertRowid);

  const row = db.prepare(`
    SELECT p.id, p.current_price, p.target_price,
           (SELECT MAX(price) FROM price_history h WHERE h.product_id = p.id) as max_price
    FROM products p WHERE user_id = ?
  `).get(user.id);

  assert.strictEqual(row.current_price, 80);
  assert.strictEqual(row.max_price, 100);
  assert.strictEqual(row.current_price < row.max_price, true); // Active drop
  assert.strictEqual(row.current_price <= row.target_price, true); // Target reached
});

test('store registry contains all 15 platforms with valid configurations and offer enrichment', () => {
  const { STORES, STORE_MAP, enrichOffer } = require('../server/stores');
  assert.strictEqual(STORES.length, 15, 'All 15 platforms registered');

  const expectedIds = [
    'amazon', 'flipkart', 'snapdeal', 'croma', 'reliance',
    'tatacliq', 'vijaysales', 'jiomart', 'myntra', 'ajio',
    'meesho', 'nykaa', 'poorvika', 'sangeetha', 'ebay'
  ];

  for (const id of expectedIds) {
    const store = STORE_MAP[id];
    assert.ok(store, `Store ${id} must exist in STORE_MAP`);
    assert.ok(store.name, `Store ${id} must have a name`);
    assert.ok(store.color, `Store ${id} must have a brand color`);
    assert.ok(typeof store.searchUrl === 'function', `Store ${id} must have searchUrl function`);
    assert.ok(typeof store.parse === 'function', `Store ${id} must have parse function`);
  }

  // Test offer enrichment
  const baseOffer = { title: 'Apple iPhone 16 128GB', price: 69900, url: 'https://test.com' };
  const enriched = enrichOffer(baseOffer, 'tatacliq');
  assert.ok(enriched.originalPrice >= 69900);
  assert.ok(enriched.rating >= 4.0);
  assert.ok(Array.isArray(enriched.offers));
  assert.ok(enriched.offers.length > 0);
});
